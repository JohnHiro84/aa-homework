module.exports = {
  // mongoURI: 'mongodb://AtlasAdmin:Admin6789@cluster0-shard-00-00-yx83e.mongodb.net:27017,cluster0-shard-00-01-yx83e.mongodb.net:27017,cluster0-shard-00-02-yx83e.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true'
  mongoURI: 'mongodb://AtlasAdmin:Admin6789@cluster0-shard-00-00-yx83e.mongodb.net:27017,cluster0-shard-00-01-yx83e.mongodb.net:27017,cluster0-shard-00-02-yx83e.mongodb.net:27017/merntwitter?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true',
  secretOrKey: "secret123abc789"
            //Make sure this is your own unique string
}

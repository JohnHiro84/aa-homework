



export const commentsByEventId = (state) => {
  let comments_exist = state.comments;
  let copy = comments_exist.all;
  return copy;

};

City Events

This application lets users be able to create
an account as well as view and create events
for others to browse. One can add themselves
to the event list to confirm attendance.

This application was created with MongoDB, express,
React, Redux, and nodeJs.

One of the challenges I faced was in getting the
events list to have each of the event boxs to be
equal in height. I used flexbox to fix this.

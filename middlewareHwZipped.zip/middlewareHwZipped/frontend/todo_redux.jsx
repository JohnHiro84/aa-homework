import React from 'react';
import ReactDOM from 'react-dom';
import configureStore from './store/store';
// import rootReducer from 'reducers';
import {createStore, applyMiddleware} from 'redux';
import Root from './components/root';
import {receiveTodo, receiveTodos} from './actions/todo_actions';
import logger from './middleware/logger';
import rootReducer from './reducers/root_reducer';


const addLoggingToDispatch = store => next => action => {

  console.log('Action received:', action);
  console.log('State pre-dispatch:', store.getState());
  let result = next(action);
  console.log('State post-dispatch:', store.getState());

  return result;
};


//
// const configureStore = (preloadedState = {}) => {
//   const store = createStore(
//     rootReducer,
//     preloadedState,
//     applyMiddlewares(store, [logger])
//   );
//     store.subscribe(() => {
//     localStorage.state = JSON.stringify(store.getState());
//   });
//   return store;
// }
//
// const applyMiddlewares = (store, middlewares) => {
//   let dispatch = store.dispatch;
//   console.log(store);
//   middlewares.forEach(mid => {
//     console.log(mid);
//     dispatch = mid(store)(dispatch);
//   });
//   return Object.assign({}, store, { dispatch })
// };




document.addEventListener('DOMContentLoaded', () => {
  const preloadedState = localStorage.state ?
    JSON.parse(localStorage.state) : {};
  const store = configureStore(preloadedState);


  window.store = store;
  window.receiveTodos = receiveTodos;
  window.receiveTodo = receiveTodo;
  window.dispatch = store.dispatch;
  // let store.dispatch = addLoggingToDispatch(store);


  const root = document.getElementById('content');
  ReactDOM.render(<Root store={store} />, root);
});

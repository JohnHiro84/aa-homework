import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../reducers/root_reducer';
// import thunk from 'redux-thunk';
// import logger from 'redux-logger';
import logger from '../middleware/logger';

//
// export const applyMiddlewares = (store, middlewares) => {
//   let dispatch = store.dispatch;
//   console.log(store);
//   middlewares.forEach(mid => {
//     console.log(mid);
//     dispatch = mid(store)(dispatch);
//   });
//   return Object.assign({}, store, { dispatch })
// };


const configureStore = (preloadedState = {}) => {
  const store = createStore(
    rootReducer,
    preloadedState,
    applyMiddleware(logger)
  );
    store.subscribe(() => {
    localStorage.state = JSON.stringify(store.getState());
  });
  return store;
}

export default configureStore;

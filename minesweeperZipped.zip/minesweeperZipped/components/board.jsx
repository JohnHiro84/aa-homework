import React from 'react';
import {Board} from '../minesweeper.js'
import {Tile} from '../minesweeper.js'

class Boardjsx extends React.Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   time: new Date()
    // };
    // this.explore = this.explore.bind(this);
    // this.functionx = this.functionx.bind(this);
  }

  // explore() {
  //   // console.log(tile);
  //   if (tile.explored === true){
  //     return "E";
  //   } else if (tile.bombed === true){
  //     return "B";
  //   } else if (tile.flagged === true){
  //     return "F";
  //   }
  // }

  // functionx() {
  //   console.log("x");
  // }
  render() {
    console.log(this.props.theboard.grid[0][0].bombed);
 return (

      <div>
        <p></p>
        {
          this.props.theboard.grid.map(function(item, i){
            // console.log(item);
            return(
              <ul key={"a" + i.toString()} className ="mine-row">
                {
                  item.map(function(tile, j){
                    console.log();
                    return <li className="mine-cell" key={"b" + j.toString()}>{tile.status()}</li>
                  })
                }
              </ul>
            )
          })
        }
      </div>
    )
  }
}

export default Boardjsx;

import React from 'react';
// import Minesweeper from '../minesweeper';
// import Board from '../minesweeper.js';
import {Tile} from '../minesweeper.js'
import {Board} from '../minesweeper.js'
import Boardjsx from './board'
import Tilejsx from './tile'

class Game extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      board: new Board(10,10)
    }

    this.updateGame = this.updateGame.bind(this);
    };

    updateGame() {
      console.log(this.state.board.grid)
    }

    render() {
      return (
        <div>
        <h1>Game</h1>
        <p onLoad={this.updateGame()}></p>
        <Boardjsx  theboard={this.state.board} updateGame={this.updateGame}/>
        <Tilejsx />
       </div>
      )
    }
}

export default Game;

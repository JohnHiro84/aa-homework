import React from 'react';

class Tilejsx extends React.Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   time: new Date()
    // };
  }


  render() {
   return (
     <div>
       <h2>T</h2>
    </div>
    )
  }
}

export default Tilejsx;

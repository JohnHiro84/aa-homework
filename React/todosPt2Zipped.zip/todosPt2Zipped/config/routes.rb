Rails.application.routes.draw do

  # resources :todos, :defaults => { :format => :json }
  root 'static_pages#root'
  resources :users, only: [:new, :create]
  resource :session, only: [:new, :create, :destroy]

  namespace :api, defaults:{ format: :json } do
  	resources :todos, only: [:show, :index, :update, :create, :destroy] do
      resources :steps, only: [:index, :create]
    end

    resources :steps, only: [:show, :update, :destroy]
  end
end

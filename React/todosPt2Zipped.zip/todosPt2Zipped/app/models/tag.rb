
class Tag < ApplicationRecord
    validates :name, presence: true

    #
    # has_many :steps,
    #   class_name: :Step,
    #   dependent: :destroy
end

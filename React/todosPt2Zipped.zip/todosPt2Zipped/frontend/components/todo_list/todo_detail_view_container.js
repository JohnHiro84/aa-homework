import { connect } from 'react-redux';
import TodoDetailView from './todo_detail_view';
// Actions
import { removeTodo, destroyTodo } from '../../actions/todo_actions';
import { receiveSteps, fetchSteps } from '../../actions/step_actions';

const mapDispatchToProps = (dispatch, { todo }) => ({
  destroyTodo: () => dispatch(destroyTodo(todo)),
  fetchSteps: () => dispatch(fetchSteps(todo.id))

});

export default connect(
  null, // todo props is already passed in
  mapDispatchToProps
)(TodoDetailView);

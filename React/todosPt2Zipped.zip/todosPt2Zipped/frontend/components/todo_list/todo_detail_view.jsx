import React from 'react';

// Components
import StepListContainer from '../step_list/step_list_container';

class TodoDetailView extends React.Component {
  componentDidMount() {
    this.props.fetchSteps();
  }
  render() {
    const { todo, destroyTodo } = this.props;
    return(
      <div className="detail_viewer">
        <h3>Description:</h3>
        <p className="todo-body">{ todo.body }</p>
        <StepListContainer todo_id={ todo.id } />
        <button
          className="deleteTodo"
          onClick={ destroyTodo }>Delete Todo</button>
      </div>
    );
  }
}

export default TodoDetailView;

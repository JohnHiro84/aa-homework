import { uniqueId } from '../../util/id_generator';
import React from 'react';
import ErrorList from './error_list';
class TodoForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "",
      body: "",
      done: false,
      tag_names: [],
      newTag: ""
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.addTag = this.addTag.bind(this);
  }

  update(property) {
    return e => this.setState({[property]: e.target.value});
  }

  addTag(e) {
    if(this.state.newTag.length > 0){
      this.setState({
        tag_names: [ ...this.state.tag_names, this.state.newTag ],
        newTag: ""
      });
    }
  }

  handleSubmit(e) {
    e.preventDefault();
    const todo = Object.assign({}, this.state);
    console.log(todo);
    this.props.createTodo({todo}).then(
      () => this.setState({title: '', body: '', newTag: "", tag_names: []})
    );
  }




  render() {
    const tags = this.state.tag_names.map(tag => (
        <li class="tags-li-tba" key={`todo-list-item${tag}`} >{tag}</li>
      )
    );
    return (
      <form className="todo-form" onSubmit={this.handleSubmit}>
      <ErrorList errors={ this.props.errors } />
        <label>Title:</label>
          <input
            className="input"
            ref="title"
            value={this.state.title}
            placeholder="buy milk"
            onChange={this.update('title')}
            required/>

        <label>Body:</label>
          <textarea
            className="input"
            ref="body"
            cols='20'
            value={this.state.body}
            rows='5'
            placeholder="2% or whatever is on sale!"
            onChange={this.update('body')}
            required></textarea>


        <label>Tags:</label>
          <input
            className="input"
            ref="tag_names"
            cols='20'
            value={this.state.newTag}
            rows='5'
            placeholder="add a tag!"
            onChange = {this.update("newTag")}
            ></input>
        <button className="add-tag-button" type="button" onClick={this.addTag}>Add Tag</button>


        <ul className="tags-ul-tba">{tags}</ul>

        <button className="create-todo-button">Create Todo!</button>
      </form>
    );
  }
};

export default TodoForm;

import React from 'react';
import TodoDetailViewContainer from './todo_detail_view_container';
import merge from 'lodash/merge';

class TodoListItem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {detail: false};
    this.toggleDetail = this.toggleDetail.bind(this);
    this.toggleTodo = this.toggleTodo.bind(this);
  }

  toggleDetail(e) {
    e.preventDefault();
    this.setState({ detail: !this.state.detail });
  }

  toggleTodo(e) {
    e.preventDefault();
    const toggledTodo = merge(
      {},
      this.props.todo,
      { done: !this.props.todo.done }
    );

     this.props.updateTodo(toggledTodo);
  }

  render() {
    const { todo , updateTodo, destroyTodo } = this.props;
    const { title, done, tag_names } = todo;

    let detail;
    if (this.state.detail) {
      detail = <TodoDetailViewContainer todo={ todo } />;
    }
    const tags = todo["tags"].map(tag => (
        <li class="tags-li-tba"
          key={`tag.id`}
           >{tag.name}</li>
      ));

    return (
      <li className="todo-list-item">
        <div className="todo-header">
          <h2><a onClick={ this.toggleDetail }>{ title }</a></h2>
          <button
            id="toggleTodo"
            className={ done ? "done" : "undone" }
            onClick={ this.toggleTodo }>
            { done ? "Undo" : "Done" }
          </button>
          <h3>Tags:</h3>
          <ul class="tags-ul-tba">{tags}</ul>
        </div>
        { detail }
      </li>
    );
  }
}

export default TodoListItem;

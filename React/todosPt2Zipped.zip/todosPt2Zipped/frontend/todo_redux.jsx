import React from 'react';
import ReactDOM from 'react-dom';
import configureStore from './store/store';
// import {fetchTodos} from './util/todo_api_util';
import Root from './components/root';
import {receiveTodo, receiveTodos, fetchTodos} from './actions/todo_actions';
// import thunkMiddleware from './middleware/thunk_middleware';
import * as APIUtil from './util/todo_api_util';

document.addEventListener('DOMContentLoaded', () => {

  const store = configureStore();
  // window.store = store;

  window.store = store;
  window.receiveTodos = receiveTodos;
  window.receiveTodo = receiveTodo;
  window.dispatch = store.dispatch;
  // window.fetchTodos = fetchTodos;
  window.fetchTodos = fetchTodos;
  // window.thunkMiddeware = thunkMiddleware;
  window.apifetchTodos = APIUtil.fetchTodos;

  const root = document.getElementById('content');
  ReactDOM.render(<Root store={store} />, root);
});


export const fetchTodos = () => {
  let thepromise = $.ajax({
    method: 'GET',
    url: '/api/todos'
  })
  return thepromise;
};

export const createTodo = (todo) => {
  console.log(todo);
  let apromise = $.ajax({
    url: '/api/todos',
    type: 'POST',
    data: todo
    // data: {
    //     title: todo.title,
    //     body: todo.body,
    //     done: todo.done
    // }
    // data: JSON.stringify(todo),
  //   error: function(e){
  //     console.log(e);
  //   },
  //   dataType: "json",
  //   contentType: "application/json"
  });
  return apromise;
}

export const updateTodo = (todo) => {
  console.log(todo);
  let apromise = $.ajax({
    method: 'PATCH',
    url: `/api/todos/${todo.id}`,
    data: { todo }
  });
  return apromise;
}



export const deleteTodo = (todo) => {
  console.log(todo);
  let apromise = $.ajax({
    method: 'DELETE',
    url: `/api/todos/${todo.id}`,
    data: { todo }
  });
  return apromise;
}

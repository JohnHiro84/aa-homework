
export const fetchSteps = (todo_id) => {
  let thepromise = $.ajax({
    method: 'GET',
    url: `/api/todos/${todo_id}/steps`
  })
  return thepromise;
};


export const createStep = (todo_id, step) => {
  let apromise = $.ajax({
    url: `/api/todos/${todo_id}/steps`,
    type: 'POST',
    data: {step}

  });
  return apromise;
}


export const updateStep = (step) => {
  let apromise = $.ajax({
    url: `/api/steps/${step.id}`,
    type: 'PATCH',
    data: {step}

  });
  return apromise;
}


export const deleteStep = (step) => {
  let apromise = $.ajax({
    url: `/api/steps/${step.id}`,
    type: 'DELETE'

  });
  return apromise;
}

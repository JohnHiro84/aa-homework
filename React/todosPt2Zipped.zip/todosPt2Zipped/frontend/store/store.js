import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../reducers/root_reducer';
import thunk_middleware from '../middleware/thunk_middleware';
import logger from 'redux-logger';

// import middleware_new from '../middleware/thunk';

const configureStore = (preloadedState = {}) => {
  const store = createStore(rootReducer, preloadedState, applyMiddleware(thunk_middleware));
  return store;
}

export default configureStore;

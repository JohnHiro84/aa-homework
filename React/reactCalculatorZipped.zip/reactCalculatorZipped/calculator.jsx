import React from 'react';

class Calculator extends React.Component {
  constructor(props) {
    super(props);
    // your code here
    this.state = {
      num1: "",
      num2: "",
      result: 0,
      operation: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleChange2 = this.handleChange2.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

    this.clear = this.clear.bind(this);

    this.addoperation = this.addoperation.bind(this);
    this.subtractoperation = this.subtractoperation.bind(this);
    this.multiplyoperation = this.multiplyoperation.bind(this);
    this.divideoperation = this.divideoperation.bind(this);
  }



  // your code here
  handleChange(event) {
    this.setState({num1: event.target.value});

  }
  handleChange2(event) {
    this.setState({num2: event.target.value});
  }

  handleSubmit(event) {

    // this.state.result = this.state.num1 + this.state.num2;

        event.preventDefault();
  }
  addoperation(event){
    event.preventDefault();
    this.setState({operation: "+"});
    this.setState({result: Number(this.state.num1) + Number(this.state.num2)});

  }
  subtractoperation(event){
    event.preventDefault();
    this.setState({operation: "-"});
    this.setState({result: Number(this.state.num1) - Number(this.state.num2)});

  }
  multiplyoperation(event){
    event.preventDefault();
    this.setState({operation: "*"});
    this.setState({result: Number(this.state.num1) * Number(this.state.num2)});

  }

  divideoperation(event){
    event.preventDefault();
    this.setState({operation: "/"});
    this.setState({result: Number(this.state.num1) / Number(this.state.num2)});

  }
  clear(event){
    event.preventDefault();
    this.setState({operation: "", num1: "", num2: "", result: ""});
    document.getElementById("input1").value = "";
    document.getElementById("input2").value = "";
  }

  render() {
   return (
     <div>
       <h2>Hello world</h2>



       <h1>Calculator</h1>

       <form onSubmit={this.handleSubmit}>
       <input type="text" id="input1" name="input1" onChange={this.handleChange} value={this.state.num1.value}/>
       <input type="text" id="input2" name="input2" onChange={this.handleChange2} value={this.state.num2.value}/>
       <button onClick={this.clear}>Clear!!!</button>
       <br/>
       <button onClick={this.addoperation}>add(+)</button>
       <button onClick={this.subtractoperation}>subtract(-)</button>
      <button onClick={this.multiplyoperation}>multiply(*)</button>
      <button onClick={this.divideoperation}>divide(/)</button>
       </form>
       <h2>Result: {this.state.result}</h2>
     </div>
   );
 }
}

export default Calculator;

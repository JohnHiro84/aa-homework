import { combineReducers } from 'redux';
import entitiesReducer from './entities_reducer';

const rootReducer = combineReducers({
  entities: entitiesReducer
});
export default rootReducer;


//
//
// import { combineReducers } from 'redux';
// import entities from './entities_reducer';
//
//
// export default combineReducers({
//   entities
// });

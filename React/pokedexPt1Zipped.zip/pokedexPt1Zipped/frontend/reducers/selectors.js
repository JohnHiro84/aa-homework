// export const selectAllPokemon = (state)=> {
//   let all_pokemon = state.entities.pokemon;
// 	Object.keys(all_pokemon).map(id => all_pokemon[id])
//   return all_pokemon;
// };

export const selectAllPokemon = state => Object.values(state.entities.pokemon);




// export const allPokemon = ({ pokemon }) => Object.keys(pokemon).map(id => pokemon[id]);

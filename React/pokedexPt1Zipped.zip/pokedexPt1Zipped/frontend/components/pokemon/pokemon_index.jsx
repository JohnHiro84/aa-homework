import React from 'react';


class PokemonIndex extends React.Component {
  componentDidMount() {
    this.props.requestAllPokemon();
  }

  render() {
    const { pokemon, requestAllPokemon } = this.props;
    console.log(pokemon);

    let pokemonItems = pokemon.map(poke => (

        <li key={`poke-list-item${poke.id}`} pokemon={poke}>{poke.name}</li>
      )
    );

    return(
      <div>
        <ul className="poke-list">
          { pokemonItems }
        </ul>
      </div>
    );
  }
}

export default PokemonIndex;

export const fetchAllPokemon = () => {
 let poke_promise = $.ajax({
    method: 'GET',
    url: `/api/pokemon/`
  })
  return poke_promise;
};

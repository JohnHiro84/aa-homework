import React from 'react';

const Violet = () => (
  <div>
    <h2 className="violet"></h2>
  </div>
);

export default Violet;

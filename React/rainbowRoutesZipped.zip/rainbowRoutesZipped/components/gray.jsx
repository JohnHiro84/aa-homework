import React from 'react';

const Gray = () => (
  <div>
    <h2 className="gray"></h2>
  </div>
);

export default Gray;

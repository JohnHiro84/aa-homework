Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root to: 'static_pages#root'


  # namespace :api do
  #   resource :session, only: [:new]
  #   resources :users, only: [:new]
  # end

  namespace :api, defaults: {format: :json} do
    resources :users, only: [:index, :create, :show]
    resources :benches, only: [:create, :index, :show]
    resource :session, only: [:create, :destroy]

    # , only: [:create, :index, :show]
  end



end

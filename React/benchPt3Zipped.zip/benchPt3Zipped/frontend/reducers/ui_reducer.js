import { combineReducers } from 'redux';
import merge from 'lodash/merge';

import filters from './filter_reducer';

export default combineReducers({
  filters
});

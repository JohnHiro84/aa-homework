export const selectAllBenches = state => Object.values(state.entities.benches);

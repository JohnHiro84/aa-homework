
import React from 'react';
import {createMarkerFromBench} from './create_marker_from_bench';

export default class MarkerManager {
  constructor(map) {
    this.map = map;
    this.markers = {};
  }

  updateMarkers(benches) {

    const benchesObj = {};
    benches.forEach(bench => benchesObj[bench.id] = bench);

    console.log('time to update');
    console.log(this.markers);
    let marks;
    if(benches.length > 0){
      // marks = benches.map(bench => createMarkerFromBench(this.map, bench));
      benches.forEach(bench => this.markers[bench.id] = createMarkerFromBench(this.map, bench));
    }

    console.log("this.markers");
    console.log(this.markers);

    Object.keys(this.markers)
      .filter(benchId => !this.markers[benchId])
      .forEach((benchId) => this.removeMarker(this.markers[benchId]))

    // this.markers = benches;
  }
  removeMarker(marker) {
  this.markers[marker.benchId].setMap(null);
  delete this.markers[marker.benchId];
}

}

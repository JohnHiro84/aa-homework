
//
// export const fetchAllBenches = () => {
//  let poke_promise = $.ajax({
//     method: 'GET',
//     url: `/api/benches/`,
//     error: (err) => console.log(err)
//   })
//   return poke_promise;
// };

export const fetchAllBenches = (data) => {
 let poke_promise = $.ajax({
    method: 'GET',
    url: `/api/benches/`,
    error: (err) => console.log(err),
    data
  })

  return poke_promise;
};

export const fetchSingleBench = (benchId) => {
 let poke_promise = $.ajax({
    method: 'GET',
    url: `/api/benches/${benchId}`
  })
  return poke_promise;
};

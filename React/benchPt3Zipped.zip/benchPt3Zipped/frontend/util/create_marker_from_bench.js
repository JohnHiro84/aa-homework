export const createMarkerFromBench = (map, bench) => {
  // console.log(bench);
  // let ele = {};
  // ele[bench.id] = bench.description;
  // return ele;

  // position: { lat: 37.7758, lng: -122.435 },


  var marker = new google.maps.Marker({
    position: { lat: bench.lat, lng: bench.lng},
    map: map,
    title: bench.description
  });
  marker.setMap(map);
  return marker;

}

import React from 'react';
import MarkerManager from '../util/marker_manager';

// just a normal react component class :)
class BenchMap extends React.Component {

  componentDidMount() {
    // set the map to show SF
    const mapOptions = {
      center: { lat: 37.7758, lng: -122.435 }, // this is SF
      zoom: 13
    };

    // wrap this.mapNode in a Google Map
    this.map = new google.maps.Map(this.mapNode, mapOptions);
    this.MarkerManager = new MarkerManager(this.map);
    this.MarkerManager.updateMarkers(this.props.benches);
    this.props.fetchBenches();
    this.listenForMove();

  }
  componentDidUpdate(prevProps) {
    if (prevProps.benches !== this.props.benches) {
      this.MarkerManager.updateMarkers(this.props.benches);
      console.log('componentDidUpdate');
      console.log(prevProps.benches);
      console.log(this.props.benches);
      console.log(this.map.bounds);
      // this.props.requestSinglePokemon(this.props.match.params.pokemonId);
    }
  }
  listenForMove() {
  /*
   * we listen for the map to emit an 'idle' event, it does this when
   * the map stops moving
   */
  google.maps.event.addListener(this.map, 'idle', () => {
    const bounds = this.map.getBounds();
    // alert('map has moved, check console to see updated bounds');
    // alert(bounds);
    const returned_bounds = {
      "northEast" : { "lat" : bounds.getNorthEast().lat(),
      "lng" : bounds.getNorthEast().lng() },
      "southWest" : { "lat" : bounds.getSouthWest().lat(),
      "lng" : bounds.getSouthWest().lng() }
    }
    // alert(JSON.stringify(returned_bounds));
    this.props.updateBounds(returned_bounds);
  });
}

  render() {
// <div id='map' ref='map'/>
    return (

        <div id='map' ref={ map => this.mapNode = map }>
        <p>
          map is here
        </p>

        <span>MAP DEMO</span>

      </div>
    );
  }
}

export default BenchMap;

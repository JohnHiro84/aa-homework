import React from 'react';
import { Link } from 'react-router-dom';

class SessionForm extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: ""
    };
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  update(property) {
    return e => this.setState({ [property]: e.target.value });
  }
  handleSubmit(e) {
    e.preventDefault();
    const user = Object.assign({}, this.state);
    this.props.processForm(user);

    this.props.history.push('/');
  }


  render() {

    let opposite_link = "";
    if (this.props.formType === "signup"){
      opposite_link = "/login";
    } else if (this.props.formType === "login"){
      opposite_link = "/signup";
    }
    return (
      <section>
        <h1>{this.props.formType}</h1>
        <form className="session-form" onSubmit={this.handleSubmit}>
            <input
              type="text"
              value={this.state.username}
              placeholder=""
              onChange={this.update('username')}
            />
            <input
              type="text"
              value={this.state.password}
              placeholder=""
              onChange={this.update('password')}
            />

          <button>{this.props.formType}</button>
        </form>
        <Link className="btn" to={opposite_link}>{opposite_link}</Link>

      </section>
    );
  }
      //...
}

export default SessionForm;

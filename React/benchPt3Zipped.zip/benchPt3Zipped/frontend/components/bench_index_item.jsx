import React from 'react';
// import { Link } from 'react-router-dom';

const BenchIndexItem = ({ bench }) => (
  <li className="bench-index-item">
      <span>{bench.id}</span>
      <span>{bench.description}</span>
      <span>{bench.lng}</span>
      <span>{bench.lat}</span>
  </li>
);

export default BenchIndexItem;

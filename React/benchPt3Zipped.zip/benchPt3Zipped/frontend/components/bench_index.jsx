import React from 'react';
import BenchIndexItem from './bench_index_item';

class BenchIndex extends React.Component {
  componentDidMount() {
    // request benches from your API here
    this.props.fetchBenches();

    // this.props.fetchBenches(ownProps.match.params.filters);
  }

    render() {
      const { benches} = this.props;

      let benchItems = benches.map(bench => (
          <BenchIndexItem key={`bench-index-item${bench.id}`} bench={bench}/>
        )
      );

      return(
        <div>
        <ul className="bench-list">
          { benchItems }
        </ul>
        </div>
      );
    }
  }

  export default BenchIndex;

import React from 'react';
import BenchIndex from './bench_index.jsx';
import BenchMap from './bench_map.jsx';


class Search extends React.Component {

  render() {
    const { benches, fetchBenches, updateBounds} = this.props;
    //
    // let pokemonItems = pokemon.map(poke => (
    //     <PokemonIndexItem key={`poke-index-item${poke.id}`} pokemon={poke}/>
    //   )
    // );

    return(
      <div>
        <BenchIndex benches={benches} fetchBenches={fetchBenches}/>
        <BenchMap benches={benches} fetchBenches={fetchBenches} updateBounds={updateBounds}/>
      </div>
    );
  }
}

export default Search;

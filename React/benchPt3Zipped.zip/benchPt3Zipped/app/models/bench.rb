
class Bench < ApplicationRecord

  # validates :username, presence: true, uniqueness: true


    def self.in_bounds(bounds)
      self.where("lat < ?", bounds[:northEast][:lat])
        .where("lat > ?", bounds[:southWest][:lat])
        .where("lng > ?", bounds[:southWest][:lng])
        .where("lng < ?", bounds[:northEast][:lng])

      # Bench.where(lat: (Float(bounds["southWest"]["lat"]))..(Float(bounds["northEast"]["lat"])))
      # .where(lng: (Float(bounds["southWest"]["lng"]))..(Float(bounds["northEast"]["lng"])))
      #
      # self.where(lat: (Float(bounds["southWest"]["lat"]))..(Float(bounds["northEast"]["lat"])))
      # .where(lng: (Float(bounds["southWest"]["lng"]))..(Float(bounds["northEast"]["lng"])))


    end
    # Bench.where(self.lat >= Float(bounds["southWest"]["lat"]))
    # Bench.all
    # Bench.where(lat: 37.784976)
    # AND lat <= Float(bounds["northEast"]["lat"])
         # if self.lat >= Float(bounds["southWest"]["lat"]) &&
         #   self.lat <= Float(bounds["northEast"]["lat"]) &&
         #   self.lng >= Float(bounds["southWest"]["lng"]) &&
         #   self.lng <= Float(bounds["northEast"]["lng"])
         #   puts "lat and lng inbounds"
         # end
    # google map bounds will be in the following format:
    # {
    #   "northEast"=> {"lat"=>"37.80971", "lng"=>"-122.39208"},
    #   "southWest"=> {"lat"=>"37.74187", "lng"=>"-122.47791"}
    # }
    #... query logic goes here

end

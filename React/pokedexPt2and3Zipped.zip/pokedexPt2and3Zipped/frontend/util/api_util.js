export const fetchAllPokemon = () => {
 let poke_promise = $.ajax({
    method: 'GET',
    url: `/api/pokemon/`
  })
  return poke_promise;
};

export const fetchSinglePokemon = (pokemonId) => {
 let poke_promise = $.ajax({
    method: 'GET',
    url: `/api/pokemon/${pokemonId}`
  })
  return poke_promise;
};

export const createPokemon = (pokemon) => {
  pokemon.moves = Object.keys(pokemon.moves).map(k => pokemon.moves[k]);

 let poke_promise = $.ajax({
    method: 'POST',
    url: `/api/pokemon/`,
    data: { pokemon }
  })
  return poke_promise;
};

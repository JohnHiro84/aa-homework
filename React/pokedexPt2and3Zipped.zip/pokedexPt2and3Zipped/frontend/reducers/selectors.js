

export const selectAllPokemon = state => Object.values(state.entities.pokemon);

export const selectPokeItems = (state, poke) => {
  return poke ? poke.item_ids.map(id => state.entities.items.items[id]) : [];
};

// selectPokemonItem(state, itemId)
// export const allPokemon = ({ pokemon }) => Object.keys(pokemon).map(id => pokemon[id]);

export const selectPokemonItem = (state, id) => {
  return state.entities.items.items[id];
};

import React from 'react';
import ReactDOM from 'react-dom';
import {fetchAllPokemon, fetchSinglePokemon} from './util/api_util';
import { Provider } from 'react-redux';
import PokemonIndexContainer from './components/pokemon/pokemon_index_container';

import { receiveAllPokemon, requestAllPokemon,
  receiveSinglePokemon, requestSinglePokemon, createPokemon } from './actions/pokemon_actions';
import configureStore from './store/store';
// import Root from './components/root';
import { HashRouter, Route } from 'react-router-dom';

const Root = ({store}) => (
  <Provider store={store}>
    <HashRouter>
      <Route path="/" component={PokemonIndexContainer} />
    </HashRouter>
  </Provider>
);

document.addEventListener('DOMContentLoaded', () => {
  const store = configureStore();
  // window.store = store;
  // window.fetchAllPokemon = fetchAllPokemon;
  // window.receiveAllPokemon = receiveAllPokemon;
  // window.getState = store.getState;
  // window.dispatch = store.dispatch;
  // window.requestAllPokemon = requestAllPokemon;
  // window.requestSinglePokemon = requestSinglePokemon;
  // window.receiveSinglePokemon = receiveSinglePokemon;
  // window.fetchSinglePokemon = fetchSinglePokemon;
  // window.createPokemon = createPokemon;

  const rootEl = document.getElementById('root');
  ReactDOM.render(<Root store={store}/>, rootEl);
});

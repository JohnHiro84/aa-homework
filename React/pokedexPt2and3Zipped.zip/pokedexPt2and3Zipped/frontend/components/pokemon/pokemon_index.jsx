import React from 'react';
import PokemonIndexItem from './pokemon_index_item';
import PokemonDetailContainer from './pokemon_detail_container';
import PokemonFormContainer from './pokemon_form_container';
import { Route } from 'react-router-dom';
import LoadingIcon from './loading_icon';

class PokemonIndex extends React.Component {
  componentDidMount() {
    this.props.requestAllPokemon();
  }

  render() {
    const { pokemon, loading} = this.props;


    if (loading) { return <LoadingIcon />; }

    let pokemonItems = pokemon.map(poke => (
        <PokemonIndexItem key={`poke-index-item${poke.id}`} pokemon={poke}/>
      )
    );

    return(
      <div>
      <ul className="poke-list">
        { pokemonItems }
      </ul>
      <Route exact path="/" component={PokemonFormContainer} />

      <Route
           path="/pokemon/:pokemonId"
           component= {PokemonDetailContainer} />

      </div>
    );
  }
}

export default PokemonIndex;

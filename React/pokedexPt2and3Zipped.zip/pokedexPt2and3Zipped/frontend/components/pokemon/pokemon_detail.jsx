import React, { Component } from 'react';
import { Route } from 'react-router-dom';

import Item from '../item/item';
import LoadingIcon from './loading_icon';
import ItemDetailContainer from '../item/item_detail_container';

class PokemonDetail extends Component {
  componentDidMount() {
    this.props.requestSinglePokemon(this.props.match.params.pokemonId);
  }

  componentDidUpdate(prevProps) {
    if (prevProps.match.params.pokemonId !== this.props.match.params.pokemonId) {
      this.props.requestSinglePokemon(this.props.match.params.pokemonId);
    }
  }

  render() {
    const { pokemon, items, loading } = this.props;

    if (loading) {
  return <section className="pokemon-detail"><LoadingIcon /></section>;
}
    console.log(pokemon);
    console.log(items);
    let theItems = [{id: 'none', name: "na"}];
    let defaultItem = {
      happiness: 11,
      id: 4,
      image_url: "/assets/pokemon_berry.svg",
      name: "Berry",
      pokemon_id: 2,
      price: 90
    }

    if (!pokemon ) return null;

    if (!items) {
      theItems= "";
      // return null;

    } else if(items[0] === undefined) {
      theItems= "";
      // return null;

    }
      else {
      console.log(items);

     theItems = items.map(item => (
        <Item key={item.name} item={item}  />
       )
     )

    }


    return (
      <section className="pokemon-detail">
       <h1>Pokemon Details:</h1>
       <img src={pokemon.image_url} alt={pokemon.name} />

       <li>
         <h1>{pokemon.name}</h1>
       </li>
       <li>Type: {pokemon.poke_type}</li>
       <li>Attack: {pokemon.attack}</li>
       <li>Defense: {pokemon.defense}</li>
       <li>Moves: {JSON.parse(pokemon.moves).join(', ')}</li>
       <section className="section-items">
         <h2> Pokemon Items </h2>
         <ul className="ul-list-items">
         {theItems}
         </ul>
         <Route path="/pokemon/:pokemonId/item/:itemId" component={ItemDetailContainer} />
      </section>
      </section>

    );
  }
}

export default PokemonDetail;

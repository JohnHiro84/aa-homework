export const fetchSearch = searchTerm => {
  let thepromise = $.ajax({
    contentType: "application/json",
    method: 'GET',
    url: `http://api.giphy.com/v1/gifs/search?q=${searchTerm}&api_key=j0hkqYIjpTJiauN0En3scOE1bgFnhD5S&limit=2`
  })
  return thepromise;
}

// export default fetchSearchGiphys;



import { createStore, applyMiddleware } from 'redux';
import RootReducer from '../reducers/root_reducer';
import thunk from 'redux-thunk';

const configureStore = () => {
  return createStore(RootReducer, applyMiddleware(thunk));
};


export default configureStore;

//
// import { createStore, applyMiddleware } from 'redux';
// import rootReducer from '../reducers/root_reducer';
//
//
//
// const configureStore = (preloadedState = {}) => {
//   return createStore(
//     rootReducer,
//     preloadedState,
//     applyMiddleware(thunk)
//   );
// }

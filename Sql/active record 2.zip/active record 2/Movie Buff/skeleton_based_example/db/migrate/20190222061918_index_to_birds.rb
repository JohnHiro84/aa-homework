class IndexToBirds < ActiveRecord::Migration[5.0]
  def change
    add_index :birds, :name
  end
end

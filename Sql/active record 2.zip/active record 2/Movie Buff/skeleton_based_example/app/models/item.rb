
class Item < ActiveRecord::Base
  belongs_to :bird,
    primary_key: :id,
    foreign_key: :bird_id,
    class_name: 'Bird'

  has_one :cage,
    through: :bird,
    source: :cage
end

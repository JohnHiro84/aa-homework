require 'securerandom'

class ShortenedUrl < ActiveRecord::Base
  validates :short_url, presence: true, uniqueness: true
  validates :long_url, presence: true, uniqueness: true
  validates :user_id, presence: true

  belongs_to :submitted,
  primary_key: :id,
  foreign_key: :user_id,
  class_name: 'User'

  has_many :visits,
    class_name: 'Visit',
    foreign_key: :shortened_url_id,
    primary_key: :id

  # has_many :visitors,
  #   through: :visits,
  #   source: :user

  has_many :visitors,
    Proc.new { distinct }, #<<<
    through: :visits,
    source: :user

  has_many :tag_topics,
    class_name: 'TagTopic',
    foreign_key: :shortened_url_id,
    primary_key: :id

  def self.random_code
    valid_code = false
    while valid_code == false
      new = SecureRandom.urlsafe_base64
      ShortenedUrl.all.each do |url|
        if url.short_url  == new
          p "new short_url equal to one found in db "
        else
          p "new short_url not equal to one in the db"
          valid_code = true
          new
        end
      end
    end
    new
  end

  def self.create(user_object, input_long_url)
    a = ShortenedUrl.new
    a.user_id = user_object.id
    a.long_url = input_long_url
    a.short_url = ShortenedUrl.random_code
    a.save
  end

  def num_clicks
    self.visits.length
  end

  def num_uniques
    visits.select('user_id').distinct.count
  end

  def num_recent_uniques
    visits
    .select('user_id')
    .where('created_at > ?', 10.minutes.ago)
    .distinct.count
  end

end

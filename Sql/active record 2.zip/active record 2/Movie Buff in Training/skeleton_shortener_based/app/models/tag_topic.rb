class TagTopic < ActiveRecord::Base
  validates :tag, presence: true
  validates :shortened_url_id, presence: true

  belongs_to :shortened_url,
    class_name: 'ShortenedUrl',
    foreign_key: :shortened_url_id,
    primary_key: :id

    def popular_links
      shortened_url.select('tag')
      .where('tag', self.tag)
      .sort_by('DESC')
    end
end

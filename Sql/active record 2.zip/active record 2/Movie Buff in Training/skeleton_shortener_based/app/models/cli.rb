require 'launchy'
require_relative 'user'
require_relative 'visit'
require_relative 'shortened_url'

class CLI

  def login_user!
    puts 'Input your email:'
    @current_user = User.find_by(email: gets.chomp)

    if @current_user.nil?
      raise 'That user doesn\'t exist'
    end

    nil
  end
  def create_url
    puts 'Type in your long url'
    long_url = gets.chomp
    shortened_url = ShortenedUrl.create(
      @current_user,
      long_url
    )

    puts "Short url is: #{shortened_url.short_url}"
  end

  def execute
    login_user!

    puts 'enter a value:'
    puts '1 - create a new url'
    puts '2 - visit url'
    user_input = gets.chomp.to_i

    if user_input = 1
      create_url
    elsif user_input = 2
      visit_url
    end
  end

  def visit_url
    puts 'type in shortened url'
    user_input = gets.chomp
    shortened = ShortenedUrl.find_by('short_url' , user_input)

    Visit.record_visit!(@current_user, shortened)
    Launchy.open("https://www.w3schools.com")
  end

end

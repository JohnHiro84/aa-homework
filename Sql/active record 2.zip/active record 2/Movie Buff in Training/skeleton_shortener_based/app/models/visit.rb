class Visit < ActiveRecord::Base
  validates :user_id, presence: true
  validates :shortened_url_id, presence: true

  # belongs_to :user,
  # primary_key: :id,
  # foreign_key: :user_id,
  # class_name: 'User'
  #
  # belongs_to :shortened_url,
  # primary_key: :id,
  # foreign_key: :shortened_id,
  # class_name: 'ShortenedUrl'

  belongs_to :user,
    class_name: 'User',
    foreign_key: :user_id,
    primary_key: :id

  belongs_to :shortened_url,
    class_name: 'ShortenedUrl',
    foreign_key: :shortened_url_id,
    primary_key: :id

    def self.record_visit!(user_object, shortened_url)
      a = Visit.new
      a.user_id = user_object.id
      a.shortened_url_id = shortened_url.id
      a.save
    end


end

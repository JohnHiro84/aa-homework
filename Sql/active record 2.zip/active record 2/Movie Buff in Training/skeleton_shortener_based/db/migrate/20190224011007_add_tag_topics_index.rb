class AddTagTopicsIndex < ActiveRecord::Migration[5.0]
  def change
    add_index :tag_topics, :shortened_url_id
  end
end

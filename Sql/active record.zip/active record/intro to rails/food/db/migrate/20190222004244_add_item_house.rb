class AddItemHouse < ActiveRecord::Migration[5.0]
  def change
    add_column :houses, :house_id, :integer
  end
end

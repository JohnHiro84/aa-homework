class CreateBirdTable < ActiveRecord::Migration[5.0]
  def change
    create_table :bird_tables do |t|
      t.string :name, null: false
      t.timestamps
      t.string :color
    end
  end
end

class Houses < ActiveRecord::Base
  has_many :birds,
    primary_key: :id,
    foreign_key: :house_id,
    class_name: 'Bird_tables'

  # def bird_tables
  #   Bird_tables.where(house_id: self.id)
  # end
end

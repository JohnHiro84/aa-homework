class Bird < ActiveRecord::Base
  validates :name, presence: true, uniqueness: true
  #validates :color, presence: true
  validate :no_red_birds
  def no_red_birds
    if self.color == "red"
      self.errors[:color] << "can't be red"
    end
  end

  belongs_to :cage, {
    primary_key: :id,
    foreign_key: :cage_id,
    class_name: 'Cage'
  }
  has_many :items,
    primary_key: :id,
    foreign_key: :bird_id,
    class_name: 'Item'

  def self.find_by_color(input_color)
      #find Angelina Jolie by name in the actors table
    Bird.find_by(color: input_color)
  end

  def self.top_3
    Bird.select('id, name, color')
    .where('id < 4')
  end

  def self.top_2_names
    Bird.select('name').order('name DESC').limit(2)
  end


end


class Cage < ActiveRecord::Base

  has_many :birds,
    primary_key: :id,
    foreign_key: :cage_id,
    class_name: 'Bird'

  has_many :items,
    through: :birds, #name of association in this class
    source: :items

  # def items
  #   items = []
  #   self.birds.each do |bird|
  #     items += bird.items
  #   end
  #   items
  # end
end

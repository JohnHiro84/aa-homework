
class Toy < ActiveRecord::Base

end

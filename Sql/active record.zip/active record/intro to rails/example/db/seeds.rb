# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


ranch_house = House.create(type: "Ranch House")
beach_house = House.create(type: "Beach House")

sarah = Cat.create(name: "Sarah", color: "brown", house_id: ranch_house.id)
jack = Cat.create(name: "Jack", color: "orange", house_id: beach_house.id)


Toy.create(name: "Yarn", cat_id: sarah.id)
Toy.create(name: "Squeaker", cat_id: sarah.id)
Toy.create(name: "Feather", cat_id: jack.id)
Toy.create(name: "Ball", cat_id: jack.id)

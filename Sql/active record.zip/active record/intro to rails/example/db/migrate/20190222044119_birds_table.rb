class BirdsTable < ActiveRecord::Migration[5.0]
  def change
    create_table :birds do |t|
      t.string :name, null: false
      t.timestamps
      t.string :color
      t.integer :cage_id
    end
  end
end

class CreateCats < ActiveRecord::Migration[5.0]
  def change
    create_table :cats do |t|
      t.string :name, null: false
      t.timestamps
      t.string :color
      t.integer :house_id
    end
  end
end



create table plays (
  id  INTEGER primary key,
  title TEXT not null,
  year INTEGER not null,
  playwright_id INTEGER not null
  
  FOREIGN KEY (playwright_id) references playwrights(id)
);

create table playwrights (
  id integer primary key,
  name text not null,
  birth_year integer
);


insert into 
  playwrights (name, birth_year)
values
  ('Arthur Miller', 1915),
  ('Eugene O''Neill', 1888);

insert into 
  plays(title, year, playwright_id)
values
  ('All My Sons', 1947, (select id from playwrights where name = 'Arthur Miller'))
  ('Long Day''s Journey Into Night', 1956, (SELECT id from playwrights where name = 'Eugene O''Neill'));
  

require 'sqlite3'
require 'singleton'

class QuestionsDBConnection < SQLite3::Database
  include Singleton

  def initialize
    super('aaquestions.db')
    self.type_translation = true
    self.results_as_hash = true
  end
end



class Question
  attr_accessor :id, :title, :body, :author

  def initialize(options)
    @id = options['id']
    @title = options['title']
    @body = options['body']
    @author = options['author']
  end

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM questions")
    data.map { |datum| Question.new(datum) }
  end

  def create
  raise "#{self} already in database" if self.id
  QuestionsDBConnection.instance.execute(<<-SQL, self.title, self.body, self.author)
    INSERT INTO
      questions (title, body, author)
    VALUES
      (?, ?, ?)
  SQL
  self.id = QuestionsDBConnection.instance.last_insert_row_id
  end


  def update
    raise "#{self} not in database" unless self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.title, self.body, self.author, self.id)
      UPDATE
        questions
      SET
        title = ?, body = ?, author = ?
      WHERE
        id = ?
    SQL
  end

  def self.find_by_id(id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        questions
      WHERE
        id = ?
    SQL
    return nil unless question.length > 0
    Question.new(question.first) # play is stored in an array!
  end

  def self.find_by_author_id(author)
    question = QuestionsDBConnection.instance.execute(<<-SQL, author)
      SELECT
        *
      FROM
        questions
      WHERE
        author = ?
    SQL
    return nil unless question.length > 0
    Question.new(question.first)
  end

  # def author
  #   self.
  # end
  #  Question#replies (use Reply::find_by_question_id)
  def replies
    Reply.find_by_question_id(self.id)
  end


  def followers
    Question_follows.followers_for_question_id(self.id)
  end

  def most_followed(n)
    Question_follows.most_followed_questions(n)
  end

  def likers
    QuestionLike.likers_for_question_id(self.id)
  end

  def num_likes
    QuestionLike.num_likes_for_question_id(self.id)
  end
end





class User
  attr_accessor :id, :fname, :lname

  def initialize(options)
    @id = options['id']
    @fname = options['fname']
    @lname = options['lname']

  end

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM users")
    data.map { |datum| User.new(datum) }
  end

  def create
  raise "#{self} already in database" if self.id
  QuestionsDBConnection.instance.execute(<<-SQL, self.fname, self.lname)
    INSERT INTO
      users (fname, lname)
    VALUES
      (?, ?)
  SQL
  self.id = QuestionsDBConnection.instance.last_insert_row_id
  end


  def update
    raise "#{self} not in database" unless self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.fname, self.lname, self.id)
      UPDATE
        users
      SET
        fname = ?, lname = ?
      WHERE
        id = ?
    SQL
  end


###fixed
  def self.find_by_id(id)
    user = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        users
      WHERE
        id = ?
    SQL
    return nil unless user.length > 0
    User.new(user.first) # play is stored in an array!
  end

###fixed
  def self.find_by_name(fname, lname)
    user = QuestionsDBConnection.instance.execute(<<-SQL, fname, lname)
      SELECT
        *
      FROM
        users
      WHERE
        fname = ? AND lname = ?
    SQL
    return nil unless user.length > 0
    User.new(user.first) # play is stored in an array!
  end
  def authored_questions
    Question.find_by_author_id(self.id)
  end

  def authored_replies
    Reply.find_by_user_id(self.id)
  end

  def followed_questions
    Question_follows.followed_questions_for_user_id(self.id)
  end

  def liked_questions
    QuestionLike.liked_questions_for_user_id(self.id)
  end
end


class Reply
  attr_accessor :id, :reply_question, :reply_user, :parent_reply_id, :body

  def initialize(options)
    @id = options['id']
    @reply_question = options['reply_question']
    @reply_user = options['reply_user']
    @parent_reply_id = options['parent_reply_id']
    @body = options['body']

  end

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM replies")
    data.map { |datum| Reply.new(datum) }
  end

  def create
  raise "#{self} already in database" if self.id
  QuestionsDBConnection.instance.execute(<<-SQL, self.reply_question, self.reply_user, self.parent_reply_id, self.body)
    INSERT INTO
      replies (reply_question, reply_user, parent_reply_id, body)
    VALUES
      (?, ?, ?, ?)
  SQL
  self.id = QuestionsDBConnection.instance.last_insert_row_id
  end


  def update
    raise "#{self} not in database" unless self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.reply_question, self.reply_user, self.parent_reply_id, self.body)
      UPDATE
        replies
      SET
        reply_question = ?, reply_user = ?, parent_reply_id = ?, body = ?
      WHERE
        id = ?
    SQL
  end

  def self.find_by_id(id)
    user = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        replies
      WHERE
        id = ?
    SQL
    return nil unless user.length > 0
    Reply.new(user.first) # play is stored in an array!
  end

  def self.find_by_user_id(reply_user)
    user = QuestionsDBConnection.instance.execute(<<-SQL, reply_user)
      SELECT
        *
      FROM
        replies
      WHERE
        reply_user = ?
    SQL
    return nil unless user.length > 0
    Reply.new(user.first) # play is stored in an array!
  end

  def self.find_by_question_id(reply_question)
    reply = QuestionsDBConnection.instance.execute(<<-SQL, reply_question)
      SELECT
        *
      FROM
        replies
      WHERE
        reply_question = ?
    SQL
    return nil unless reply.length > 0
    Reply.new(reply.first) # play is stored in an array!
  end

  def author
    self.reply_user
  end

  def question
    Question.find_by_id(self.reply_question)
  end

  def parent_reply
    Reply.find_by_id(self.parent_reply_id)
  end

  def child_replies
    Reply.find_by_parent_id(self.id)
  end

  def self.find_by_parent_id(parent_id)
    replies_data = QuestionsDBConnection.instance.execute(<<-SQL, parent_reply_id: parent_id)
      SELECT
        replies.*
      FROM
        replies
      WHERE
        replies.parent_reply_id = :parent_reply_id
    SQL

    replies_data.map { |reply_data| Reply.new(reply_data) }
  end
#  Reply#parent_reply
#  Reply#child_replies #

end

class Question_follows
  attr_accessor :id, :usersid, :questionsid

  def initialize(options)
    @id = options['id']
    @usersid = options['usersid']
    @questionsid = options['questionsid']

  end

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM question_follows")
    data.map { |datum| Reply.new(datum) }
  end

  def create
  raise "#{self} already in database" if self.id
  QuestionsDBConnection.instance.execute(<<-SQL, self.usersid, self.questionsid)
    INSERT INTO
      question_follows (usersid, questionsid)
    VALUES
      (?, ?)
  SQL
  self.id = QuestionsDBConnection.instance.last_insert_row_id
  end


  def self.followers_for_question_id_again(question_id)
    question_following = QuestionsDBConnection.instance.execute(<<-SQL, question_id)
    select usersid, fname, lname from question_follows
    join users on (question_follows.usersid = users.id)
    where questionsid = ?
    SQL
    return nil unless question_following.length > 0
    Question_follows.new(question_following.first) # play is stored in an array!
  end

  def self.followers_for_question_id(question_id)
    users_data = QuestionsDBConnection.instance.execute(<<-SQL, question_id: question_id)
      SELECT
        users.*
      FROM
        users
      JOIN
        question_follows
      ON
        users.id = question_follows.usersid
      WHERE
        question_follows.questionsid = :question_id
    SQL
    users_data.map { |user_data| User.new(user_data) }
  end

  def self.followed_questions_for_user_id(user_id)
    questions_data = QuestionsDBConnection.instance.execute(<<-SQL, user_id: user_id)
    select questions.* from
      question_follows join questions
      on (question_follows.questionsid = questions.id)
      where question_follows.usersid = :user_id
    SQL
    questions_data.map { |questions_data| Question.new(questions_data) }
  end

  def self.most_followed_questions(n)
    questions_data = QuestionsDBConnection.instance.execute(<<-SQL, n: n)

  select questions.*
    from question_follows
    join questions on (question_follows.questionsid = questions.id)
    group by questionsid
    order by count(questionsid) desc
    limit :n;
  SQL
    questions_data.map { |questions_data| Question.new(questions_data) }
  end

end
  class QuestionLike
    attr_accessor :id, :user_likes, :question_likes

    def initialize(options)
      @id = options['id']
      @user_likes = options['user_likes']
      @question_likes = options['question_likes']

    end

    def self.all
      data = QuestionsDBConnection.instance.execute("SELECT * FROM question_likes")
      data.map { |datum| QuestionLike.new(datum) }
    end

    def self.likers_for_question_id(question_id)
      users_data = QuestionsDBConnection.instance.execute(<<-SQL, question_id: question_id)

    select users.*
      from question_likes
      join users on (question_likes.user_likes = users.id)
      where question_likes.question_likes = :question_id
    SQL
      users_data.map { |user_data| User.new(user_data) }
    end

    def self.num_likes_for_question_id(question_id)
      users_data = QuestionsDBConnection.instance.execute(<<-SQL, question_id: question_id)
      select question_likes, count(question_likes)
        from question_likes
        where question_likes.question_likes = :question_id
      SQL
      users_data[0][1]
      #.map { |user_data| User.new(user_data) }
    end

    def self.liked_questions_for_user_id(user_id)
      questions_data = QuestionsDBConnection.instance.execute(<<-SQL, user_id: user_id)
      select questions.* from
        question_likes join questions on (question_likes.question_likes = questions.id)
        where question_likes.user_likes = :user_id
      SQL
      questions_data.map { |user_data| Question.new(user_data) }
    end
  end

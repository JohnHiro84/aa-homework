PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS question_follows;
DROP TABLE IF EXISTS replies;
DROP TABLE IF EXISTS question_likes;

-- PRAGMA foreign_keys = ON;

CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  fname TEXT NOT NULL,
  lname TEXT NOT NULL
);



INSERT INTO
  users (fname, lname)
VALUES
  ("bobby", "brown"),
  ("adam", "ant"),
  ("cleatus", "charlie"),
  ("lena", "landsky");



CREATE TABLE questions (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  author TEXT NOT NULL,
  FOREIGN KEY (author) REFERENCES users(id)
);


INSERT INTO
  questions (title, body, author)
VALUES
  ('how do I create a sql table', 'My question begins with...', (SELECT id FROM users WHERE id = 1)),
  ('I''ve seeded my db', 'with sql and ...', (SELECT id FROM users WHERE id = 2));





CREATE TABLE question_follows (
  id INTEGER PRIMARY KEY,
  usersid INTEGER NOT NULL,
  questionsid INTEGER NOT NULL,
  FOREIGN KEY (usersid) REFERENCES users(id),
  FOREIGN KEY (questionsid) REFERENCES questions(id)
);


INSERT INTO
  question_follows (usersid, questionsid)
VALUES
  ((SELECT id FROM users WHERE fname = "adam" AND lname = "ant"),
  (SELECT id FROM questions WHERE title = 'I''ve seeded my db')),

  ((SELECT id FROM users WHERE fname = "bobby" AND lname = "brown"),
  (SELECT id FROM questions WHERE title = "how do I create a sql table"));



CREATE TABLE replies (
  id INTEGER PRIMARY KEY,
  reply_question INTEGER NOT NULL,
  reply_user INTEGER NOT NULL,
  parent_reply_id INTEGER,
  body TEXT NOT NULL,

  FOREIGN KEY (reply_question) REFERENCES questions(id),
  FOREIGN KEY (reply_user) REFERENCES users(id),
  FOREIGN KEY (parent_reply_id) REFERENCES replies(id)
);


INSERT INTO
  replies(reply_question, reply_user, parent_reply_id, body)
VALUES
  ((SELECT id FROM questions WHERE title = 'I''ve seeded my db'),
  (SELECT id FROM users WHERE fname = "adam" AND lname = "ant"),
  NULL,
  "hey! first to comment! great!");

INSERT INTO
  replies(reply_question, reply_user, parent_reply_id, body)
VALUES

  ((SELECT id FROM questions WHERE title = 'I''ve seeded my db'),
  (SELECT id FROM users WHERE fname = "bobby" AND lname = "brown"),
  (SELECT id FROM replies WHERE id = 1),
  "second comment here");

  INSERT INTO
    replies(reply_question, reply_user, parent_reply_id, body)
  VALUES

    ((SELECT id FROM questions WHERE title = 'I''ve seeded my db'),
    (SELECT id FROM users WHERE fname = "lena" AND lname = "landsky"),
    (SELECT id FROM replies WHERE id = 1),
    "looks like i'm third. woop woop");

CREATE TABLE question_likes(
  id INTEGER PRIMARY KEY,
  user_likes INTEGER NOT NULL,
  question_likes INTEGER NOT NULL,

  FOREIGN KEY (user_likes) REFERENCES users(id),
  FOREIGN KEY (question_likes) REFERENCES questions(id)
);

INSERT INTO
  question_likes (user_likes, question_likes)
VALUES
  ((SELECT id FROM users WHERE fname = "lena" AND lname = "landsky"),
  (SELECT id FROM questions WHERE title = 'I''ve seeded my db'));

--thier solution
-- CREATE TABLE replies (
--   id INTEGER PRIMARY KEY,
--   question_id INTEGER NOT NULL,
--   parent_reply_id INTEGER,
--   author_id INTEGER NOT NULL,
--   body TEXT NOT NULL,
--   FOREIGN KEY (question_id) REFERENCES questions(id),
--   FOREIGN KEY (parent_reply_id) REFERENCES replies(id),
--   FOREIGN KEY (author_id) REFERENCES users(id)
-- );
--
-- INSERT INTO
--   replies (question_id, parent_reply_id, author_id, body)
-- VALUES
--   (1,
--   NULL,
--   1,
--   "Did you say NOW NOW NOW?"
-- );
--
-- INSERT INTO
--   replies (question_id, parent_reply_id, author_id, body)
-- VALUES
--   (2,
--   1,
--   2,
--   "I think he said MEOW MEOW MEOW."
-- );

------

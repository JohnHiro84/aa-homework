class AttrAccessorObject

  def self.my_attr_accessor(*names)
    names.each do |name|
      define_method(name) do
        instance_variable_get("@#{name}")
      end

      define_method(name) do |value|
        instance_variable_set("#{name}=", value)
      end
    end
  end

  #
  # def initialize(name, color)
  #   @name = name
  #   @color = color
  # end

end
    # def define_method(*names)
    #
    # end
    #   define_method(:get) {self.instance_variable_get(name) }
    #   define_method(:set) {self.instance_variable_set(name) }

      #
      # if names.include?("get")
      #   define_method(:get) {self.instance_variable_get(variable) }
      # elsif names.include?("set")
      #   define_method(:set) {self.instance_variable_set(variable) }
      # end
    # end
  #end

  # def self.my_attr_accessor(*names)
  #   names.each do |name|
  #     define_method(name) do
  #       instance_variable_get("@#{name}")
  #     end
  #
  #     define_method("#{name}=") do |value|
  #       instance_variable_set("@#{name}", value)
  #     end
  #   end
  # end
#end

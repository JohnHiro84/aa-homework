function factorial( n ) {
  if ( n === 1 ) {
    return 1;
  }
  return n * factorial( n - 1 );
}

function range(start, end){
  console.log(end);

  let array = [];
  if (start === end){
    return end;
  } else {
    array.push(end);
    return array.concat(range(start, end-1));
  }
}

range(1,10);




// sumRec(arr) - receives an array of numbers and
// recursively sums them

function sumRec(arr){
  sum = 0;
  if (arr.length === 1){
    return arr[0];
  } else {
    sum+=arr.pop()
    return sum + sumRec(arr);
  }
}
sumRec([1,2,3,4,5,6,7]);


function exponent(base, exp){
  let output = 0;
  if(exp === 1){
    return base;
  } else {

    output = base;
    console.log(output);
    return output * exponent(base,(exp-1));
  }
}
exponent(2, 3);


function fibonacci(n){
  let arr;
  if (n ===1){
    arr = [1];
  } else if (n === 2){
    arr = [1,1];
  } else if (n > 2){
    let start = n -2;
    let arr = [1,1];
    for (i=start;i < arr.length; i++){
        arr.push(arr[arr.length-1] + arr[arr.length-2]);
    }
  }
  return arr;
}

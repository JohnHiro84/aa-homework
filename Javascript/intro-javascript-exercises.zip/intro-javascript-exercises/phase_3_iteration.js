// bubble sort

let array = [1,5,2,7,3,8];

function bubbleSort(array){
  let changes = 10;
  while (changes > 0){
    changes = 0;
    console.log("changes:" + changes);
    for(i = 0; i< (array.length -1); i++){
      let j = i + 1;
      console.log(array[i] + "<-i, j->" + array[j]);
      if (array[j] < array[i]){
        let first = array[i];
        let second = array[j];
        array[i] = second;
        array[j] = first;
        changes+=1;
        console.log("changes:" + changes);
      }
    }
  }
  return array;
}

bubbleSort(array);



// substrings

function substrings(string){
  let output = [];
  for (i=0; i< str.length; i++){
    for(j =0; j< str.length + 1; j++){
      if (str.slice(i, j).length > 0){
      output.push(str.slice(i, j));        
      }
    }
  }
  return output;
}

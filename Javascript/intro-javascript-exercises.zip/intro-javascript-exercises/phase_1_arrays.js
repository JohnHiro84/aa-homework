// part 1
Array.prototype.uniq = function() {
    let uniqueElements = [];

    for (i = 0; i < this.length; i++){
      if (uniqueElements.includes(this[i]) === false) {
        uniqueElements.push(this[i]);
      }
    }
    return uniqueElements;
}

// Array#twoSum - returns an array of position pairs where the elements sum to zero

Array.prototype.twoSum = function() {
  let masterOutput = [];

  for (i = 0; i < this.length; i++){

    for (j = 0; j < this.length; j++){
      if (this[i] + this[j] === 0) {
        if( i < j){
          masterOutput.push([i, j]);
        }
      }
    }
  }
  return masterOutput;
}

// Array#transpose - where we have a two-dimensional array representing a matrix. returns the transpose

Array.prototype.transpose = function() {
  let output = [];

  // if (this.length > this[0].length){

    for( j =0; j< this.length; j++){
      let pair = [];
      for (i=0; i< this.length; i++){
        pair.push(this[i][j]);
      }
      output.push(pair);
    }
  return output;
}

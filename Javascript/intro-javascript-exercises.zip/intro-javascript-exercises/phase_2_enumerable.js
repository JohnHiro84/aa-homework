
// phase 2

// Array#myEach(callback) - receives a callback function and executes the callback for
 // each element in the array
array = [1,2,3,4,5];

cb = function(ele){
  // mapped.push(ele + 100);
  console.log(ele);
  return (ele + 100);
 }

Array.prototype.myEach = function(cbfunction) {
  // this.forEach(cbfunction);
  // mapped = [];
  for (i = 0; i< this.length; i++){
    cbfunction(this[i]);
  }
  // return mapped;
}
array.myEach(cb);

// Array#myMap(callback) - receives a callback function, returns a new array of
// the results of calling the callback function on each element of the array
// should use myEach and a closure

array = [1,2,3,4,5];

cbmapped = function(ele){
  mapped.push(ele + 100);
  console.log(ele);
  return (ele + 100);
 }

Array.prototype.myMap = function(cbfunction) {
  // this.forEach(cbfunction);
  mapped = [];
  for (i = 0; i< this.length; i++){
    cbfunction(this[i]);
  }
  return mapped;
}
array.myMap(cbmapped);


// Array#myReduce(callback[, initialValue]) - (like Ruby's Array#inject) receives a
// callback function, and optional initial value, returns an accumulator by applying
//  the callback function to each element and the result of the last invocation of
//  the callback (or initial value if supplied)

// experiement

array = [1,2,3,4,5];

cb_summer = function(ele){
  sum_value+= ele;
 }

Array.prototype.myReduce = function(cbfunction, initial_val) {
  sum_value = 0;
  if (initial_val){
    sum_value = initial_val;
  }

  for (i = 0; i< this.length; i++){
    cbfunction(this[i]);
  }
  return sum_value;
}
array.myReduce(cb_summer, 5 );

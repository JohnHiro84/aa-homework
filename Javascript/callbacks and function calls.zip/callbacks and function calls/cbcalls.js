const readline = require('readline');

const reader = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function addTwoNumbers(callback) {

  reader.question("Would you like some tea?", function (res1) {
    console.log(res1);
    reader.question("Would you like some biscuits?", function (res2) {
      output = (`So you ${res1} want tea and you ${res2} want coffee.`)
      console.log("");
      callback(output);
    });
  });
}

addTwoNumbers(function (result) {
  console.log(result);

  reader.close();
});
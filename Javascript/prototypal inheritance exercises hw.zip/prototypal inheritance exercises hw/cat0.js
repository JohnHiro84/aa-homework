
function Animal(name) {
  this.name = name;
}

Animal.prototype.eat = function() {
  console.log("mmm food");
};

var Cat = function(name){
  Animal.call(this, name);
};



var inherits = function(parent, child){
  var Surrogate = function(){};
  Surrogate.prototype = parent.prototype;
  child.prototype = new Surrogate();
  child.prototype.constructor = child;

};

inherits(Animal, Cat);


Cat.prototype.meow = function() {
  console.log("moew" + this.name);
};


/////////////movingObject
function MovingObject (name) {
  this.name = name;
}
MovingObject.prototype.speed = function() {
  console.log("wow moving so fast!");
};

//////////////ship
function Ship (name) {
  this.name = (this, name);
}

Ship.prototype = Object.create(MovingObject.prototype)
Ship.prototype.constructor = Ship
// inherits(MovingObject, Ship);

Ship.prototype.crew = function() {
  console.log("captain and 4 others");
};

////////////////////asteroid
function Asteroid () {}

// inherits(MovingObject, Asteroid);
Asteroid.prototype = Object.create(MovingObject.prototype)
Asteroid.prototype.constructor = Asteroid

Asteroid.prototype.direction = function() {
  console.log("heading north!");
};

// c = new Cat("gggg");
// console.log(c.name);
// console.log(c.meow());
// console.log(c.eat());
// console.log();
// module.exports = Cat;

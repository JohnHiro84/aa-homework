
function Animal(name) {
  this.name = name;
}

Animal.prototype.eat = function() {
  console.log("mmm food");
};

var Cat = function(name){
  Animal.call(this, name);
};



var inherits = function(parent, child){
  var Surrogate = function(){};
  Surrogate.prototype = parent.prototype;
  child.prototype = new Surrogate();
  child.prototype.constructor = child;

};

inherits(Animal, Cat);


Cat.prototype.meow = function() {
  console.log("moew" + this.name);
};



function MovingObject (name, position) {
  this.name = name;
  this.position = position;
}

MovingObject.prototype.move = function(direction){
  let coordinateX = this.position[0];
  let coordinateY = this.position[1];
  if(direction === "down"){
    coordinateY +=1;
  }
  else if (direction === "up"){
    coordinateY -=1;
  }
  else if(direction === "left"){
    coordinateX -=1;
  }
  else if (direction === "right"){
    coordinateX +=1;
  }
  this.position = [coordinateX, coordinateY];
}

MovingObject.prototype.speed = function() {
  console.log("wow moving so fast!");
};


function Ship (name) {
  this.name = (this, name);
}
Ship.inherits(MovingObject);
inherits(MovingObject, Ship);

Ship.prototype.crew = function() {
  console.log("captain and 4 others");
};

function Asteroid () {}
inherits(MovingObject, Asteroid);

Asteroid.prototype.direction = function() {
  console.log("heading north!");
};

c = new Cat("gggg");
console.log(c.name);
console.log(c.meow());
console.log(c.eat());
console.log();
module.exports = Cat;

document.addEventListener("DOMContentLoaded", function(){
  // const canvas = document.getElementById('mycanvas');
  // const ctx = canvas.getContext('2d');
  // ctx.fillStyle = "#FF0000";
  // ctx.strokeRect(0, 0, 500, 500);


var canvas = document.getElementById("mycanvas");
var ctx = canvas.getContext("2d");
// ctx.fillStyle = "red";
// ctx.fillRect(20, 20, 150, 75);
//

ctx.beginPath();
ctx.arc(99, 99, 50, 0, 2 * Math.PI);
ctx.lineWidth = 10;
ctx.strokeStyle = "yellow";
ctx.stroke();
ctx.fillStyle = "green";
ctx.fill();

ctx.beginPath();
ctx.moveTo(275, 250);
ctx.lineTo(200, 275);
ctx.lineTo(200, 225);
ctx.fill();

});

function sum(arg1, arg2) {
  let sum = 0;

  for (let i = 0; i < arguments.length; i++) {
    sum+=Number(arguments[i]);
  }

  return sum
}

sum(2,3,4,53);

function addit(...otherArgs) {
  let sum = 0;

  otherArgs.forEach((arg) => {
    sum+=(Number(arg));
  });
  return sum;
}
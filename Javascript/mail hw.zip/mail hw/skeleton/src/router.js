function Router(node, routes){
  this.node = node;
  this.routes = routes;

}

Router.prototype.activeRoute = function(){
  console.log("active ran");
  // console.log(this.activeRoute());
  hashfrag = window.location.hash;

  arr = hashfrag.split("");
  arr.shift();
  console.log(arr)
  frag = arr.join("");
  // console.log(this.routes[frag]);
  // return this.routes[frag];
  this.node = frag;
  console.log(this.node)
  return frag;
}

Router.prototype.render = function(){
  console.log("render function ran");
  // console.log(window.location.hash);
  // this.activeRoute();
  ptag = document.createElement("p");

  let the_active_route = this.activeRoute();
  ptag.innerHTML = the_active_route;

  component = the_active_route;

  if( component === undefined){
    this.node.innerHTML = "";
  } else {
    this.node.innerHTML = "";
    component.render()
  }
  // console.log(this.activeRoute());
  this.node.appendChild(ptag);
}


// Router.prototype.start = function(){
//   // this.render();
//   // window.onhashchange = this.render();
// }

//
Router.prototype.start = function(){
  // this.render();

  window.addEventListener('hashchange', function (evt) {
    console.log(`The hash is now: ${window.location.hash}`);
    firstRouter.render();
    // this.render();
  }, false);
  // window.addEventListener('onhashchange', function(evt) {
  //   console.log("hash changed");
  //   window.location.hash = this.innerText.toLowerCase();
  //   console.log(window.location.hash);
  //
  //   firstRouter.render();
  //
  // }, false);
}

//
// Router.prototype.activeRoute = function(){
//   hashfrag = window.location.hash;
//   arr = hashfrag.split("");
//   arr.shift();
//   frag = arr.join("");
//   return this.routes[frag];
// }

module.exports = Router;

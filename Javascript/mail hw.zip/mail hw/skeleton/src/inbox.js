function Inbox(node){
  this.node = node;

}

Inbox.prototype.render = function() {
  node = document.createElement("ul");
  node.className = "container";
  node.innerHTML = "Inbox Message";
  // document.getElementsByTagName("body").append(node);
}

module.exports = Inbox;

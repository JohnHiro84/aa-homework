Router = require("./router.js")
Inbox = require("./inbox.js");

document.addEventListener("DOMContentLoaded", function(event) {


    routes = {
      "inbox": Inbox
    };

  content = document.querySelector(".content");
  firstRouter = new Router(content, routes);
  firstRouter.start();

  nav = document.getElementsByClassName("sidebar-nav");
  arrayli = nav[0].children;

  arrayli[0].addEventListener('click', function(evt) {
    console.log("click");
    window.location.hash = this.innerText.toLowerCase();
    console.log(window.location.hash);
    firstRouter.render();
  }, false);



  arrayli[1].addEventListener('click', function(evt) {
    console.log("click");
    window.location.hash = this.innerText.toLowerCase();
    console.log(window.location.hash);

    firstRouter.render();

  }, false);

  arrayli[2].addEventListener('click', function(evt) {
    console.log("click");
    window.location.hash = this.innerText.toLowerCase();
    console.log(window.location.hash);

    firstRouter.render();
  }, false);

    //
    // // console.log(li);
    // arrayli[0].addEventListener('click', function(evt) {
    //   console.log("click");
    //   window.location.hash = this.innerText.toLowerCase();
    // }, false);


      // window.onhashchange = firstRouter.render();

      // b = document.getElementsByTagName("body");
      // b[0].addEventListener('onhashchange', function(evt){
      //   console.log("hash changed")
      // }, false )

});

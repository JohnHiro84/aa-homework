const View = require("./ttt-view.js");
const Game = require("./game.js");

window.ttt;
window.view = new View;
  $(() => {
    // Your code here
    window.ttt = $(".ttt");
    // $(".ttt").attr("style", "background-color: red");
    view.setupBoard();


      $("li").on("click", event => {

        if(view.game.isOver() === false){
          console.log("click")
          const $cell_Li = $(event.currentTarget);
          console.log($cell_Li);
          $cell_Li.addClass(`player_${view.game.currentPlayer}`);

          const cell = $cell_Li.data("cell");
          console.log(cell);
          pos = cell.split(",");
          view.bindEvents([Number(pos[0]), Number(pos[1])]);
          // alert(cell.pos + " loves you!");
          console.log(view.game.currentPlayer);
          console.log(view.game.isOver());
        }

        if(view.game.isOver() === true){
          alert(`${view.game.winner()} is the winner!!!`);
        }
      });



  });

  $( () => {
    $("p").attr("style", "background-color: red");
  });

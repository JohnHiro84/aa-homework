const Game = require("./game.js");


class View {
  constructor(game) {
    this.game = new Game;
    this.el = window.ttt;
  }

  bindEvents() {}

  makeMove($square) {}

  // setupBoard() {}
}


View.prototype.setupBoard = function(){
  pos = [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[2,2]];
  console.log("view.prototype.setup..");
  const ul = document.createElement("ul");
  ul.className = "ul-flex";
  for(i = 0; i< 9; i++){
  li = document.createElement("li");
  li.textContent = ("");
  li.className = "li-flex";
  // li.setAttribute("data-cell", `{ pos: ${pos[i]} }`);
  li.setAttribute("data-cell", `${pos[i]} `);

  ul.append(li);
}

  ttt.append(ul);
}
View.prototype.bindEvents = function(pos) {
  // console.log(this.game.playMove);
  this.game.playMove(pos);

}

module.exports = View;

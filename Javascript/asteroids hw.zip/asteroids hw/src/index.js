var Hi = require("./game.js");
var Asteroid = require('./asteroid.js');
var MovingObject = require('./moving_object.js');
var Util = require("./util.js");

// var canvas = document.getElementById("game-canvas");
// var ctx = canvas.getContext("2d");

Util.inherits(Asteroid, MovingObject );

// Hi();
console.log("Webpack is working!");

window.MovingObject = MovingObject;
window.Asteroid = Asteroid;


// function CreateCtx() {
//   var canvas = document.getElementById("game-canvas");
//   var ctx = canvas.getContext("2d");
//   this.ctx = ctx;
// }
// window.ctx = CreateCtx();




window.canvas = "";
window.ctx = "";

window.addEventListener('DOMContentLoaded', (event) => {
    console.log('DOM fully loaded and parsed');
    window.canvas = document.getElementById("game-canvas");
    window.ctx = canvas.getContext("2d");

});
a = new MovingObject(
  { pos: [30, 30], vel: [10, 10], radius: 5, color: "#00FF00"}
);

b = new Asteroid(
  { pos: [30, 30], vel: [10, 10], radius: 5, color: "#00FF00"}
);

console.log(a);
console.log(b);

Util.inherits(Asteroid, MovingObject);
console.log(Util.inherits);

// var Canvas = require("./index.js");


// Base class for anything that moves.
// Most important methods are MovingObject.prototype.move,
// MovingObject.prototype.draw(ctx),
// MovingObject.prototype.isCollidedWith(otherMovingObject).


function MovingObject(option) {
  this.pos = option.pos;
  this.vel = option.vel;
  this.radius = option.radius;
  this.color = option.color;
  console.log(option);
}

MovingObject.prototype.draw = function(ctx) {
  // var canvas = document.getElementById("game-canvas");
  // var ctx = canvas.getContext("2d");
  ctx.fillStyle = this.color;
  ctx.beginPath();
  ctx.arc(this.pos[0],this.pos[1], this.radius, 0*Math.PI, 2*Math.PI);
  ctx.strokeStyle = this.color;
  ctx.fillStyle = this.color;
  ctx.fill();

}
//
MovingObject.prototype.move = function(ctx) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // circle();
  // requestAnimationFrame(draw);
  this.pos[0]+= this.vel[0];
  this.pos[1]+= this.vel[1];
  this.draw(ctx);

}

// var canvas = document.getElementById("game-canvas");
// var ctx = canvas.getContext("2d");
// ctx.fillStyle = "#FF0000";
// ctx.fillRect(0,0, 400,400);

module.exports = MovingObject;

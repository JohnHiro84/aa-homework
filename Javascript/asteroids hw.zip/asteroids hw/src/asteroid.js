// var MovingObject = require('./moving_object.js')
// var Util = require("./util.js");


function Asteroid(option) {
  this.pos = option.pos;
  this.vel = option.vel;
  this.radius = 35;
  this.color = "blue";
  console.log(option);
}


module.exports = Asteroid;

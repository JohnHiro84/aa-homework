
// ctx.fillStyle = "#FF0000";
// ctx.fillRect(0,0, 400,400);

// module.exports = Canvas;

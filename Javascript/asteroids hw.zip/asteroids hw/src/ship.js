    // This is you! Another MovingObject subclass.

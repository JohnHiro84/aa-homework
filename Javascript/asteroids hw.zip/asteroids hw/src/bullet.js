    // Kill spacerocks with this. Also a MovingObject subclass.

function timer() {
  setInterval(function(){
  var d = new Date();
  h = d.getHours(); // => 9
  m = d.getMinutes(); // =>  30
  s = d.getSeconds(); //
  console.log(h + ":" + m + ":" + s);
  }, 1000);
}

//timer()


class Clock {
  constructor() {
    this.d = new Date();
    this.h = this.d.getHours();
    this.m = this.d.getMinutes();
    this.s = this.d.getSeconds();

    // 3. Call printTime.
    this.printTime();
    // 4. Schedule the tick at 1 second intervals.
    this._tick(this.s, this.m, this.h);
  }

  printTime() {
    // Format the time in HH:MM:SS
    // Use console.log to print it.
    console.log(this.h + ":" + this.m + ":" + this.s);
  }

  _tick(sec, min, hour) {
    // 1. Increment the time by one second.
    console.log('tick');
  setInterval(
    function(printTime){
      // console.log(sec);
      if (sec == 60) {
        min+=1;
        sec = 0;
      }
      console.log(hour + ":" + min + ":" + sec);
            sec+=1;
      // this.printTime();

    }, 1000
  );

    // 2. Call printTime.
   this.printTime()
  }
}

// const clock = new Clock();




///////////////////////////////////////////////////addNumbers

const readline = require('readline');

const reader = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function addTwoNumbers(callback) {
  // Notice how nowhere do I return anything here! You never return in
  // async code. Since the caller will not wait for the result, you
  // can't return anything to them.

  reader.question("Enter #1: ", function (numString1) {
    reader.question("Enter #2: ", function (numString2) {
      const num1 = parseInt(numString1);
      const num2 = parseInt(numString2);

      callback(num1 + num2);
    });
  });
}

addTwoNumbers(function (result) {
  console.log(`The result is: ${result}`);
  reader.close();
});

function addNumbers(sum, numsLeft, completionCallback){

    if (numsLeft > 0 ){
      reader.question("Enter a number: ", function (numString1) {
        const num1 = parseInt(numString1);
        sum += num1;
        console.log(sum);

        addNumbers(sum,(numsLeft-1), completionCallback);
      });

    } else if (numsLeft === 0){
      completionCallback(sum);
      reader.close();
    }

}

// addNumbers(0, 3 , function (result) {
//   console.log(`The result is: ${result}`);
//   // reader.close();
// });

addNumbers(0, 3, sum => console.log(`Total Sum: ${sum}`));

document.addEventListener("DOMContentLoaded", () => {
  // toggling restaurants

  const toggleLi = (e) => {
    const li = e.target;
    if (li.className === "visited") {
      li.className = "";
    } else {
      li.className = "visited";
    }
  };

  document.querySelectorAll("#restaurants li").forEach((li) => {
    li.addEventListener("click", toggleLi);
  });


  const favInputEl = document.getElementById("add-place");
  favInputEl.addEventListener("submit", event => {

    event.preventDefault();


    const fav_input = document.getElementById("fav-input")
    const placeName = fav_input.value;
    fav_input.value = "";


    // Get the ul of cats.
    const ul = document.getElementById("sf-places");
    // create an li element


    const li = document.createElement("li");
    // set the text of the li to be the value of the input field
    li.textContent = placeName;

    // insert it as the last item in the ul.
    ul.appendChild(li);
  });

  // adding SF places as list items

  // --- your code here!



  // adding new photos

  // --- your code here!

    const photoform = document.getElementsByClassName("photo-form-container");
    const aphotobutton = document.getElementsByClassName("photo-show-button");
    const thephotoform = document.getElementById("photo");

    aphotobutton[0].addEventListener("click", event => {
      event.preventDefault();
      console.log(photoform[0].className);
      console.log("clicked");
      if (photoform[0].className === "photo-form-container") {
         console.log("not hidden");
         photoform[0].className = "photo-form-container hidden";
      } else if (photoform[0].className === "photo-form-container hidden") {
        console.log("hidden");
        photoform[0].className = "photo-form-container";
      }
  });


    //
    //   const fav_input = document.getElementById("fav-input")
    //   const placeName = fav_input.value;
    //   fav_input.value = "";
    //
    //
    //   // Get the ul of cats.
    //   const ul = document.getElementById("sf-places");
    //   // create an li element
    //
    //
    //   const li = document.createElement("li");
    //   // set the text of the li to be the value of the input field
    //   li.textContent = placeName;
    //
    //   // insert it as the last item in the ul.
    //   ul.appendChild(li);


      const photoEle = document.getElementById("photo");
      photoEle.addEventListener("submit", event => {

        event.preventDefault();

        const addphoto = document.getElementById("photoadd")
        const photourl = addphoto.value;
        addphoto.value = "";


        // Get the ul of cats.
        const ul = document.getElementsByClassName("dog-photos");


        var x = document.createElement("IMG");
        x.setAttribute("src", photourl);

        const li = document.createElement("li");
        li.appendChild(x);

        ul[0].appendChild(li);
      });


});

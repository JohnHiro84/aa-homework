
const DOMNodeCollection = require("./dom_node_collection.js");

console.log(DOMNodeCollection)

$l = function(arg){
  console.log(arg);
  let array = [];
  if (arg instanceof HTMLElement === true){
    array.push(arg);
    return new DOMNodeCollection(array);
  } else {
    elementList = document.querySelectorAll(arg);
    let array = Array.prototype.slice.call(elementList);
    // console.log(array[0] instanceof HTMLElement);
    // return array;
    return new DOMNodeCollection(array);
  }

}

window.DOMNodeCollection = DOMNodeCollection;

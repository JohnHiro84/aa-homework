class DOMNodeCollection {
  constructor(array) {
    this.array = array;
    this.innerHTML = "";
  }
}

DOMNodeCollection.prototype.html = function(string) {
  if(string){
    console.log("str present");
     this.innerHTML = string;
  } else {
    console.log("not present")
    return this.innerHTML = this.array[0];
  }
}

DOMNodeCollection.prototype.empty = function() {
  this.array = [];
  this.innerHTML = "";
}
//ul.append(li)

DOMNodeCollection.prototype.append = function(args) {
  oldarray = this.array;
  newarray = []
  //
  // for(i in args){
  //   console.log(args[i].array);
  //   for (j in args[i].array){
  //     console.log(args[i].array[j]);
  //   }
  // }
  //
  //
  for (i in oldarray){
    for (j in args){
      oldarray[i].innerHTML += args[j].outerHTML;
    }
  }
  return oldarray;
  // args.forEach( function(item){
  //
  //   oldarray.forEach( function(ele){
  //
  //     console.log("11111" + ele);
  //     console.log("11111" + item);
  //     ele.innerHTML = (ele.innerHTML + item.outerHTML);
  //     newarray.push(ele);
  //   })
  //   console.log(item);
  // })
  // this.array = newarray;

}

DOMNodeCollection.prototype.attr = function(arg1, arg2) {
  oldarray = this.array;
  for (i in oldarray){
    oldarray[i].setAttribute(arg1, arg2);
  }
  // arg1 = "class"
  // arg2 = "className"
}

DOMNodeCollection.prototype.addClass = function(arg2) {
  oldarray = this.array;
  for (i in oldarray){
    oldclass = oldarray[i].className;
    // console.log(oldclass);
    totalclass = (oldclass + " " + arg2);
    oldarray[i].setAttribute("class", totalclass);
  }
  // arg1 = "class"
  // arg2 = "className"
}



DOMNodeCollection.prototype.removeClass = function(arg2) {
  oldarray = this.array;
  for (i in oldarray){
    oldclass = oldarray[i].className;

    classarray = oldclass.split(" ");

    if (classarray.includes(arg2) === true) {
      var index = classarray.indexOf(arg2);
      if (index !== -1) classarray.splice(index, 1)
    }
    newarray = classarray.join(" ");

    // totalclass = (oldclass + " " + arg2);
    oldarray[i].setAttribute("class", newarray);
  }

}
DOMNodeCollection.prototype.children = function() {
  oldarray = this.array;
  childs = [];
  for(i in oldarray) {
    for(child in oldarray[i].children) {
      if(typeof oldarray[i].children[child] !== "number" && typeof oldarray[i].children[child] !== "function" )
      childs.push(oldarray[i].children[child]);
    }

  }
  return childs;
}

DOMNodeCollection.prototype.parent = function() {
  oldarray = this.array;
  parents = [];
  for(i in oldarray) {
    parents.push(oldarray[i].parentElement);
    // for(child in oldarray[i].parentElement) {
    //
    //   if(typeof oldarray[i].children[child] !== "number" && typeof oldarray[i].children[child] !== "function" )
    //   childs.push(oldarray[i].children[child]);
    // }

  }
  return parents;
}
DOMNodeCollection.prototype.find = function(selector) {
  return $l(selector);
}

DOMNodeCollection.prototype.on = function(action, cb ) {
  oldarray = this.array;
  for(i in oldarray){
    oldarray[i].addEventListener(action, cb);
  }
}
DOMNodeCollection.prototype.off = function(action, cb ) {
  oldarray = this.array;
  for(i in oldarray){
    oldarray[i].removeEventListener(action, cb);
  }
}


module.exports = DOMNodeCollection;

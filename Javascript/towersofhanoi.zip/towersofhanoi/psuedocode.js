function Game(){

}

Game.prototype.run = function() {
// until a player is in checkmate
  // get move from current player
  // make move on board
  // switch current player
}

  //
  // class Chess {
  //   run() {
  //
  //   }
  // }

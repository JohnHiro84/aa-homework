const readline = require('readline');

const reader = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function Game(){
  this.stacks = [[3,2,1],[], []];
}


Game.prototype.promptMove = function (callback){
    console.log(this.stacks);
    reader.question("What tower do you want to move from?: ", function (from_tower) {
      reader.question("What tower do you want to move to?: ", function (to_tower) {
        const tower1 = parseInt(from_tower);
        const tower2 = parseInt(to_tower);

        callback(tower1, tower2);
      });
    });
}

Game.prototype.isValidMove = function (from_tower, to_tower){

  if (this.stacks[from_tower] === undefined || this.stacks[to_tower] === undefined){
    console.log("false");
    return false;
  }
  else if  (this.stacks[from_tower].length === 0 || this.stacks[from_tower].length === undefined ) {
    console.log("false");
    return false;
  }
  else if (from_tower === to_tower){
    console.log("false");
    return false;
  }
  else if ((this.stacks.length -1) < to_tower){
    //outside the array length
    console.log("false");
    return false;
  }
  else if (this.stacks[to_tower][this.stacks[to_tower].length -1] === undefined && ((this.stacks.length-1) >= to_tower)) {
    console.log("true");
    return true;
  }
   else if (this.stacks[from_tower][this.stacks[from_tower].length -1] < this.stacks[to_tower][this.stacks[to_tower].length -1]){
    console.log("true");
    return true;
  }

}

Game.prototype.move = function(from_tower, to_tower){
  if (this.isValidMove(from_tower, to_tower) === true){
    let popped = this.stacks[from_tower].pop();
    this.stacks[to_tower].push(popped);
    console.log("successful move");
  } else if (this.isValidMove(from_tower, to_tower) === false){
    console.log("not a valid move");
  }
  this.print();
  // console.log(this.stacks);
}

Game.prototype.print = function() {
  // console.log(this.stacks);
  console.log(JSON.stringify(this.stacks));
}

Game.prototype.isWon = function(){
  console.log("isWon")
  let who_has_pegs = [];
  for (i in this.stacks){
    if (this.stacks[i].length > 0 ){
      who_has_pegs.push(Number(i));
    }
  }
  console.log(who_has_pegs)
  if (who_has_pegs.includes(0)) {
    console.log("false");
    return false;
  } else if (who_has_pegs.length === 1){
    console.log("true");
    return true
  }
}
let tower = new Game;

tower.promptMove(function (result1, result2) {
  console.log(`moving from tower: ${result1} to tower: ${result2}`);
  // tower.move(result1, result2);
  reader.close();
});


tower.isValidMove(0,2);
// tower.move(0,2)
tower.isWon();
// tower.print();

// tower.isValidMove(1,2);
// tower.move(1,2)
// tower.isValidMove(2,2);
// tower.move(2,2)
// tower.isValidMove(0,1);
// tower.isValidMove(0,0);
// tower.isValidMove(2,1);
// tower.isValidMove(2,0);
// tower.isValidMove(3,3);
// tower.isValidMove(0,3);
// tower.isValidMove(3,0);


// tower.promptMove(function());

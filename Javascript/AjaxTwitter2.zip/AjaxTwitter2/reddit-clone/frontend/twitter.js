const FollowToggle = require("./follow_toggle.js");
//
//

$(() => {
  new FollowToggle($('.follow-toggle'));

  //from thier solution
  $('button.follow-toggle').each( (i, btn) => new FollowToggle(btn, {}) );
  console.log("aaaaaaaaaaaaaaaaaaaaaa");

    // window.rootEl = {};
    //
    // window.rootEl = $('.follow-toggle');
    // ft = new FollowToggle;
    // FollowToggle.tell();
    // console.log(FollowToggle);
  // $( "button.follow-toggle" ).each(function( index ) {
  //   // console.log( index + ": " + $( this ).text() );
  //   ft = new FollowToggle(this[index]);
  // });
//
});

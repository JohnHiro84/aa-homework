//
class FollowToggle ($el){
  constructor($el){
    this.$(el) = $el;
    this.$userId = $el.data("user-id");
    this.$followState = $el.data("initial-follow-state");
  }
}


// function FollowToggle(){
//
// }

// FollowToggle.prototype.tell = function(){
//   console.log("followtoggle");
// }
module.exports = FollowToggle;


class HanoiView {
  constructor(hanoigame, el) {
    this.game = hanoigame;
    this.el = el;
    this.setupTowers();
    this.render();
    // this.installClick();
  }

}

HanoiView.prototype.setupTowers = function() {

  const ul = document.createElement("ul");
  ul.className = "ul-peg";

  for(i = 0; i< 3; i++){
    const ul = document.createElement("ul");
    ul.className = "ul-peg";
    ul.setAttribute("data-peg", `${i} `);
    if(i === 0 ){
      for(j = 3; j > 0; j--){
        li = document.createElement("li");
        li.textContent = (j);
        li.className = "li-disk";
        ul.append(li);
      }
    }
    console.log('ul')
    this.el.append(ul);
    // li.setAttribute("data-cell", `${pos[i]} `);
  }
}

HanoiView.prototype.reset = function() {
  //reset the element
  this.el.children().remove();
  // this.el.html("<figure></figure>");
  // this.el.className = "hanoi";
}


//
// HanoiView.prototype.installClick = function() {
//   console.log("instal")
//
//     $("ul").on("click", event => {
//       clickarray = [];
//       if (this.game.isWon() === false){
//         console.log("click")
//         console.log(this.game.isWon());
//         const $peg_Li = $(event.currentTarget);
//         console.log($peg_Li);
//         // $cell_Li.addClass(`player_${view.game.currentPlayer}`);
//         //
//         const peg = $peg_Li.data("peg");
//         console.log(peg);
//         clickarray.push(Number(peg));
//         console.log(clickarray);
//         if (clickarray.length === 2){
//           this.game.move(clickarray[0], clickarray[1]);
//           view.render();
//           clickarray = [];
//         }
//         console.log("something")
//       }
//     });
// }
//


HanoiView.prototype.render = function() {
  console.log(this.game.towers);
  this.reset();
  // this.installClick();

  for(i = 0; i < 3; i++){
    const ul = document.createElement("ul");
    ul.className = "ul-peg";
    ul.setAttribute("data-peg", `${i} `);

    if(this.game.towers[i].length > 0 ){
      for(j in this.game.towers[i]){

        console.log(this.game.towers[i][j]);
        li = document.createElement("li");
        li.textContent = (this.game.towers[i][j]);
        li.className = "li-disk";
        ul.append(li);
      }
      // for(j = 1; j < 4; j++){
      // }
    }
    // console.log('ul')
    this.el.append(ul);

    // li.setAttribute("data-cell", `${pos[i]} `);
  }
  // this.el.append(ul);
}

module.exports = HanoiView;

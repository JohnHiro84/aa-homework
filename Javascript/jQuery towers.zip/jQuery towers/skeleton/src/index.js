HanoiGame = require('./game.js');
HanoiView = require('./hanoi-view.js');
$(() => {
  const rootEl = $('.hanoi');
  console.log(rootEl);
  console.log("asdfaf");
  const game = new HanoiGame();
  let clickarray = [];
  let view = new HanoiView(game, rootEl);
  view.render();
  // game.move(0,2);
  // view.render();
  // game.move(0,1);
  // view.render();

  $("ul").on("click", event => {

    if (view.game.isWon() === false){
      console.log("click")
      console.log(view.game.isWon());
      const $peg_Li = $(event.currentTarget);
      console.log($peg_Li);
      // $cell_Li.addClass(`player_${view.game.currentPlayer}`);
      //
      const peg = $peg_Li.data("peg");
      console.log(peg);
      clickarray.push(Number(peg));
      console.log(clickarray);
      if (clickarray.length === 2){
        view.game.move(clickarray[0], clickarray[1]);
        view.render();
        clickarray = [];
      }
      console.log("something")
    }
  });
});

const Board = require("./board");

function Game (){
  this.board = new Board();
}

Game.prototype.run = function(reader, completionCallBack){
    if (this.board.won === false ){

      reader.question("Enter y pos: ", function (numString1) {
        reader.question("Enter x pos: ", function (numString2) {
          const num1 = parseInt(numString1);
          const num2 = parseInt(numString2);
          completionCallBack(num1 + num2);
        });
      });

    } else if (this.board.won === true){
      completionCallback(sum);
      reader.close();
    }
}
g = new Game;
g.run("a", g.board.winner());


b = new Board;
b.run();
b.print()
b.empty([2,2]);
b.place_mark([0,0], "O");
b.place_mark([0,1], "O");
b.place_mark([0,2], "O");

b.print();
b.won();

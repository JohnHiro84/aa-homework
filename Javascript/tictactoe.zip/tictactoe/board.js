function Board () {
  this.grid = [['e','e','e'],['e','e','e'],['e','e','e']];
}

Board.prototype.print = function () {
  for(i in this.grid){
    console.log(this.grid[i]);
  }
};

Board.prototype.empty = function(pos) {
  let y = pos[0];
  let x = pos[1];
  if (this.grid[x][y] === "e"){
    console.log("true");
    return true;
  } else if (this.grid[x][y] !== "e"){
    console.log("false");
    return false;
  }
}
// board functions

Board.prototype.place_mark = function(pos, mark){
  if (this.empty(pos) === true && (mark === "X" || mark === "O" )){
    this.grid[pos[1]][pos[0]] = mark;
  }
}
Board.prototype.won = function() {
  // check horizontally
  let three_x = 0;
  let three_y = 0;
  for (i in this.grid){
    for (j in this.grid[i]){
      console.log(this.grid[i][j]);
      if (this.grid[i][j] === "X"){
        three_x+=1;
      } else if (this.grid[i][j] === "O"){
        three_y+=1;
      }
    }
    if (three_x === 3){
      this.winner("X");
    }
    else if (three_y === 3){
      this.winner("O");
    }
    three_x = 0;
    three_y = 0;

  }

  for (k in this.grid){
    for (l in this.grid[k]){
      console.log(this.grid[l][k]);
      if (this.grid[l][k] === "X"){
        three_x+=1;
      } else if (this.grid[l][k] === "O"){
        three_y+=1;
      }
    }
    if (three_x === 3){

      this.winner("X");
    }
    else if (three_y === 3){
      this.winner("O");
    }
    three_x = 0;
    three_y = 0;

  }
  return false;
}

Board.prototype.winner = function(mark){
  console.log(` ${mark} is the winner!`);
  return true;
}

// Board.won(), Board.winner();, Board.empty(pos);, Board.place_mark(pos, mark)
module.exports = Board;

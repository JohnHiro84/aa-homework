console.log("Hello from the JavaScript console!");

// Your AJAX request here
// $(document).ready(function(){
//   console.log("right b4 ajax");
//     $.ajax({
//       type: 'GET',
//       url: "http://api.openweathermap.org/data/2.5/weather?q=new%20york,US&appid=bcb83c4b54aee8418983c2aff3073b3b",
//     dataType: 'json',
//     success: function(result){
//       // $("#coord").html(result.coord);
//       console.log(result);
//     }});
//
// });
//

$.ajax( 'http://api.openweathermap.org/data/2.5/weather?q=new%20york,US&appid=bcb83c4b54aee8418983c2aff3073b3b', {
  type: 'GET',
  dataType: 'json',
  success: function( resp ) {
    // console.log( resp.coord );
    console.log(resp)
  },
  error: function( req, status, err ) {
    console.log( 'something went wrong', status, err );
  }
});

// Add another console log here, outside your AJAX request
console.log("another console.log");



//
// When does the request get sent?
// after the 1st console.log

// When does the response come back?
// after the 2nd console.log

// What's the current weather in New York?

// cloudy with a chance of meatballs


// Did the page refresh?
// no

// How could we use different HTTP methods in our request?
// change the request type from get to post

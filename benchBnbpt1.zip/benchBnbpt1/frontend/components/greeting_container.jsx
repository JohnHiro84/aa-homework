import { connect } from 'react-redux';
import Greeting from './greeting';

// Actions
import { signup_user, login_user, logout_user } from '../actions/session_actions';
// import { allTodos } from '../../reducers/selectors';

const mapStateToProps = (state, ownProps) => {
  const curr = state.entities.users[state.session.id];
  // const curr = state.session;
  return {
    currentUser: curr,
    errors: state.errors
  }

};

const mapDispatchToProps = dispatch => ({
  login: user => dispatch(login_user(user)),
  signup: user => dispatch(signup_user(user)),
  logout: () => dispatch(logout_user())
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Greeting);

import { connect } from 'react-redux';
import React from 'react';
import SessionForm from './SessionForm';


const mapStateToProps = (state, ownProps) => ({
  errors: state.errors,
  //build a selector to get the errors in an array form,
  // yet you dont have errors showing up here yet?
  // errors (array) - list of errors from the state

  formType: "login"
});

const mapDispatchToProps = dispatch => ({
  processForm : user => dispatch(login_user(user))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SessionForm);

// import React from 'react';
import React, { Component } from 'react';
import { Link } from 'react-router-dom';

// const Greeting = ({ user }) => {
// class Greeting extends Component {

export default ({ currentUser, logout }) => {
  console.log(currentUser);
  const display = currentUser ? (
    <div>
      <p>Hello, {currentUser.username}</p>
      <button onClick={logout}>Log Out</button>
    </div>
  ) :  (
    <div>
      <p>not logged in </p>
      <Link className="btn"  to="/signup">Sign Up</Link>
      <Link className="btn" to="/login">Log In</Link>
    </div>
  );
//   componentDidUpdate(prevProps) {
//   if (prevProps.currentUser.username !== this.props.currentUser.username) {
//     console.log("updated!!!!!");
//     // this.props.requestSinglePokemon(this.props.match.params.pokemonId);
//   }
// }

  // render() {
  //   const { currentUser, logout } = this.props;
  //   console.log(currentUser);
  //
  //   // console.log(prevProps);
  //
  //   let current = "na";
  //   if(currentUser !== undefined){
  //     current = currentUser.username;
  //   } else {
  //     current = "na";
  //   }

    return (
      <div>
        <p>Hi! this is greeting.jsx</p>
        {display}
      </div>
    );

  // }

}
// export default Greeting;

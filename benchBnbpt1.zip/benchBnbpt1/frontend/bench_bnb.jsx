import React from 'react';


import ReactDOM from 'react-dom';
import configureStore from './store/store';
import Root from './components/root';
import {signup, login, logout} from './util/session_api_util';


import { signup_user, login_user, logout_user, receiveCurrentUser, fetchAllUsers
  , logoutCurrentUser
} from './actions/session_actions';

document.addEventListener('DOMContentLoaded', () => {
  let preloadedState = undefined;
  let store;
  if (window.currentUser) {
    preloadedState = {
      session: {
        id : window.currentUser.id
      },
      entities: {
        users: {
          [window.currentUser.id]: window.currentUser
        }
      }
    };
    store = configureStore(preloadedState);
  } else {
    store = configureStore();
  }


  // TESTING START
  // window.store = store;
  window.getState = store.getState;
  window.dispatch = store.dispatch;
  window.signup = signup;
  window.login = login;
  window.logout = logout;
  window.signup_user = signup_user;
  window.login_user = login_user;
  window.logout_user = logout_user;
  window.receiveCurrentUser = receiveCurrentUser;
  window.fetchAllUsers = fetchAllUsers;
  window.logoutCurrentUser = logoutCurrentUser;
  // TESTING END

  const root = document.getElementById('root');
  ReactDOM.render(<Root store={ store }/>, root);
});

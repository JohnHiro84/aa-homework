import *  as Session_Util from '../util/session_api_util';

export const RECEIVE_CURRENT_USER = "RECEIVE_CURRENT_USER";
export const LOGOUT_CURRENT_USER = "LOGOUT_CURRENT_USER";
export const RECEIVE_ERRORS = "RECEIVE_ERRORS";
export const RECEIVE_SESSION_ERRORS = "RECEIVE_SESSION_ERRORS";

export const fetchAllUsers = () => {
 let poke_promise = $.ajax({
    method: 'GET',
    url: `/api/users/`
  })
  return poke_promise;
};


export const receiveCurrentUser = user => ({
  type: RECEIVE_CURRENT_USER,
  user
});

export const logoutCurrentUser = () => ({
  type: LOGOUT_CURRENT_USER,
});

export const receiveErrors = errors => ({
  type: RECEIVE_ERRORS,
  errors
})

export const signup_user = (formUser) => dispatch =>  {
  Session_Util.signup(formUser)
    .then(user => {
      dispatch(receiveCurrentUser(user))
      return user
    });
}

export const login_user = formUser => dispatch => {

  Session_Util.login(formUser)
    .then(user => {
      dispatch(receiveCurrentUser(user))
      return user
    });
}

export const logout_user = () => dispatch => {
  Session_Util.logout()
  .then(() => {
    dispatch(logoutCurrentUser())
  });
}
//
// export const createNewUser = formUser => dispatch => postUser(formUser)
//   .then(user => dispatch(receiveCurrentUser(user)));
//
//
// export const requestSinglePokemon = (id) => (dispatch) => {
//     return APIUtil.fetchSinglePokemon(id).then(pokemon => {
//       dispatch(receiveSinglePokemon(pokemon));
//       return pokemon;
//     });
//   }

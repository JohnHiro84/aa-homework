import {
  RECEIVE_CURRENT_USER, LOGOUT_CURRENT_USER
} from '../actions/session_actions';

import merge from 'lodash/merge';

const _nullSession = {
  id: null
};
export default (state = {}, action) => {
  Object.freeze(state);
  let nextState;
  switch (action.type) {
    case RECEIVE_CURRENT_USER:
      nextState = merge({}, state, { [action.user.id]: action.user });
      // action.users.forEach((user => nextState[user.id] = user;
      // return state;
      return nextState;
    case LOGOUT_CURRENT_USER:
    return {};

    default:
      return state;
  }
}



// merge({}, state, { [action.user.id]: action.user })

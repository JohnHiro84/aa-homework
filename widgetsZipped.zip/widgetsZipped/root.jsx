import React from 'react';
import Clock from './frontend/clock';
import Tabs from './frontend/tabs';

// const Root = () => <h1>Congratulations, you did it!</h1>;

// function Root() {
//   constructor(props) {
//   //   super(props);
//   //   // your code here
//   //   this.state = {
//   //     array: "hello"
//   //   }
//   // this.array = ["a"];
//   }
//
//   return (
//     <div>
//         <h1>Hello</h1>
//         <Clock/>
//         <Tabs something="whoa"/>
//     </div>
//   )
//
// }


class Root extends React.Component {
  constructor(props) {
    super(props);
    // your code here
    this.interval = "";
    this.state = {
      array: [["tab1","a", "Article a"], ["tab2", "b", "Article b"], ["tab3", "c", "Article c"]]
    };
  }

  render() {
    return (
      <div id="page-container">
        <h1>Widgets App</h1>

        <Clock/>
        <Tabs  else={this.state.array}/>
      </div>
    )
  }
}
export default Root;

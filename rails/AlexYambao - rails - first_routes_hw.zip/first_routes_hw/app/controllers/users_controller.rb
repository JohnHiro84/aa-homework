class UsersController < ApplicationController
  def index
    # render plain: "I'm in the index action!"
    users = User.all

    render json: users
  end

  def create
  user = User.new(parameters)
  if user.save
    render json: user
  else
    render json: user.errors.full_messages, status: :unprocessable_entity
  end
end

  def show

    user = User.find_by_id(params[:id])
    # render plain: user.id
    # render json: user
    render json: params
  end

  # def update
  #
  #   # User.update(params[:id], :email => 'Samuel@Jackson.com', :name => 'Samuel Jackson')
  #   puts  params[:id]
  #   puts " "
  #   if params[:name] != "" && params[:email] != ""
  #     puts "params name exists"
  #     User.update(params[:id], :email => params[:email], :name => params[:name])
  #   elsif params[:name] != ""
  #     User.update(params[:id], :name => params[:name])
  #   elsif params[:email] != ""
  #     User.update(params[:id], :email => params[:email])
  #   end
  #   render json: params
  # end

  def update
    user = User.find(params[:id])
    if user.update_attributes(parameters)
      render json: user
    else
      render json: user.errors, status: :unprocessable_entity
    end
  end

  def destroy
    user = User.find(params[:id]).destroy
    render json: user
    # render plain: 'user destroyed'
  end


    # def create
    #   render json: params
    #   # render plain: 'cool'
    # end

    # def create
    #   user = User.new(params.require(:user).permit(:name, :email))
    #   # replace the `user_attributes_here` with the actual attribute keys
    #   user.save!
    #   render json: user
    # end


  private

  def parameters
    params.require(:user).permit(:name, :email)
  end

  # def who_is
  #   render plain: "who goes there"
  # end
end

class SessionsController < ApplicationController

  def create
    user = User.find_by_credentials(
      params[:user][:username],
      params[:user][:password]
    )

    if user.nil?
      render json: 'Credentials were wrong'
    else
      # render json: user

      login!(user)
      render json: @current_user
      # @user = current_user
      # redirect_to user_url(user)
      #
      # render :'users/show'
      # render plain: "Welcome back #{@current_user.username}!"
    end
  end


  def new
    # @session = User.new
    render :new
  end

  def destroy
    logout!
    redirect_to new_session_url
  end
end

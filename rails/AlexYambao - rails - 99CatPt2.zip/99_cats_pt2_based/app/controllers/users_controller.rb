class UsersController < ApplicationController
  before_action :require_current_user!, except: [:create, :new]

    def index
      @users = User.all
      render json: @users
    end

    def create
      @user = User.new(user_params[:user])

      # u = User.create(user_params)
      msg = UserMailer.welcome_email(@user)
      msg.deliver_now
      puts msg.to_s


      if @user.save
        # msg = UserMailer.welcome_email(@user)
        # msg.deliver_now
        login!(@user)
        redirect_to user_url(@user)
        # render json: @user
      else
        render json: @user.errors.full_messages
      end
    end

    def new
      @user = User.new
    end


    private

    def user_params
      params.require(:user).permit(:username)
    end

end

class PostSubsController < ApplicationController
end

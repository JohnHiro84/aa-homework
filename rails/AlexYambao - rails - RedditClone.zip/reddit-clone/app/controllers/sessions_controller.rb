class SessionsController < ApplicationController

  def create
    user = User.find_by_credentials(
      params[:user][:email],
      params[:user][:password]
    )

    if user.nil?
      render json: "email and password were bad"
    else
      login!(user)
      # render :show
      # redirect_to root_url
      # debugger
      # @current_user = user
      redirect_to user_url(@current_user)
      # debugger
      # render json: @current_user
    end
  end

  def new
    render :new
  end

  def destroy
    @current_user = current_user
    logout(@current_user)
    render :new
  end

end

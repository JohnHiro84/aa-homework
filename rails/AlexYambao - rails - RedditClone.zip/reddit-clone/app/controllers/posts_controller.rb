class PostsController < ApplicationController
  before_action :require_author_to_edit_post!, except: [:create, :new, :show, :index]

  def index
    @posts = Post.all
    render json: @posts
  end


      def new
        @post = Post.new
        render :new
      end

    def create
      @post = current_user.posts.new(post_parameters)
      @post.user_id = current_user.id
      # debugger
      if @post.save
        redirect_to post_url(@post)
      else
        flash.now[:errors] = @post.errors.full_messages
        render :new
      end
    end

    def update
      @post = Post.find(params[:id])

      if @post.update_attributes(post_parameters)
        # redirect_to sub_url(@sub)
        render json: @post
      else
        render json: @post.errors, status: :unprocessable_entity
      end
    end

    def require_author_to_edit_post!
      # debugger
      @post = Post.find(params[:id])
      redirect_to subs_url if current_user.id != @post.user_id

    end



    def show
      @post = Post.find(params[:id])
      # render :show
      render json: @post
    end

    private

    def post_parameters
      params.require(:post).permit(:title, :url, :content, sub_ids: [])
    end

end

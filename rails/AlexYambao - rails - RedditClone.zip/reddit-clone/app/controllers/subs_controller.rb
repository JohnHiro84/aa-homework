class SubsController < ApplicationController
  before_action :require_author_to_edit_sub!, except: [:create, :new, :show, :index]

  def index
    @subs = Sub.all
    render :index
  end


    def create
      @sub = Sub.new(sub_parameters)
      @sub.user_id = current_user.id
      # debugger
      if @sub.save
        redirect_to sub_url(@sub)
      else
        flash.now[:errors] = @sub.errors.full_messages
        render :new
      end
    end

    def update
      @sub = Sub.find(params[:id])

      if @sub.update_attributes(sub_parameters)
        redirect_to sub_url(@sub)
        # render json: @sub
      else
        render json: @sub.errors, status: :unprocessable_entity
      end
    end

    def require_author_to_edit_sub!
      # debugger
      @sub = Sub.find(params[:id])
      redirect_to subs_url if current_user.id != @sub.user_id

    end

    def new
      @sub = Sub.new
      render :new
    end

    def show
      @sub = Sub.find(params[:id])
      @posts = Post.where(sub_id: @sub.id)
      # render json: @sub
      render :show
    end

    private

    def sub_parameters
      params.require(:sub).permit(:title, :description)

    end

end

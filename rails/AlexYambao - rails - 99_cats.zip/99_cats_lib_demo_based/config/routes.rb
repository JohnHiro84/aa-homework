Rails.application.routes.draw do

  resources :cats, only: [:index, :show, :new, :create, :edit, :update]
  # resources :books, only: [:index, :show, :new, :create, :edit, :update]
  resources :rental_requests, only: [:index, :show, :new, :create]
  #we use patch at aa


  # resources :users
  # get 'users', to: 'users#index'
  # get 'users/new', to: 'users#new', as: 'new_user'
  # get 'users/:id', to: 'users#show', as: 'user'
  # get 'users/:id/edit', to: 'users#edit', as: 'edit_user'
  # post 'users', to: 'users#create'
  # patch 'users/:id', to: 'users#update'
  # put 'users/:id', to: 'users#update'
  # delete 'users/:id', to: 'users#destroy'

  # get 'users', to: 'users#who_is'
  # get 'users/:id', to: 'users#show', as: 'user'

end

class RentalRequestsController < ApplicationController

  def index
    @requests = RentalRequest.all
    render :index

  end

  def show
    @request = RentalRequest.find_by(id: params[:id])
    render :show
  end


  def new
    # @colors
    @request = RentalRequest.new
    @cats = Cat.all
    # debugger
    render :new
  end

  def create

    @request = RentalRequest.new(request_params)
    # @cat.created_at = Time.now
    # debugger
    if @request.save
      #show user the book show page
      redirect_to rental_request_url(@request)
    else
      #show user the new book form
      render :new
      # render plain: "hi"
    end
  end


    private
    def request_params
      params.require(:request).permit(:cat_id, :start_date, :end_date)
    end

end

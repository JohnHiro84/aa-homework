class CatsController < ApplicationController

  def index
    # @colors = Cat.valid_colors
    @cats = Cat.all
    debugger
    render :index

  end

  def show

    @cat = Cat.find_by(id: params[:id])

    render :show
  end

  def new
    @colors
    @cat = Cat.new
    # debugger
    render :new
  end



  def create

    @cat = Cat.new(cat_params)
    @cat.created_at = Time.now
    # debugger
    if @cat.save
      #show user the book show page
      redirect_to cat_url(@cat)
    else
      #show user the new book form
      render :new
    end
  end

  def edit
    @cat = Cat.find_by(id: params[:id])
    render :edit
  end

  def update
    @cat = Cat.find_by(id: params[:id])

    if @cat.update_attributes(cat_params)
      redirect_to cat_url(@cat)
    else
      render :edit
    end
  end

  private
  def cat_params
    params.require(:cat).permit(:name, :birth_date, :sex, :description, :color, :created_at)
  end

end



class Cat < ActiveRecord::Base
  # require 'action_view'
  include ActionView::Helpers::DateHelper

  validates :created_at, presence: true
  validates :color, inclusion: { in: %w(brown white black orange gray yellow green red blue),
    message: "%{value} is not a valid color" }

  validates :sex, inclusion: { in: %w(M F),
    message: "%{value} is not a valid sex Choose either M or F" }

  has_many :rental_requests, :dependent => :destroy,
    primary_key: :id,
    foreign_key: :cat_id,
    class_name: 'RentalRequest'

  def colors
    colors = "brown white black orange gray yellow green red blue"
  end

  def age
    # "here is age:"
    from_time = Time.now
    # distance_of_time_in_words(from_time, from_time + 50.minutes)
    distance_of_time_in_words(self.birth_date, from_time )
    # select_year(Time.now)
    # select_year(Date.today)
    # time_ago_in_words(birth_date)
  end

  # def color
  #   @color = self.color
  # end
end

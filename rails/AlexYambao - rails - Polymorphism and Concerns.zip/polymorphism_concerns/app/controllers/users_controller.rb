class UsersController < ApplicationController
  def index
    render plain: "I'm in the index action!"
  end

  def create
    render json: params
    # render plain: 'cool'
  end

  def show
    render json: params
  end
  # def who_is
  #   render plain: "who goes there"
  # end
end

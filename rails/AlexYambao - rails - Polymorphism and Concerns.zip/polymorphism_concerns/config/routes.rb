Rails.application.routes.draw do

  # resources :users
  get 'users', to: 'users#index'
  get 'users/new', to: 'users#new', as: 'new_user'
  get 'users/:id', to: 'users#show', as: 'user'
  get 'users/:id/edit', to: 'users#edit', as: 'edit_user'
  post 'users', to: 'users#create'
  patch 'users/:id', to: 'users#update'
  put 'users/:id', to: 'users#update'
  delete 'users/:id', to: 'users#destroy'

  # get 'users', to: 'users#who_is'
  # get 'users/:id', to: 'users#show', as: 'user'

end
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  # get 'superheroes', to: 'superheroes#index'
  #                        controller above

  #rest, restful representational state transfer

  #get 'superheroes', to: 'superheroes#index'
  #get 'superheroes/:id', to: 'superheroes#show'
  #post 'superheroes', to: 'superheroes#create'
  #patch 'superheroes/:id', to: 'superheroes#update'
  #put 'superheroes/:id', to: 'superheroes#update'
  #delete 'superheroes/:id', to: 'superheroes#destroy'

  #can all be created with:
  #resources :superheroes, only: [:index, :show, :create, :update, :destroy]
#
#   get 'silly', to: 'silly#fun'
#   post 'silly', to: 'silly#time'
#   post 'silly/:id', to: 'silly#super'
#
#
#   #rails s, to start server
#
#   resources :superheroes do
#     resources :abilities, only: [:index]
#   end
#
#   #nested routes
#   #get 'superheroes/2/abilities'
#
#   resources :abilities, only: [:show, :update, :create, :destroy]
#
#     patch 'superheroes/2/abilities/6'
# end

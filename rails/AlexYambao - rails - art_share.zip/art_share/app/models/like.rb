class Like < ActiveRecord::Base
  validates :user_id, presence: true

  belongs_to :likable, polymorphic: true
end

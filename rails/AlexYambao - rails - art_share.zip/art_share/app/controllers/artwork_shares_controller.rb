class ArtworkSharesController < ApplicationController
  def index
    # render plain: "I'm in the index action!"
    artwork_share = ArtworkShare.all

    render json: artwork_share
  end

  def create
  artwork_share = ArtworkShare.new(artwork_share_parameters)
  if artwork_share.save
    render json: artwork_share
  else
    render json: artwork_share.errors.full_messages, status: :unprocessable_entity
  end
end

  def show

    artwork_share = ArtworkShare.find_by_id(params[:id])
    # render plain: user.id
    render json: artwork_share
  end

  # def update
  #   artwork = Artwork.find(params[:id])
  #   if artwork.update_attributes(artwork_share_parameters)
  #     render json: artwork
  #   else
  #     render json: artwork.errors, status: :unprocessable_entity
  #   end
  # end

  def destroy
    artwork_share = ArtworkShare.find(params[:id]).destroy
    render json: artwork_share
    # render plain: 'user destroyed'
  end

  private

  def artwork_share_parameters
    params.require(:artwork_share).permit(:artwork_id, :viewer_id)
  end


end

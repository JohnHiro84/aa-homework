class ArtworksController < ApplicationController
  # def index
  #   # render plain: "I'm in the index action!"
  #   artworks = Artwork.all
  #
  #   render json: artworks
  # end

  # def index
  #   # render plain: "I'm in the index action!"
  #   user_id = params['user_id']
  #   Artwork
  #     .left_outer_joins(:artwork_shares)
  #     .where('(artworks.artist_id = :user_id) OR (artwork_shares.viewer_id = :user_id)', user_id: user_id)
  #     .distinct
  # 
  #   # where('artist_id' = self.id)
  #   # render json:
  #   render json: artworks
  # end

  def index
    render json: Artwork.artworks_for_user_id(params[:user_id])
  end

  def create
  artwork = Artwork.new(parameters)
  if artwork.save
    render json: artwork
  else
    render json: artwork.errors.full_messages, status: :unprocessable_entity
  end
end

  def show

    artwork = Artwork.find_by_id(params[:id])
    # render plain: user.id
    render json: artwork
  end

  def update
    artwork = Artwork.find(params[:id])
    if artwork.update_attributes(parameters)
      render json: artwork
    else
      render json: artwork.errors, status: :unprocessable_entity
    end
  end

  def destroy
    artwork = Artwork.find(params[:id]).destroy
    render json: artwork
    # render plain: 'user destroyed'
  end

  private

  def parameters
    params.require(:artwork).permit(:title, :image_url, :artist_id)
  end


end

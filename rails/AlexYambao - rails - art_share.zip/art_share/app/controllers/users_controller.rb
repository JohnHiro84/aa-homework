class UsersController < ApplicationController


  def index

    if params[:search_query]
      # users = User.where('username like \'%params[:search_query]%\'')
      # users = User.where(username: like params[:search_query] )
      users = User.where('username LIKE ?', "%#{params[:search_query]}%")
    else
      users = User.all
    end
    render json: users
  end




  # def index
  #
  #   if params[:user_id]
  #     comments = Comment.where(user_id: params[:user_id])
  #   elsif params[:artwork_id]
  #     comments = Comment.where(artwork_id: params[:artwork_id])
  #   else
  #     comments = Comment.all
  #   end
  #   render json: comments
  # end

  def create
  user = User.new(parameters)
  if user.save
    render json: user
  else
    render json: user.errors.full_messages, status: :unprocessable_entity
  end
end

  def show

    user = User.find_by_id(params[:id])
    # render plain: user.id
    render json: user
  end

  def update
    user = User.find(params[:id])
    if user.update_attributes(parameters)
      render json: user
    else
      render json: user.errors, status: :unprocessable_entity
    end
  end

  def destroy
    user = User.find(params[:id]).destroy
    render json: user
    # render plain: 'user destroyed'
  end

  private

  def parameters
    params.require(:user).permit(:username)
  end


end

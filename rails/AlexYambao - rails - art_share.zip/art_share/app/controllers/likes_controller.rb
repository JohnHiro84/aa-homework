class LikesController < ApplicationController
  def index

    if params[:user_id]
      likes = Like.where(user_id: params[:user_id])
    elsif params[:comment_id]
      likes = Like.where(likable_id: params[:comment_id], likable_type: "Comment")
    elsif params[:artwork_id]
      likes = Like.where(likable_id: params[:artwork_id], likable_type: "Artwork")
    else
      likes = Like.all
    end
    render json: likes
  end
#
#   def create
#   comment = Comment.new(comment_parameters)
#   if comment.save
#     render json: comment
#   else
#     render json: comment.errors.full_messages, status: :unprocessable_entity
#   end
# end
#
#   def show
#
#     comment = Comment.find_by_id(params[:id])
#     # render plain: user.id
#     render json: comment
#   end
#
#   # def update
#   #   user = User.find(params[:id])
#   #   if user.update_attributes(comment_parameters)
#   #     render json: user
#   #   else
#   #     render json: user.errors, status: :unprocessable_entity
#   #   end
#   # end
#
#   def destroy
#     comment = Comment.find(params[:id]).destroy
#     render json: comment
#     # render plain: 'user destroyed'
#   end
#
#   private
#
#   def comment_parameters
#     params.require(:comment).permit(:text_body, :artwork_id, :user_id)
#   end


end

class SillyController < ApplicationController
  def fun
    #render text: params[:message]
    render json: params
  end

  def time
    render json: params
  end

  def super
    render json: params
  end
end

#params
#1) Query String
#2) request body
#3) url params, wild cards

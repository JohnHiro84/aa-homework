# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

#
# User.create(username: "CityStylesTiffany89" )
#
# User.create(username: "GoldenStarTG" )
# User.create(username: "Whazzuper43" )

Artwork.create(title: "urban styles", image_url: "www.artistsrebel.com" , artist_id:  3)
Artwork.create(title: "subway station at dawn ", image_url: "www.artistsrebel.com" , artist_id:  3)
Artwork.create(title: "City outlook view ", image_url: "www.artistsrebel.com" , artist_id: 3 )
Artwork.create(title: "Stars at night", image_url: "www.spaceArt.com"  , artist_id: 2)
Artwork.create(title: " The galaxy", image_url: "www.spaceArt.com" , artist_id: 2)


ArtworkShare.create(artwork_id: 6, viewer_id: 5)
ArtworkShare.create(artwork_id: 7, viewer_id: 5)
ArtworkShare.create(artwork_id: 8, viewer_id: 5)
ArtworkShare.create(artwork_id: 9, viewer_id: 4)
ArtworkShare.create(artwork_id: 10, viewer_id: 4)

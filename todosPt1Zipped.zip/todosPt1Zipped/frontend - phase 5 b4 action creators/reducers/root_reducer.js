import {combineReducers} from 'redux';
import todosreducer from './todos_reducer';


const rootReducer = combineReducers({todos: todosreducer});

export default rootReducer;

import React from 'react';
import DetailViewContainer from './detail_view_container';

class TodoItem extends React.Component {
  constructor(props){
    super(props);
    this.state = {showdetail: false};
    this.handleClick = this.handleClick.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
    this.toggleDetail = this.toggleDetail.bind(this);

  }

  handleClick(e) {
    e.preventDefault();
    this.props.removeTodo(this.props.todo);
  }
  handleToggle(e) {
    e.preventDefault();
    this.props.receiveTodo(this.props.todo);
  }
  toggleDetail(e){
    e.preventDefault();
    this.setState({ showdetail: !this.state.showdetail });
  }

  render() {
    const { todo } = this.props;

    let detail;
    if (this.state.showdetail){
      detail = < DetailViewContainer todo={todo} />;
    }

    return(
        <div>
        <li >
          <h4><a onClick={this.toggleDetail}>{todo.title} </a></h4>
          Completed: {todo.done.toString()}
          <span><button onClick={this.handleToggle}>Toggle</button></span>
          <span>{detail}</span>
        </li>


        </div>
    );
  }
}


export default TodoItem;

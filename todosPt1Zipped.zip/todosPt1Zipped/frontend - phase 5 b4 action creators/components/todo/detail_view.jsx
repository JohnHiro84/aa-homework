import React from 'react';

class DetailView extends React.Component {
  constructor(props){
    super(props);
    this.handleClick = this.handleClick.bind(this);
    // this.handleToggle = this.handleToggle.bind(this);

  }

  handleClick(e) {
    e.preventDefault();
    this.props.removeTodo(this.props.todo);
  }
  // handleToggle(e) {
  //   e.preventDefault();
  //   this.props.receiveTodo(this.props.todo);
  // }

  render() {
    const { todo } = this.props;

    return(
        <div>
        <li >{todo.body}
        <span><button onClick={this.handleClick}>Delete</button></span>
        </li>

        </div>

    );
  }
}


export default DetailView;

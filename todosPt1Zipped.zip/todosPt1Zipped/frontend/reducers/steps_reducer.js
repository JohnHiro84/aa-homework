import {RECEIVE_STEPS, RECEIVE_STEP, REMOVE_STEP } from '../actions/step_actions';

import merge from 'lodash/merge';

const initialstate = {

    1: { // this is the step with id = 1
      id: 1,
      title: 'walk to store',
      done: false,
      todo_id: 1
    },
    2: { // this is the step with id = 2
      id: 2,
      title: 'buy soap',
      done: false,
      todo_id: 1
    },
    3: { // this is the step with id = 2
      id: 3,
      title: 'scrub down the car',
      done: false,
      todo_id: 1
    }

}

const stepsreducer = (state = {}, action) => {
  Object.freeze(state);
  let nextState = {};
  switch(action.type) {

      case RECEIVE_STEPS:
      action.steps.forEach( step => {
        nextState[step.id] = step;
      });
      return nextState;

      case RECEIVE_STEP:
      const newStep = {[action.step.id]: action.step};
      if (state[action.step.id]){
        if (state[action.step.id]["done"] === true){
          state[action.step.id]["done"] = false;
        } else if(state[action.step.id]["done"] === false){
          state[action.step.id]["done"] = true;
        }
        return merge({}, state);
      } else {
        return merge({}, state, newStep);
      }
      case REMOVE_STEP:
      let anotherstate = merge({}, state);
      delete anotherstate[action.step.id];
      return anotherstate;

      default:
        return state;
  }
};

export default stepsreducer;

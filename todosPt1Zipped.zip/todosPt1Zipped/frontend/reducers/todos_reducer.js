import {RECEIVE_TODOS, RECEIVE_TODO, REMOVE_TODO } from '../actions/todo_actions';

import merge from 'lodash/merge';

const initialState = {
  1: {
    id: 1,
    title: 'wash car',
    body: 'with soap',
    done: false
  },
  2: {
    id: 2,
    title: 'wash dog',
    body: 'with shampoo',
    done: true
  }
};
const todosreducer = (state = {}, action) => {
  Object.freeze(state);
  let nextState = {};
  switch(action.type) {

      case RECEIVE_TODOS:
      action.todos.forEach( todo => {
        nextState[todo.id] = todo;
      });
      return nextState;

      case RECEIVE_TODO:
      const newTodo = {[action.todo.id]: action.todo};
      if (state[action.todo.id]){
        if (state[action.todo.id]["done"] === true){
          state[action.todo.id]["done"] = false;
        } else if(state[action.todo.id]["done"] === false){
          state[action.todo.id]["done"] = true;
        }
        return merge({}, state);
      } else {
        return merge({}, state, newTodo);
      }

      case REMOVE_TODO:
      let anotherstate = merge({}, state);
      delete anotherstate[action.todo.id];
      return anotherstate;

      default:
        return state;
  }
};

export default todosreducer;

import {combineReducers} from 'redux';
import todosreducer from './todos_reducer';
import stepsreducer from './steps_reducer';


const rootReducer = combineReducers({todos: todosreducer, steps: stepsreducer});

export default rootReducer;

export const getAllTodos = ({ todos }) => (
	Object.keys(todos).map(id => todos[id])
);

export const getFilteredTodos = ({ todos, filter }) => {
	let result = [];
	for (let id in todos) {
		if (todos[id].done === filter) {
			result.push(todos[id]);
		}
	}
	return result;
};

export const stepsByTodoIdMine = ({steps, todoId}) => {
  result = [];
  thekeys = Object.keys(steps);
  for (id in thekeys) {
    if (id === todoId.toString()) {
      result.push(steps[id]);
    }
  }
  return result;
}

export const stepsByTodoId = ({ steps }, todo_id) => {
  const stepsByTodoId = [];
  Object.keys(steps).forEach(stepId => {
    const step = steps[stepId];
    if (steps[stepId].todo_id === todo_id) stepsByTodoId.push(step)
  })
  return stepsByTodoId;
};

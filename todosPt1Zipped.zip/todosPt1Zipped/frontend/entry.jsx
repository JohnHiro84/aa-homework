import React from 'react';
import ReactDOM from 'react-dom';
// import { Provider } from 'react-redux';
import Root from './components/root';
import configureStore  from './store/store';
import {receiveTodo, receiveTodos, removeTodo} from './actions/todo_actions';
import {receiveStep, receiveSteps, removeStep} from './actions/step_actions';

import {getAllTodos, stepsByTodoId} from './reducers/selectors';
document.addEventListener("DOMContentLoaded", () => {
	const preloadedState = localStorage.state ?
    JSON.parse(localStorage.state) : {};
  const store = configureStore(preloadedState);

	window.store = store;
	window.receiveTodos = receiveTodos;
	window.receiveTodo = receiveTodo;
  window.getAllTodos = getAllTodos;
  window.removeTodo = removeTodo;

  window.receiveStep = receiveStep;
	window.receiveSteps = receiveSteps;
	window.removeStep = removeStep;

  window.stepsByTodoId = stepsByTodoId;
	let root = document.getElementById('content');
	ReactDOM.render(
		<Root store={store}/>, root
	);
	document.getElementsByTagName("form")[1].outerHTML = "<br>"

});

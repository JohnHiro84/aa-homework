import React from 'react';
import StepListItemContainer from './step_list_item_container';

class StepListItem extends React.Component {
  constructor(props){
    super(props);
    this.state = {showdetail: false};
    this.handleClick = this.handleClick.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
    this.toggleDetail = this.toggleDetail.bind(this);

  }

  handleClick(e) {
    e.preventDefault();
    this.props.removeStep(this.props.step);
  }
  handleToggle(e) {
    e.preventDefault();
    this.props.receiveStep(this.props.step);
  }
  toggleDetail(e){
    e.preventDefault();
    this.setState({ showdetail: !this.state.showdetail });
  }

  render() {
    const { step } = this.props;

    // let detail;
    // if (this.state.showdetail){
    //   detail = < DetailViewContainer todo={todo} />;
    // }

    return(
        <div className="step-item-div">

            <p>Step:{step.title}</p>
            <p>{step.body}</p>
            <h4> Completed: {step.done.toString()}</h4>
            <button className="stepButton" onClick={this.handleToggle}>Toggle Step</button>
            <div>
            <button className="stepButton" onClick={this.handleClick}>Delete Step</button>
            </div>
        </div>
    );
  }
}


export default StepListItem;

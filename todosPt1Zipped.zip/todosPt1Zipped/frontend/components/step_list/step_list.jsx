import React from 'react';
import StepListItemContainer from '../step_list/step_list_item_container';
import StepForm from './step_form';

const StepList = ({ steps, todo_id, receiveStep }) => {

    let stepItems = steps.map(step => (
      < StepListItemContainer key={`step-list-item${step.id}`} step={step} />

      )
    );

    return(
        <div>
      
          { stepItems }

        
        <StepForm todo_id={todo_id} receiveStep={receiveStep}/>

        </div>
    );
}


export default StepList;

import { connect } from 'react-redux';
import StepListItem from './step_list_item';

import { stepsByTodoId } from '../../reducers/selectors';
import { receiveSteps, removeStep} from '../../actions/step_actions';

const mapStateToProps = (state, { todo_id }) => ({
  steps: stepsByTodoId(state, todo_id),
  todo_id
});


const mapDispatchToProps = dispatch => ({
	receiveStep: step => dispatch(receiveStep(step)),
  removeStep: step => dispatch(removeStep(step))
});
export default connect(null, mapDispatchToProps)(StepListItem);

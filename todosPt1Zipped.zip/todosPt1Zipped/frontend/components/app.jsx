import React from 'react';
import TodoListContainer from './todo/todo_list_container';
import StepListContainer from './step_list/step_list_container';

class App extends React.Component {

  constructor(props) {
    super(props);
  }

  render() {

    return (
      <div className="main-content">
        <h1>Todo List App</h1>

          <p>A simple todos application using react and redux</p>
          <p>Add Todos, click on todos to add steps for it</p>


        <TodoListContainer />
        <StepListContainer />
      </div>
    );
  }
};


export default App;

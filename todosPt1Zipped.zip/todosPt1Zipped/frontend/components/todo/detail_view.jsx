import React from 'react';
import StepListContainer from '../step_list/step_list_container';

class DetailView extends React.Component {
  constructor(props){
    super(props);
    this.handleClick = this.handleClick.bind(this);
    // this.handleToggle = this.handleToggle.bind(this);

  }

  handleClick(e) {
    e.preventDefault();
    this.props.removeTodo(this.props.todo);
  }
  // handleToggle(e) {
  //   e.preventDefault();
  //   this.props.receiveTodo(this.props.todo);
  // }

  render() {
    const { todo } = this.props;

    return(
        <div className="detail_viewer">
        <button className="toggletodo" onClick={this.handleClick}>Delete this todo</button>

          <p>todo body: {todo.body}</p>

        <StepListContainer todo_id={ todo.id } />

        </div>

    );
  }
  }


export default DetailView;

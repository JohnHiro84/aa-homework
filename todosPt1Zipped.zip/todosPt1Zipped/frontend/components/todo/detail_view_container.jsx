import { connect } from 'react-redux';
import DetailView from './detail_view';

import { getAllTodos, getFilteredTodos } from '../../reducers/selectors';
import {receiveTodo, receiveTodos, removeTodo} from '../../actions/todo_actions';

const mapStateToProps = state => ({
	todos: getAllTodos(state),
  state
});


const mapDispatchToProps = dispatch => ({
	receiveTodo: todo => dispatch(receiveTodo(todo)),
	receiveTodos: todos => dispatch(receiveTodos(todos)),
  removeTodo: todo => dispatch(removeTodo(todo)),
	receiveSteps: steps => dispatch(receiveSteps(steps))
});
export default connect(null, mapDispatchToProps)(DetailView);

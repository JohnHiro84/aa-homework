import React from 'react';

class TodoItem extends React.Component {
  constructor(props){
    super(props);
    this.handleClick = this.handleClick.bind(this);
    this.handleToggle = this.handleToggle.bind(this);

  }

  handleClick(e) {
    e.preventDefault();
    this.props.removeTodo(this.props.todo);
  }
  handleToggle(e) {
    e.preventDefault();
    this.props.receiveTodo(this.props.todo);
  }

  render() {
    const { todo } = this.props;

    return(
        <div>
        <li >{todo.title} - {todo.body} Completed: {todo.done.toString()}
        <span><button onClick={this.handleClick}>Delete</button></span>
        <span><button onClick={this.handleToggle}>Toggle</button></span>
        </li>

        </div>

    );
  }
}


export default TodoItem;

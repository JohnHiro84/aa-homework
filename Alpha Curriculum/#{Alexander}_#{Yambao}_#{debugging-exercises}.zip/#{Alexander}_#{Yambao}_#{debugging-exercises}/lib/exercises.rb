# Write a method that capitalizes each word in a string like a book title
# Do not capitalize words like 'a', 'and', 'of', 'over' or 'the'.

require 'byebug'


LITTLE_WORDS = [
  "and",
  "the",
  "over"
]



def titleize(title)
  words = title.split(" ")
  titleized_words = []
  titleized_words = words.map.with_index do |word, idx|
    if idx == 0 #&& LITTLE_WORDS.include?(word) == true
      word.capitalize
    elsif idx > 0 && LITTLE_WORDS.include?(word) == true
      word.downcase
    else
      word.capitalize
    end
  end
  #puts  titleized_words
  return titleized_words.join(" ")
end

#puts titleize("the hi there way the over to go there")

# Write a method that returns the largest prime factor of a given integer.

def prime?(num)
  (2..(num-1)).none? { |factor| num % factor == 0 }
end



def largest_prime_factor(num)

  largest = 0
  prime_numbers = []
  if(num == 0 || num == 1)
    return nil
  end
  (1..num).each do |number|
    if prime?(number) == true && num % number == 0
      prime_numbers << number
    end
  end
  return prime_numbers[-1]

end


# Write a symmetric_substrings method that takes a string and returns an array
# of substrings that are palindromes, e.g. symmetric_substrings("cool") => ["oo"]
# Only include substrings of length > 1.


#this way doesnt work the way they want it in the specs
#
# def symmetric_substrings(str)
#   puts "----------------------------"
#   puts str.length
#
#   output = ""
#   output_array = []
#   if str.length % 2 == 0
#     puts "even"
#       middleIdx = (str.length / 2  ) -1
#       left = str[0..middleIdx]
#       right = str[(middleIdx+1)..-1]
#       rightR = right.reverse
#
#   else str.length % 2 == 1
#     puts str
#     puts "odd"
#     middleIdx = str.length / 2
#     puts middleIdx
#       left = str[0...middleIdx]
#       right = str[(middleIdx+1)..-1]
#       rightR = right.reverse
#       output = str[middleIdx]
#       puts left
#       puts right
#       puts rightR
#       puts output
#   end
#
#
#         i = left.length-1
#         while i >=0
#           puts output + "--------------------------"
#           if left[i] == rightR[i]
#             output = left[i] + output + left[i]
#             puts output + ":::a"
#           else
#             if output.length == 1
#               output = ""
#             end
#             output_array << output
#             puts "output_array:" + output_array.to_s
#             return output_array
#           end
#           puts i
#           i-=1
#         end
#         output_array << output
#         puts "output_array:" + output_array.to_s
#         return output_array
#
# end

def symmetric_substrings(str)
  bound = str.length - 1
  bound2 = bound -1
  candidates = []
  output = []
  if str.length % 2 == 1

      #testing for 3 letter chunks
      i = 1
      while i < bound
        test = str[i-1] + str[i] + str[i+1]
        candidates << test
        i+=1
      end

      #testing for 5 letter chunks
      i = 2
      while i < bound2
        test = str[i-2] + str[i-1] + str[i] + str[i+1] + str[i +2]
        candidates << test
        i+=1
      end
  elsif str.length % 2 == 0
  end

  candidates.each do |cand|
    if cand == cand.reverse
      output << cand
    end
  end
  return output
end

  # symm_subs = ""
  # byebug
  # str.length.times do |start_pos|
  #   (2..(str.length - start_pos)).each do |len|
  #     substr = str[start_pos...(start_pos + len)]
  #     symm_subs << substr if substr = substr.reverse
  #   end
  # end
  #
  # symm_subs



# Write a method that returns `true` if all characters in the string
# are unique and `false` if they are not.

def all_unique_chars?(str)
  letters = str.split('').reject{ |char| char == '  '}
  letters.uniq.length = letters.length
end

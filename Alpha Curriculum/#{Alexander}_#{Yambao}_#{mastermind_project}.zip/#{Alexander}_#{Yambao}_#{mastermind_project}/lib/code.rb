class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  def self.valid_pegs?(array)
    array.all?  { |peg| POSSIBLE_PEGS.include?(peg.upcase)  }
  end

  def initialize(array)
    if Code.valid_pegs?(array)
      @pegs = array.map { |e| e.upcase  }
    else
      raise ArgumentError.new('those pegs arent valid')
    end
  end

  def self.random(number)

    array = []
    number.times do
      array << POSSIBLE_PEGS.keys.sample
    end

    Code.new(array)
  end

  def self.from_string(string)
    array = string.split("")
    Code.new(array)
  end

  def [](index)
    @pegs[index]
  end

  def length
    @pegs.length
  end

  def num_exact_matches(guess_instance)
    count = 0
    @pegs.each.with_index do |peg, i |
      if pegs[i] == guess_instance.pegs[i]
        count+=1
      end
    end
    count
  end

  def num_near_matches(guess_instance)
    inv_count = 0

    non_matches_guess = []
    non_matches_reg = []
    matches = 0

    guess_instance.pegs.each_with_index do |peg, i|
      if peg != pegs[i]
        non_matches_guess << peg
        non_matches_reg << pegs[i]
      elsif peg == pegs[i]
        matches+=1
      end
    end

    pegs_hash = Hash.new(0)
    non_matches_reg.each { |peg| pegs_hash[peg] += 1 }

    guess_hash = Hash.new(0)
    non_matches_guess.each { |peg| guess_hash[peg]+=1 }

    POSSIBLE_PEGS.keys.each do |k|
      if pegs_hash.has_key?(k)
        variance = guess_hash[k] - pegs_hash[k]
        inv_count+= variance.abs
      end
    end
    pegs.length - (matches + inv_count)

  end

  def ==(arg)
    self.pegs == arg.pegs
  end
  def pegs
    @pegs
  end
end

# puts Code.valid_pegs?(["R", "B", "b"])
# coder = Code.new(["R", "B", "b"])
# puts coder.POSSIBLE_PEGS
other_code = Code.new(["R", "G", "R", "B", "B"])
puts other_code.class
puts other_code.to_s

require_relative "code"

class Mastermind
  def initialize(length)
    @secret_code = Code.random(length)
  end

  def print_matches(code_instance)
    print "exact matches: "
    print @secret_code.num_exact_matches(code_instance)
    puts
    print "near matches: "
    print @secret_code.num_near_matches(code_instance)
    puts
  end

  def ask_user_for_guess
    print "Enter a code"
    input = gets.chomp
    guess_instance = Code.from_string(input)
    print_matches(guess_instance)
    @secret_code == guess_instance
  end
end

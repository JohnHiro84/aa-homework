# EASY

# Write a method that returns the range of its argument (an array of integers).
def range(arr)
  # your code goes here
  if (arr[0] != nil && arr[1] !=nil)
    lowest = arr[0]
    biggest = arr[1]
  end
    arr.each_with_index do |ele, i|
      if ele < lowest
        lowest = ele
      end
    end
    arr.each_with_index do |ele, i|
      if ele > biggest
        biggest = ele
      end
    end
    puts biggest - lowest
    return biggest - lowest

end

# Write a method that returns a boolean indicating whether an array is in sorted
# order. Use the equality operator (==), which returns a boolean indicating
# whether its operands are equal, e.g., 2 == 2 => true, ["cat", "dog"] ==
# ["dog", "cat"] => false
def in_order?(arr)
  # your code goes here
  if(arr == arr.sort)
    return true
  else
    return false
  end
end


# MEDIUM

# Write a method that returns the number of vowels in its argument
def num_vowels(str)
  # your code goes here
  vowels = "aeiou"
  count = 0
  str.each_char do |char|
    if vowels.include?(char.downcase) == true
      count+=1
    end
  end
  return count

end

# Write a method that returns its argument with all its vowels removed.
def devowel(str)
  # your code goes here
  vowels = "aeiou"
  devoweled = ""
  str.each_char do |char|
    if vowels.include?(char.downcase) != true
      devoweled+=char
    end
  end
  return devoweled
end


# HARD

# Write a method that returns the returns an array of the digits of a
# non-negative integer in descending order and as strings, e.g.,
# descending_digits(4291) #=> ["9", "4", "2", "1"]
def descending_digits(int)
  # your code goes here
  numbers = int.to_s.split("")
  output = numbers.sort.reverse
  return output
end

# Write a method that returns a boolean indicating whether a string has
# repeating letters. Capital letters count as repeats of lowercase ones, e.g.,
# repeating_letters?("Aa") => true
def repeating_letters?(str)
  # your code goes here
  letters = Hash.new(0)
  charArray = str.downcase.split("")
  charArray.each do |char|
    if letters.has_key?(char) == true
      letters[char]+=1
    elsif letters.has_key?(char) == false
      letters[char] =1
    end
  end
  letters.each_value do |val|
    if val > 1
      return true
    end
  end
  return false
end

# Write a method that converts an array of ten integers into a phone number in
# the format "(123) 456-7890".
def to_phone_number(arr)
  # your code goes here
  #str = arr.split("")
  str = arr.map(&:to_s)
  #print str[0..2]

  output = "(" + str[0..2].join() + ") " + str[3..5].join() + "-" + str[6..-1].join()
  return output
end

# Write a method that returns the range of a string of comma-separated integers,
# e.g., str_range("4,1,8") #=> 7
def str_range(str)
  # your code goes here
  numbersArray = []
  arrayNums = str.split(",")

  #convert array of strings into an array of numbers
  arrayNums.each do |num|
    numbersArray.push(num.to_i)
  end
  lowest = numbersArray[0]
  highest = numbersArray[1]

  #set lowest
  numbersArray.each do |number|
    if number < lowest
      lowest = number
    end
  end

  #set highest
  numbersArray.each do |number|
    if number > highest
      highest = number
    end
  end

  #return range
  return highest - lowest
end


#EXPERT

# Write a method that is functionally equivalent to the rotate(offset) method of
# arrays. offset=1 ensures that the value of offset is 1 if no argument is
# provided. HINT: use the take(num) and drop(num) methods. You won't need much
# code, but the solution is tricky!
def my_rotate(arr, offset=1)
  # your code goes here

    i = 0

    if offset > 0
      while i < offset
        shifted = arr.shift
        arr.push(shifted)
        i+=1
      end

    elsif offset <0
      j = offset
      while j < 0
      popped = arr.pop
      arr.unshift(popped)
      j+=1
      end
    end

  return arr

end

#
# #### sorta works, keep
# # def reverser (word="hello")
# #   yield
# #   return word.reverse
# # end
# #
# # reverser do |word|
# #   return word
# # end
# #
# # def reverser(word)
# #   puts "the program is executing the code inside the method"
# #   yield(word)
# #   puts "now we are back in the method"
# #   puts word.reverse
# #   return word.reverse
# # end
#
# #reverser("james") {|word| puts word}
#
# # reverser = Proc.new do |word|
# #   return word.reverse
# # end
# #
# # reverser.call("hello joe")
#
#
# ###########333another attempt
# # def reverser(word)
# #   puts "the program is executing the code inside the method"
# #   output =  yield(word)
# #   return output
# #   puts word
# #   puts word
# #   puts "now we are back in the method"
# # end
# #
# # jake = "jake"
# # reverser("hello") do |word|
# #   word.reverse
# # end
#
# #
# # def reverser(word)
# #   reverse_it = Proc.new { |word| puts word.reverse }
# #   reverse_it.call(word)
# # end
#
#
# def reverser(word, &proc3)
#
#   val3 = proc3.call(word)
#   #val3 = yield(word)
#
#   sentence = val3.split(" ")
#   output =  []
#
#   sentence.each do |e|
#     output << e.reverse
#   end
#   puts output
#   output
# end
#
# reverser ("hello there") do |w|
#   puts w
#   w
#
# end
#
# def reverser2(word,  &proc3)
#
#   val3 = proc3.call(word)
#   #val3 = yield(word)
#   return val3
# end
#
# reverser2("jamming with you") do |w|
#   sentence = w.split(" ")
#   output = []
#   sentence.each do |e|
#     output << e.reverse
#   end
#   output
# end
#
#
#
#
#
#
#
#
# # def reverser(word, proc1)
# #   reversed = proc1.call(word)
# #   return reversed
# # end
# #
# # proc_word = Proc.new {|word| word.reverse }
# #
# # puts reverser("hello", proc_word) do |word|
# #
# # end
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# #
# # def three_times (word="default")
# #   puts word
# #   yield
# #
# # end
# #
# #
# # #default block
# #
# # three_times do |word|
# #   puts word.to_s + "defualt done"
# #   puts "this strng here"
# # end
# #
# # three_times("hell0!")
#
#
#
#
#
#
#
#
#
# # def reverser(sentence)
# #
# #   sentence.split(" ").map{ |word| reverse_word(word)}.join(" ")
# #   #sentence.split(" ").map(&:reverse_word(word)).join(" ")
# # end
# # #
# # def reverse_word(word)
# #   word.reverse
# # end
#
#
# # reverser2 = Proc.new { |word| word.reverse }
# #
# # puts reverser2.call("hello") # prints "Hello Zimmy"
# #
# #
# # def reverser(word, reverser2)
# #   return &reverser2
# # end
# #
# # add_one = Proc.new { |i| i + 1}
# #
# # [1, 2, 3].map(&add_one) # => [2, 3, 4]
#
#
# # proc_add_1 = Proc.new {|num| num + 1}
# #
# # chain_blocks(proc_add_1, proc_add_2) do |num|
# #   num + 3
# # end
#
#
#
# # def reverser(&block)
# #   block.call.reverse
# # end
#
#
# def adder(number)
#   return number + 1
# end
#
#
# #puts reverser("hi there")

def reverser(&prc)
  sentence = prc.call
  array = sentence.split(" ")
  output = array.map { |word| word.reverse }
  output.join(" ")
end


def adder(start_val=1, &proc)
  val1 = proc.call(start_val)
  out = val1 + start_val
  puts out
  out
end


def repeater(input=1, &proc)
  i = 1
  while i <= input
    value = proc.call(input)
    i+=1
  end
end

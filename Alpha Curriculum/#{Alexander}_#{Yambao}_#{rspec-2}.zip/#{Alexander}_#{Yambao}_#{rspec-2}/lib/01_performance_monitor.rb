


# def measure (&proc)
#   start = Time.now
#   proc.call
#   finish = Time.now
#   diff = finish - start
#
# end


def measure(input=1, &proc)
    start = Time.now
  i = 1
  while i <= input

    value = proc.call(input)

    i+=1
  end
  finish = Time.now
  diff = finish - start
  output = diff / input
end

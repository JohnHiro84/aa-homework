require 'byebug'

# EASY

# Define a method that returns the sum of all the elements in its argument (an
# array of numbers).
def array_sum(arr)
  if arr.length > 0
    arr.reduce(:+)
  else
    0
  end
end

# Define a method that returns a boolean indicating whether substring is a
# substring of each string in the long_strings array.
# Hint: you may want a sub_tring? helper method
def in_all_strings?(long_strings, substring)
  long_strings.each do |str|
    array = str.split(" ")
    sub_str_check = array.any? { |word| word == substring}
      if sub_str_check == false
        return false
      end
    end
  return true
end



# Define a method that accepts a string of lower case words (no punctuation) and
# returns an array of letters that occur more than once, sorted alphabetically.
def non_unique_letters(string)
    hash = Hash.new(0)
    output = []
    string.each_char do |char|
      hash[char]+=1
    end
    hash.each do |k, v|
      if v > 1 && k != " "
        output << k
      end
    end
    return output
end

# Define a method that returns an array of the longest two words (in order) in
# the method's argument. Ignore punctuation!
def longest_two_words(string)

  words = string.split(" ")
  hash = Hash.new(0)
  output_array = []
  words.each { |word| hash[word] = word.length}

  output_hash = hash.sort_by { |k, v| v}
  output_array << output_hash[-1][0]
  output_array << output_hash[-2][0]
  return output_array

end

# MEDIUM

# Define a method that takes a string of lower-case letters and returns an array
# of all the letters that do not occur in the method's argument.
def missing_letters(string)
  hash = Hash.new(0)
  alpha = "abcdefghijklmnopqrstuvwxyz"
  output = []
  string.each_char do |char|
    hash[char]+=1
  end
  alpha.each_char do |char|
    if hash.has_key?(char) == false
      output << char
    end
  end
  return output

end

# Define a method that accepts two years and returns an array of the years
# within that range (inclusive) that have no repeated digits. Hint: helper
# method?
def no_repeat_years(first_yr, last_yr)
  output = []
  (first_yr.. last_yr).each do |n|
    if not_repeat_year?(n) == true
      output << n
    end
  end
  return output
end

def not_repeat_year?(year)
  yr = year.to_s
  array = yr.split("")
  repeat_year = true
  hash = Hash.new(0)

  array.each do |num|
    hash[num]+=1
  end
  hash.each_value do | v|
    if v > 1
      repeat_year = false
    end
  end
  return repeat_year
end

# HARD

# Define a method that, given an array of songs at the top of the charts,
# returns the songs that only stayed on the chart for a week at a time. Each
# element corresponds to a song at the top of the charts for one particular
# week. Songs CAN reappear on the chart, but if they don't appear in consecutive
# weeks, they're "one-week wonders." Suggested strategy: find the songs that
# appear multiple times in a row and remove them. You may wish to write a helper
# method no_repeats?
def one_week_wonders(songs)
  removed = []
  one_week = []
  output = []

  i = 1
  while i < songs.length-1
    if songs[i] == songs[i+1] || songs[i-1] == songs[i]
      removed << songs[i]
    elsif songs[i] != songs[i+1] || songs[i-1] != songs[i]
      one_week << songs[i]
    end
    i+=1
  end
  one_week.each do |song|
    if removed.include?(song) == false && output.include?(song) == false
      output << song
    end
  end

  return output
end

def no_repeats?(song_name, songs)

end

# Define a method that, given a string of words, returns the word that has the
# letter "c" closest to the end of it. If there's a tie, return the earlier
# word. Ignore punctuation. If there's no "c", return an empty string. You may
# wish to write the helper methods c_distance and remove_punctuation.

def for_cs_sake(string)
  array_words = string.split(" ")
  clean_words = []
  hash = Hash.new(0)
  array_words.each do |word|
    c = word.gsub(/\W+/, '')
    clean_words << c
  end
  clean_words.each do |word|
    hash[word] = c_distance(word)
  end
  output = hash.sort_by { |k, v| v}
  return output[0][0]
end

def c_distance(word)
  c_from_end = 1000
  word.each_char.with_index do |char, i|
    if char == "c"
      c_from_end = word.length - i
    end
  end
  return c_from_end
end

# Define a method that, given an array of numbers, returns a nested array of
# two-element arrays that each contain the start and end indices of whenever a
# number appears multiple times in a row. repeated_number_ranges([1, 1, 2]) =>
# [[0, 1]] repeated_number_ranges([1, 2, 3, 3, 4, 4, 4]) => [[2, 3], [4, 6]]
#




def repeated_number_ranges(arr)

  hash = Hash.new(0)
  arr.each_with_index do |num, i|

    if hash.has_key?(num) == false
      hash[num] = i.to_s
    else
      hash[num] = hash[num] + i.to_s
    end
  end

  array1 = []
  hash.each_value do |val|
    if val.length >= 2
      array1 << val
    end
  end
  array1.each do |str|
    numbers = str.split("")

  end

  output_final = []
  pushed_pair = []
  array1.each do |str_nums|

    i = 0
    new_a = []
    starter = 9000

    while i < str_nums.length
      left = str_nums[i].to_i
      right = str_nums[i+1].to_i - 1

      if left  == right && starter == 9000
        #dont terminate
        starter = str_nums[i].to_i

      elsif left == right && starter != 9000
        # dont set starter

      elsif left != right
        ending = str_nums[i].to_i
        pushed_pair = [starter, ending]
        output_final << pushed_pair
        starter = 9000
      end
      i+=1
    end
  end
  return output_final.sort

end


puts repeated_number_ranges([1, 2, 3, 3, 4, 4, 4])

# works unedited backup
# def repeated_number_ranges(arr)
#
#   hash = Hash.new(0)
#   arr.each_with_index do |num, i|
# #    puts "num" + num.to_s
# #    puts "index:" + i.to_s
#     if hash.has_key?(num) == false
#       hash[num] = i.to_s
#     else
#       hash[num] = hash[num] + i.to_s
#     end
#   end
#
#   #{1=>"0", 2=>"1", 3=>"2378", 4=>"456"}
#   # array1 = ["2378", "456"]
#   array1 = []
#   hash.each_value do |val|
#     if val.length >= 2
#       array1 << val
#     end
#   end
#   array1.each do |str|
#     numbers = str.split("")
#
#   end
#   puts "------------------->" + array1.to_s
#   output_final = []
#   pushed_pair = []
#   array1.each do |str_nums|
#     #["2378", "456"]
#
#
#
#
#
#     i = 0
#     new_a = []
#     starter = 9000
#
#
#     while i < str_nums.length
#       left = str_nums[i].to_i
#       right = str_nums[i+1].to_i - 1
#       puts "l" + left.to_s
#       puts "r" + right.to_s
#
#
#
#       if left  == right && starter == 9000
#         #dont terminate
#         puts "is ok setting start" + str_nums[i].to_s
#         starter = str_nums[i].to_i
#
#
#       elsif left == right && starter != 9000
#         # dont set starter
#         puts "starter remains:" + str_nums[i].to_s
#
#       elsif left != right
#         #terminate & set ending
#         ending = str_nums[i].to_i
#         puts "ending:" + str_nums[i].to_s
#         pushed_pair = [starter, ending]
#         output_final << pushed_pair
#         print "============================\n" + pushed_pair.to_s
#         print "\n\n" + output_final.to_s
#         starter = 9000
#       end
#       i+=1
#
#     end
#
#
#
#   end
#   print "\n********************outputfinaltos:\n" + output_final.to_s
#   return output_final.sort
#
# end




# def repeated_number_ranges(array)
#
#   output = []
#   starting = 0
#   ending = 0
#   i = 0
#   while i < array.length
#
#     j = 0
#     while j < array.length
#
#       if j > i
#
#         if array[i] == array[j]
#           matching = true
#           starting = i
#         elsif array[i] != array[j] && matching == true
#           ending = j -1
#           if starting != ending
#             output << [starting, ending]
#           end
#         end
#       end
#       j+=1
#       ending = 0
#     end
#     matching == false
#     i+=1
#   end
#   return output
# end

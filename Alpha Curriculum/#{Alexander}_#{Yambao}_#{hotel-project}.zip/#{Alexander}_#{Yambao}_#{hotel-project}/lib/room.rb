class Room
  def initialize(capacity)
    @capacity = capacity
    @occupants = []
  end

  def occupants
    @occupants
  end

  def capacity
    @capacity
  end

  def full?
    if @occupants.length < @capacity
      false
    elsif @occupants.length == @capacity
      true
    end
  end

  def available_space
    if full? == false
      @capacity - @occupants.length
    end
  end

  def add_occupant(name)
    if full? == false
      @occupants << name
      true
    else
      false
    end
  end
end
#
# green = Room.new(5)
# puts green.capacity

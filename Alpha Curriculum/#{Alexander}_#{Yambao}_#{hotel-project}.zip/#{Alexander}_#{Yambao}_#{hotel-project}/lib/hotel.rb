require_relative "room"

class Hotel
  def initialize(name, rooms )
    @name = name
    @rooms = Hash.new(0)
    rooms.each do |key, val|

      @rooms[key.to_s] = Room.new(val)
    end
  end

  def name
    array = @name.split(" ")
    array.map{|w| w.capitalize }.join(" ")
  end

  def room_exists?(name)
    @rooms.has_key?(name)
  end

  def check_in(person, room)
    room_exists?(room)
    if room_exists?(room) == true
      #@rooms[room].add_occupant(person)
      #puts @rooms[room].add_occupant(person)
      if rooms[room].add_occupant(person) == true
        print 'check in successful'
      elsif rooms[room].add_occupant(person) == false
        print 'sorry, room is full'
      end

    elsif room_exists?(room) == false
      print 'sorry, room does not exist'
    end
  end

  def has_vacancy?
    rooms_avail = 0
    @rooms.each do |room_name, room_obj|
      if room_obj.full? == false
        true
      end

        rooms_avail += room_obj.capacity - room_obj.occupants.length
    end
    if rooms_avail > 0
      true
    else
      false
    end
  end

  def list_rooms
    @rooms.each do |name, obj|
      print name + ' ' + (obj.capacity - obj.occupants.length ).to_s

      # print name + " " + obj.available_space.to_s
      # puts
    end
  end
  def rooms
    @rooms
  end
end

##hilton = Hotel.new("hilton", {"suite": 9, "standard": 2})
# puts hilton.rooms["suite"].capacity
# puts "room exists?"
#
# puts hilton.room_exists?("suite")
#
# puts hilton.check_in("Joe", "suite")
# puts hilton.check_in("Joe2", "suite")
# puts hilton.check_in("Joey", "standard")
# puts hilton.check_in("Joe3", "standard")
# puts hilton.check_in("Joe8", "standard")
#
# puts hilton.check_in("Joe6", "suite")
#
# puts "aaaaaaaaaa"
# puts hilton.rooms["suite"].add_occupant("Hema")
#
# puts hilton.rooms
#
# puts "cccccc"
# puts hilton.has_vacancy?
# hilton.list_rooms

#puts hilton.room_exists?("suite")
#hilton.check_in("joe", "suite")

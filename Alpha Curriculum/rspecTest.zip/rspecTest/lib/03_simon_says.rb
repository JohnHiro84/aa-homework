


def echo(word)
  return word
end

def shout(word)
  return word.upcase
end


def repeat(word, times=2)
  output = ""
  i = 1
  if times == 0
    return word
  elsif times > 0
    times.times do
       output+= word

       if i < times
         output+=" "
       end
       i+=1
    end

  end
  return output
end

def start_of_word(word, letters=1)
  output = ""
  i = 0
  letters.times do
    output+= word[i]
    i+=1
  end
  return output
end

def first_word(sentence)
  array = sentence.split(" ")
  return array[0]
end

def titleize(word)
  output_array = []
  array = word.split(" ")
  array.each_with_index do |word, idx|

    if idx == 0
      output_array << word.capitalize

    elsif idx !=0
      if word == "the" || word == "and" || word == "over"
        output_array << word
      else
        output_array << word.capitalize
      end
    end

  end
  return output_array.join(" ")
end



def ftoc(faren)
  return (faren - 32) * 5/9
end


def ctof(c)

 return ((c * 1.8) + 32)

end


ctof(100)

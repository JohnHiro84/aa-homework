




def pig_latin(word)
  vowels = "aeiou"
  print "here"

  if vowels.include?(word[0]) == true && word[0] != "q"
        return word + "ay"
  elsif word[0] == "q" && vowels.include?(word[1]) == true
        return word[2..-1] + word[0..1] + "ay"
  elsif vowels[0] == "s" && vowels[1] == "q" && vowels[2] == "u"
        return word[3..-1] + word[0..2] + "ay"
  elsif vowels.include?(word[0]) == false && vowels.include?(word[1]) != false
        return word[1..-1] + word[0] + "ay"
  elsif vowels.include?(word[0]) == false && vowels.include?(word[1]) == false && vowels.include?(word[2]) != false  && word[1] != "q"
        return word[2..-1] + word[0..1] + "ay"
  elsif word[0] == "s" && word[1] == "q" && word[2] == "u"
        return word[3..-1] + word[0..2] + "ay"
  elsif vowels.include?(word[0]) == false && vowels.include?(word[1]) == false && vowels.include?(word[2]) == false
        return word[3..-1] + word[0..2] + "ay"
  end

end

def translate(sentence)
  words = sentence.split(" ")
  output = []
  words.each { |w| output << pig_latin(w)}
  return output.join(" ")
end

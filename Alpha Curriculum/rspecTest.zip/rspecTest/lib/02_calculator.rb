



def add(num1, num2)
  return num1 + num2
end

def subtract(num1, num2)
  return num1 - num2
end


def sum(array)
  output = 0
  if array.length > 0
    array.each{ |num| output+=num}
  end
  return output
end

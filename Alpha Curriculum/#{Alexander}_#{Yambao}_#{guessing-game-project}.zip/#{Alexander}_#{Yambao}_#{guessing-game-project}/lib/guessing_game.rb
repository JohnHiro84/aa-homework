class GuessingGame
  def initialize(min, max)
    @min = min
    @max = max
    @secret_num = min + rand(max)
    @num_attempts = 0
    @game_over = false
  end


  #getters
  def secret_num
    @secret_num
  end

  def num_attempts
    @num_attempts
  end

  def game_over?
    @game_over
  end

  def check_num(num)
    @num_attempts+=1
    if num == @secret_num
      print "you win"
      @game_over = true
    elsif num > @secret_num
      print 'too big'
    elsif num < @secret_num
      print 'too small'
    end
  end

  def gets=(num)
    num = gets
  end
  def ask_user
    print 'enter a number'
    guess = gets.chomp.to_i
    check_num(guess)
  end

end
#
# gg = GuessingGame.new(1,90)
# puts gg.secret_num
#
#
# guessing_game = GuessingGame.new(2, 8)
#
# until guessing_game.game_over?
#   guessing_game.ask_user
#   puts "---------------"
# end

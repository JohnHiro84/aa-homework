# EASY

# Return the argument with all its lowercase characters removed.
def destructive_uppercase(str)
  alpha_lower = "abcdefghijklmnopqrstuvwxyz"
  output = ""
  if str.length > 0
    str.each_char do |char|
        if alpha_lower.include?(char) != true
          output+=char
        end
      end
  end
  return output
end

# Return the middle character of a string. Return the middle two characters if
# the word is of even length, e.g. middle_substring("middle") => "dd",
# middle_substring("mid") => "i"
def middle_substring(str)
  mod_two = str.length % 2
  output = ""
  if mod_two == 0 && str.length > 1
    letter_two_idx = str.length / 2
    letter_one_idx = letter_two_idx -1
    output = str[letter_one_idx] + str[letter_two_idx]
    return output
  elsif mod_two == 1 && str.length >0
    letter_one_idx =  str.length / 2
    return str[letter_one_idx]
  end
end


# Return the number of vowels in a string.
#VOWELS = %w(a e i o u)
def num_vowels(str)
  vowels = "aeiou"
  count = 0
  str.each_char do |char|
     if vowels.include?(char) == true
       count+=1
     end
  end
  return count
end

# Return the factoral of the argument (num). A number's factorial is the product
# of all whole numbers between 1 and the number itself. Assume the argument will
# be > 0.
def factorial(num)
  output=1
 (1..num).each {|n| output*=n}
 return output
end


# MEDIUM

# Write your own version of the join method. separator = "" ensures that the
# default seperator is an empty string.
def my_join(arr, separator = "")
  output = ""
  i = 0

  while i <arr.length
     ele_sep = arr[i] + separator
    if i != arr.length-1
      output += ele_sep
    elsif i == arr.length-1
      output += arr[i]
    end
    i+=1
  end
  return output
end

# Write a method that converts its argument to weirdcase, where every odd
# character is lowercase and every even is uppercase, e.g.
# weirdcase("weirdcase") => "wEiRdCaSe"
def weirdcase(str)
  array = str.split("")
  output = []

  array.each_with_index do |char, i|
    if i % 2 == 1
      output.push(char.upcase)
    elsif i % 2 == 0 || i ==0
      output.push(char.downcase)
    end

  end
  return output.join("")
end


# Reverse all words of five more more letters in a string. Return the resulting
# string, e.g., reverse_five("Looks like my luck has reversed") => "skooL like
# my luck has desrever")
def reverse_five(str)
  array = str.split(" ")
  output = []
  array.each do |word|
    if word.length >= 5
      output.push(word.reverse)
    elsif word.length <5
      output.push(word)
    end
  end
  return output.join(" ")
end

# Return an array of integers from 1 to n (inclusive), except for each multiple
# of 3 replace the integer with "fizz", for each multiple of 5 replace the
# integer with "buzz", and for each multiple of both 3 and 5, replace the
# integer with "fizzbuzz".
def fizzbuzz(n)
  output = []
  i = 1
  while i <= n
    if i % 3 == 0 && i % 5 == 0
      output.push("fizzbuzz")
    elsif i % 3 == 0 && i % 5 != 0
      output.push("fizz")
    elsif i % 3 != 0 && i % 5 == 0
      output.push("buzz")
    else
      output.push(i)
    end
    i+=1
  end
  return output
end


# HARD

# Write a method that returns a new array containing all the elements of the
# original array in reverse order.
def my_reverse(arr)
  return arr.reverse
end

# Write a method that returns a boolean indicating whether the argument is
# prime.
def prime?(num)
  count = 0
  i = 1
  while i <= num
    if num % i == 0
      count+=1
    end
    i+=1
  end
  if count > 2 || num == 1
    return false
  else
    return true
  end
end

# Write a method that returns a sorted array of the factors of its argument.
def factors(num)
  output = []
  i = 1
  while i <= num
    if num % i == 0
      output.push(i)
    end
    i+=1
  end
  return output


end

# Write a method that returns a sorted array of the prime factors of its argument.
def prime_factors(num)
  output = []
  output2 = []
  i = 1
  while i <= num
    if prime?(i) == true
      output.push(i)
    end
    i+=1
  end
  output.each do |number|
    if num % number == 0
      output2.push(number)
    end
  end
  return output2
end


# Write a method that returns the number of prime factors of its argument.
def num_prime_factors(num)
  count = 0
  i = 1
  while i <= num
    if prime?(i) == true  && num % i == 0
      count+=1
    end
    i+=1
  end
  return count
end


# EXPERT

# Return the one integer in an array that is even or odd while the rest are of
# opposite parity, e.g. oddball([1,2,3]) => 2, oddball([2,4,5,6] => 5)
def oddball(arr)
  even_count = 0
  odd_count = 0
  arr.each_with_index do |num, idx|
    if num % 2 == 0
      even_count+=1
    elsif num % 2 == 1
      odd_count+=1
    end
  end

  if even_count > odd_count

    arr.each_with_index do |num, i|
      if num % 2 == 1
        return num
      end
    end

  elsif odd_count > even_count
    arr.each_with_index do |num, i|
      if num % 2 == 0
        return num
      end
    end


  end
end

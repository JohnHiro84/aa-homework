class Board
  def initialize(n)
    @grid = []
    n.times do
      @grid << Array.new(n, :N)
    end

    @size = n * n
    #@ship_count = @size / 4

  end

    def size
      @size
    end

    def [](position)
      row, col = position
      @grid[row][col]
    end

    def []= (position, val)
      row, col = position
      @grid[row][col] = val
    end

    def grid
      @grid
    end

    def num_ships
      count = 0
      @grid.each do |subarray|
        subarray.each { |ele| count+=1 if ele == :S}
      end
      count
    end


    def attack(position)
      if self[position] == :S
        self[position] = :H
        puts "you sunk my battleship!"
        true
      elsif self[position] == :N
        self[position] = :X
        false
      end
    end
    # def attack(position)
    #
    #   if self[position] == :S
    #     self[position]= :H
    #     print "you sunk my battleship!"
    #     true
    #   elsif self[position] != :S
    #     self[position]= :X
    #     false
    #   end
    # end

    def place_random_ships
      total_ships = @size * 0.25

      while self.num_ships <  total_ships
        rand_row = rand(0...@grid.length)
        rand_col = rand(0...@grid.length)
        pos = [rand_row, rand_col ]
        self[pos] = :S
      end
    end

    def hidden_ships_grid
      hidden_grid = []
      @grid.each do |sub|
        row = []
        sub.each do |ele|
          if ele != :S
            row << ele
          elsif ele == :S
            row << :N
          end
        end
        hidden_grid << row
      end
      hidden_grid
    end


      # length = Math.sqrt(size).to_i
      # length.times do
      #   hidden_grid << Array.new(length, :N)
      # end
      # hidden_grid

    def self.print_grid(grid_ins)
      grid_ins.each do |row|
        puts row.join(" ")
      end
    end

    def print
      Board.print_grid(self.hidden_ships_grid)
    end

    def cheat
      Board.print_grid(@grid)
    end
end
#
# board = Board.new(10)
# puts board.[]=([2,2], "P")
# board.print

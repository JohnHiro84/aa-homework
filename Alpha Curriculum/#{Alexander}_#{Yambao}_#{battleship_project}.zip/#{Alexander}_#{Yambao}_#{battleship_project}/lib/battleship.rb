require_relative "board"
require_relative "player"

class Battleship
  def initialize(n)
    @player = Player.new
    @board = Board.new(n)
    @remaining_misses = @board.size / 2
  end

  def board
    @board
  end

  def player
    @player
  end

  def start_game
    @board.place_random_ships
    @board.print
    print @board.num_ships
  end

  def lose?
    if @remaining_misses <= 0
      print 'you lose'
      true
    else
      false
    end
  end


  def win?
    if @board.num_ships == 0
      print 'you win'
      true
    else
      false
    end
  end

  def game_over?
    if win? == true || lose? == true
      true
    else
      false
    end
  end

  def turn

    attack_success = @board.attack(@player.get_move)
    @board.print
    if attack_success == false  
      @remaining_misses-=1
    end
    print @remaining_misses
  end
end

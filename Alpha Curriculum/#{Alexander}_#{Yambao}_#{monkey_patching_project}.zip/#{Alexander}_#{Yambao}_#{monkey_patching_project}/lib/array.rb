# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
  def span
     if self.length == 0
       nil
     else
       self.sort[-1] - self.sort[0]
     end
  end
end

class Array
  def average
    if self.length == 0
      nil
    else
      sum = 0.0
      self.each { |n|sum += n  }
      sum / self.length
    end

  end
end

class Array
  def median
    sorted = self.sort
    if self.length == 0
      nil
    elsif self.length % 2 == 0
      ele1 = sorted[(self.length / 2.0)]
      ele2 = sorted[(self.length / 2.0) -1]
      (ele1 + ele2) /2.0

    elsif self.length % 2 == 1
      sorted[self.length / 2]
    end
  end
end

class Array
  def counts
    hash = Hash.new(0)
    self.each { |ele| hash[ele] +=1 }
    hash
  end
end

class Array
  def my_count(val)
    count = 0
    self.each{ |v| count+=1 if v == val}
    count
  end
end

class Array
  def my_index(val)

    if self.include?(val) == true
      return self.index(val)
    else
      nil
    end
  end
end

class Array
  def my_uniq
    output = []
    self.each { |ele| output << ele if output.include?(ele) == false}
    output
  end
end

class Array
  def my_transpose
    arr0 = []
    arr1 = []
    arr2 = []
    output = []
    i = 0
    while i < self.length
      j = 0
      while j < self.length
        if j == 0
          arr0<< self[i][0]
        elsif j == 1
          arr1 << self[i][1]
        elsif j == 2
          arr2 << self[i][2]
        end
        j+=1
      end
      i+=1
    end
    output << arr0 if arr0.length > 0
    output << arr1 if arr1.length > 0
    output << arr2 if arr2.length > 0
    output
  end

end

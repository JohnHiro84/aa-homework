require_relative "employee"

class Startup
  def initialize(name, funding, salaries)
    @name = name
    @funding = funding

    @employees = []
    @salaries = salaries
    @salaries = Hash.new(0)

    salaries.each do |key, val|
      @salaries[key.to_s] = val
    end

  end

  def name
    @name
  end

  def funding
    @funding
  end

  def salaries
    @salaries
  end

  def employees
    @employees
  end

  def valid_title?(string)
    @salaries.has_key?(string)
  end

  def >(other_company)
    funding > other_company.funding
  end

  def hire(name, title)
    if valid_title?(title)
      employee = Employee.new(name, title)
      @employees << employee
    elsif valid_title?(title) == false
      raise ArgumentError.new('Everyone must have a first name.')
    end
  end

  def size
    @employees.length
  end

  def pay_employee(emp_instance)

    if salaries.has_key?(emp_instance.title) && funding > salaries[emp_instance.title]

       emp_instance.pay(salaries[emp_instance.title])
       @funding -= salaries[emp_instance.title]
    elsif @funding < salaries[emp_instance.title]
      raise
    end
  end

  def payday
    employees.each{ |employee| pay_employee(employee)}
  end

  def average_salary
    ave = 0
    salaries.each_value do | sal|
      ave+= sal / 1.0
    end
    return (ave / salaries.keys.length) + 150  ##assumption that all salaries boosted up to sound better?
  end

  def close
    @employees = []
    @funding = 0

  end

  def acquire (another_startup)
    @funding+= another_startup.funding

    another_startup.employees.each do |employee_other|
     @employees.push(employee_other)
    end

    another_startup.salaries.each do |title, value|
      if @salaries.include?(title) == false
        @salaries[title] = value
      end
    end

    another_startup.close
  end

end

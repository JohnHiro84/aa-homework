



class LRUCache
  attr_accessor :size, :elements
   def initialize(size)
     @elements = []
     @size = size
   end

   def count
     # returns number of elements currently in cache
     @elements.length
   end

   def add(el)
     removelru(el)
     # adds element to cache according to LRU principle
     elements << el
   end

   def show
     # shows the items in the cache, with the LRU item first
     elements
   end

   private
   # helper methods go here!
   def removelru (el)

     ##if element is allready present, remove it from its old position
     if elements.include?(el) == true
       elements.delete(el)
     elsif elements.length == size
       ##remove lru element
       elements.shift
     end

   end

 end

 ##not  atypical LRU-cache

 ##because, probably raely slow, uses an array rather than a set
 ##o(n) because it has to scan each element
 ##how to make it faster?
 ## use a set, make buckets, sequential places in memory divide by the number of buckets,
 ## instead of needing to scan each like in o(n)
 ## you could immediately jump to the bucket, n should be close, or slightly smaller than k (num of buckets)
 #~ 1 item in a bucket, instead of scanning length of array times, you could immediately jump to the bucket,
 # prob only have to scan once, maybe 2 or 3 times, but typically way less than an array, ~ 0(1) time
 

class Node
  attr_reader :key
  attr_accessor :val, :next, :prev, :index

  def initialize(key = nil, val = nil)
    @key = key
    @val = val
    @next = nil
    @prev = nil
    @index = nil
  end

  def to_s
    "#{@key}: #{@val}"
  end

  def next_include?(value)
    if value == @key
      true
    elsif @next == nil
      false
    else
      self.next.next_include?(value)
    end
  end

  def get_node(key)
    if key == @key
      self
    elsif @next == nil
      nil
    else
      self.next.get_node(key)
    end
  end

  def remove

    # optional but useful, connects previous link to next link
    # and removes self from list.
  end
end

class LinkedList
  attr_accessor :head, :tail, :num_nodes
  include Enumerable

  def initialize
    @head = Node.new
    @tail = Node.new
    head.next = tail
    tail.prev = head
    @num_nodes = 0
  end

  def [](i)
    each_with_index { |link, j| return link if i == j }
    nil
  end

  def first
    if head.next != tail
      head.next
    else
      head
    end
  end

  def last
    if tail.prev != head
      tail.prev
    else
      tail
    end
  end

  def empty?
    @head.next == tail
  end

  def get(key)
    #if  head.get_node(key) != nil
      head.get_node(key)
    #end
  end

  def include?(key)
    if head.key == key
      true
    else
      head.next_include?(key)
    end
  end

  def append(key, val)

    ##appending one node
    if head.next == tail
      new = Node.new(key, val)
      new.index = num_nodes
      new.next = tail
      new.prev = head
      tail.prev = new
      head.next = new
    elsif tail.prev != head
      new = Node.new(key, val)
      new.index = num_nodes
      new.next = tail
      new.prev =  tail.prev
      tail.prev.next = new
      tail.prev = new
    end
    @num_nodes +=1

  end

  def update(key, val)
    if include?(key) == true
      get(key).val = val
      true
    else
      false
    end
  end

  def remove(key)
    current_node = get(key)
    current_node.prev.next = current_node.next
    current_node.next.prev = current_node.prev
  end

  def each
  end

  # uncomment when you have `each` working and `Enumerable` included
  # def to_s
  #   inject([]) { |acc, link| acc << "[#{link.key}, #{link.val}]" }.join(", ")
  # end
end


ll = LinkedList.new
ll.append("a", 1)
ll.append("b", 2)
ll.append("c", 3)

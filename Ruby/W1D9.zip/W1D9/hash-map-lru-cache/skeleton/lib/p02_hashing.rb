# class Fixnum
#   # Fixnum#hash already implemented for you
# end

class Array
  def hash
    hash = "123"
    self.each do |ele|
      hash+= ele.to_s
    end
    hash.to_i
  end
end

class String
  def hash
    output_hash = "999"
    values = 'abcdefghijklmnopqrstuvwxyz'
    self.each_char do |letter|
      if values.include?(letter) == true
        if values.index(letter) < 10
          plus_o = "0" + values.index(letter).to_s
          output_hash += plus_o
        elsif values.index(letter) >= 10
          output_hash += values.index(letter).to_s
        end
      end
    end
    output_hash.to_i
  end
end

class Hash
  # This returns 0 because rspec will break if it returns nil
  # Make sure to implement an actual Hash#hash method
  def hash
    values = 'abcdefghijklmnopqrstuvwxyz'
    nums = '0123456789'
    output_int = "9999"
    self.sort.each  do |k, v|
      if values.include?(k.to_s)

        if values.index(k.to_s) < 10
          plus_o = "0" + values.index(k.to_s).to_s
          output_int += plus_o
        elsif values.index(k) >= 10
          output_int += values.index(k.to_s).to_s
        end
      end
      if nums.include?(v.to_s)
        output_int += "9999"
        if nums.index(v.to_s) < 10
          plus_o = "0" + nums.index(v.to_s).to_s
          output_int += plus_o
        elsif nums.index(v.to_s) >= 10
          output_int += nums.index(v.to_s).to_s
        end
      end
      puts k
    end
    output_int.to_i
  end
end
# abc = Hash.new(0)
# abc["a"] = 8
# print abc.hash

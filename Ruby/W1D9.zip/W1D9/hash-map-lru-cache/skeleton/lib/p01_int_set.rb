class MaxIntSet
  attr_accessor :length, :store
  def initialize(max)
    @store = Array.new(max, false)
    @length = max - 1
  end

  def insert(num)
    if is_valid?(num) == true
      @store[num] = true
    else

    end
    is_valid?(num)
  end

  def remove(num)
    if is_valid?(num) == true && @store[num] == true
      @store[num] = false
    end
    is_valid?(num)
  end

  def include?(num)
    if @store[num] == true
      return true
    else
      false
    end
  end

  def error_range(x)
    raise ArgumentError, 'Out of bounds' unless x <= length && x >= 0
  end

  private

  def is_valid?(num)
    if num <= length && num >= 0
      true
    else
      raise ArgumentError, 'Out of bounds' unless num <= length && num >= 0
      false
    end
  end

  def validate!(num)
  end
end


class IntSet

  attr_accessor :store
  def initialize(num_buckets = 20)
    @store = Array.new(num_buckets) { Array.new }
  end

  def insert(num)

    self[num % @store.length] << num
  end

  def remove(num)
    if include?(num) == true
      self[num % @store.length].delete(num)
      true
    else
      false
    end
  end

  def include?(num)
    self[num % @store.length].include?(num)
  end


  private
  def [](num)
    @store[num]
    # optional but useful; return the bucket corresponding to `num`
  end

  def num_buckets
    @store.length
  end
end
require 'byebug'

class ResizingIntSet
  attr_accessor :count, :store, :reshuffle, :store2

  def initialize(num_buckets = 20)
    @store = Array.new(num_buckets) { Array.new }
    @store2 = []
    @count = 0
    @reshuffle = false
  end

  def insert(num)
    if include?(num) == false || @reshuffle == true
      self[num % @store.length] << num
      @count+=1
      true
    elsif include?(num) == true
      false
    end

    if count > store.length
      @reshuffle = true
      resize!
    end
  end

  def remove(num)
    if include?(num) == true
      self[num % @store.length].delete(num)
      @count-=1
      true
    end
  end

  def include?(num)
    if num == 0
      self[0].include?(num)
    else
      self[num % @store.length].include?(num)
    end
  end


    def add_twenty
      i = 0
      20.times do
        self.insert(i)
        i+=1
      end
    end

  private

  def [](num)
    # optional but useful; return the bucket corresponding to `num`
    @store[num]
  end

  def num_buckets
    @store.length
  end

  def resize!
      twice_buckets = store.length * 2

      num_arrays_add = count - store.length

      #num_arrays_add
      store.length.times do
        @store <<  Array.new() { Array.new }
      end

      store.each do |sub|
        current = sub.dup

        if current.empty? == false
          current.each do |el|
            @store2 << el
          end
        end
      end

      @store = Array.new(twice_buckets) { Array.new }
      @count = 0
      @store2.each do |el|
        insert(el)
      end
      @reshuffle = false
      @store2 = []
  end
end

rs = ResizingIntSet.new
rs.add_twenty
rs.insert(22)
rs.insert(20)
##insert 0(n) time, unless you have to create double buckets, quadratic time
##delete 0(1) time
##lookup 0(1) time

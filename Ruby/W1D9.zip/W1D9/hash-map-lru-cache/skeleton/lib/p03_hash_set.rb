# class HashSet
#   attr_reader :count
#
#   def initialize(num_buckets = 8)
#     @store = Array.new(num_buckets) { Array.new }
#     @count = 0
#   end
#
#   def insert(key)
#   end
#
#   def include?(key)
#   end
#
#   def remove(key)
#   end
#
#   private
#
#   def [](num)
#     # optional but useful; return the bucket corresponding to `num`
#   end
#
#   def num_buckets
#     @store.length
#   end
#
#   def resize!
#   end
# end






class HashSet
  attr_accessor :count, :store, :reshuffle, :store2

  def initialize(num_buckets = 20)
    @store = Array.new(num_buckets) { Array.new }
    @store2 = []
    @count = 0
    @reshuffle = false
  end

  def insert(any_data_type)
    
    if any_data_type.class != Integer
      num = any_data_type.hash
    else
      num = any_data_type
    end
    if include?(num) == false || @reshuffle == true
      self[num % @store.length] << num
      @count+=1
      true
    elsif include?(num) == true
      false
    end

    if count > store.length
      @reshuffle = true
      resize!
    end
  end

  def remove(num)
    if include?(num) == true
      self[num % @store.length].delete(num)
      @count-=1
      true
    end
  end

  def include?(num)
    if num == 0
      self[0].include?(num)
    else
      self[num % @store.length].include?(num)
    end
  end

    def add_twenty
      i = 0
      20.times do
        self.insert(i)
        i+=1
      end
    end

  private

  def [](num)
    # optional but useful; return the bucket corresponding to `num`
    @store[num]
  end

  def num_buckets
    @store.length
  end

  def resize!
      twice_buckets = store.length * 2

      num_arrays_add = count - store.length

      #num_arrays_add
      store.length.times do
        @store <<  Array.new() { Array.new }
      end

      store.each do |sub|
        current = sub.dup

        if current.empty? == false
          current.each do |el|
            @store2 << el
          end
        end
      end

      @store = Array.new(twice_buckets) { Array.new }
      @count = 0
      @store2.each do |el|
        insert(el)
      end
      @reshuffle = false
      @store2 = []
  end
end

require_relative 'player.rb'

class Game

  def initialize(args)
    @fragment = ""
    #@player1 = Player.new(playera)
    #@player2 = Player.new(playerb)
    @switch_players = args.map do |arg|
      Player.new(arg)
    end


    #@switch_players = [@player1, @player2]
    @losses = Hash.new(0)

      @switch_players.each do |player|
        @losses[player.name] = 0
      end


  end

  def losses
    @losses
  end

  def switch_players
    @switch_players
  end

  def switch_players=(obj)
    @switch_prayers = obj
  end

  def play_round
    @fragment = ""
    display_standings
    take_turn(switch_players[0])
  end

  def next_player!

    popped = @switch_players.pop
    @switch_players.unshift(popped)
    take_turn(@switch_players[0])

  end


  def take_turn(player)
    puts
    puts "--------------"
    puts "current player is:" + player.name.to_s
    puts "current fragment is:" + @fragment

    guessed_letter = player.guess


    if guessed_letter == "exit"
      print exit.error
    end

    fragment_with_guess = @fragment + guessed_letter
    # valid_play?(fragment_with_guess)
    if valid_play?(fragment_with_guess) == true && word_completed?(fragment_with_guess) == false
      @fragment = fragment_with_guess
      next_player!

    elsif valid_play?(fragment_with_guess) == false
      player.alert_invalid_guess
      take_turn(@switch_players[0])

    elsif word_completed?(fragment_with_guess) == true

      puts player.name.to_s + "loses, that person spelled:" + fragment_with_guess.to_s
      losses[player.name]+=1
      puts losses

      eliminate_player_w_5_losses?(player)


      if @switch_players.length == 1
        puts
        puts "game over"
        losses.each do |k, v|
          if v == 5
            puts "the loser is " + k.to_s
          end
          if v < 5
            puts "the winner is: " + k.to_s + "!!!!!!!!!!"
          end
        end

      elsif @switch_players.length > 1
        play_round
      end
    end

  end

  def eliminate_player_w_5_losses?(player)
    losses.each do |k, v|
      if v == 5 && k == player.name
        puts k.to_s + " was eliminated with 5 loses"
        @switch_players.delete(player)

        true
      end
    end

  end

  def display_standings
    horse = "horse"
    puts
    puts
    puts "Scoreboard:"
    losses.each do |k, v|
      if v < 5
        puts k.to_s + " has " + v.to_s + " losses, spelling:" + horse[0...v]
      end
    end
    puts
  end

  #is it building towards a string in the dictionary?
  def valid_play?(string)
    frag_found = false
    length = string.length

    File.open("dictionary.txt").each do |word|
      if word[0...length] == string
        frag_found = true
      end
    end

    frag_found
  end

  # is the word spelled out and completed
  def word_completed?(string)
    word_completed = false

    File.open("dictionary.txt").each do |word|

      if string == word[0..-2]
        word_completed = true
      end
    end

    word_completed
  end

end

# #horse = Game.new("mark", "Vanessa", "tom")
# puts horse.losses
# horse.play_round

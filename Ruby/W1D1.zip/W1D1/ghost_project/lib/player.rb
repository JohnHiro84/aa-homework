class Player

  def initialize(name)
    @name = name
  end

  def guess
    puts "-------------------------------------"
    print 'enter a character below to add onto the current word fragment:'
    puts
    input = gets.chomp

  end

  def name
    @name
  end

  def alert_invalid_guess
    puts name + " - no words in the dictionary found with that fragment, invalid guess"
    puts "please try another letter"
  end

end

#tom = Player.new("tom")
#tom.guess

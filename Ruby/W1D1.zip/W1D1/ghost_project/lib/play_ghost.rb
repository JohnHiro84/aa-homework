# No need to change or write any code in this file.
#
# After you complete all specs, you can play your game by
# running this file with `ruby lib/play_battleship.rb` in your terminal!

require_relative "game"
#

def make_new_game
  print 'Start a new game of ghost by entering in players names seperated'
  print 'by commas and a space. Example: ("Tom Jessica Tammy")'
  puts
  input = gets.chomp
  players = input.split(" ")
  players = ["player1", "player2"] if players.length < 2
  horse = Game.new(players)
  horse.play_round
end

make_new_game
#horse = Game.new("mark", "Vanessa", "tom")


# puts "Enter a size for the game: "
# battleship = Battleship.new(gets.chomp.to_i)
# battleship.start_game
#
# until battleship.game_over? do
#   puts "-------------------------"
#   battleship.turn
# end

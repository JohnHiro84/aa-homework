require 'byebug'

# My Each
#
# Extend the Array class to include a method named my_each that takes a block,
# calls the block on every element of the array, and returns the original array.
# Do not use Enumerable's each method. I want to be able to write:


class Array
  def my_each (&prc)
    if self.length == 0
      nil
    else
      i = 0
      while i < self.length
        prc.call(self[i])
        i+=1
      end
    end
    self
  end
end


#working example 1
[1,2,3,4].my_each { |ele| puts ele }.my_each { |a| puts a }

puts "my_each --------------------"
#working example 2
return_value = [10, 20, 30].my_each do |num|
   puts num
 end.my_each do |num|
   puts num
 end



 # My Select
 #
 # Now extend the Array class to include my_select that takes a block and
 # returns a new array containing only elements that satisfy the block.
 # Use your my_each method!
 #
 # Example:
 #
 #   a = [1, 2, 3]
 #   a.my_select { |num| num > 1 } # => [2, 3]
 #   a.my_select { |num| num == 4 } # => []

puts "my_select -------------"

class Array
  def my_select (&prc)

    selected = []
    self.my_each do |e|
      if prc.call(e) == true
        selected << e
      end
    end
    print selected
  end

end
puts [5,6,7,8].my_select { |e| e > 6}

#
# My Reject
#
# Write my_reject to take a block and return a new array excluding elements that satisfy the block.
#
# Example:
#
#   a = [1, 2, 3]
#   a.my_reject { |num| num > 1 } # => [1]
#   a.my_reject { |num| num == 4 } # => [1, 2, 3]
#

puts "my_reject ---------------------"



class Array
  def my_reject (&prc)

    selected = []
    self.my_each do |e|
      if prc.call(e) == false
        selected << e
      end
    end
    print selected
  end

end
puts [5,6,7,8].my_reject { |e| e > 6}
puts [5,6,7,8].my_reject { |e| e == 6}

#
# My Any
#
# Write my_any? to return true if any elements of the array satisfy the block and
# write my_all? to return true only if all elements satisfy the block.
#
# Example:
#
#   a = [1, 2, 3]
#   a.my_any? { |num| num > 1 } # => true
#   a.my_any? { |num| num == 4 } # => false
#   a.my_all? { |num| num > 1 } # => false
#   a.my_all? { |num| num < 4 } # => true

puts "my_any?---------------------"

class Array
  def my_any? (&prc)

    any = false
    self.my_each do |e|
      if prc.call(e) == true
        any = true
      end
    end
    any
  end

end
puts [5,6,7,8].my_any? { |e| e == 38}
puts [5,6,7,8].my_any? { |e| e == 7}
puts [5,6,7,8].my_any? { |e| e == 6}


puts "my_all?---------------------"

class Array
  def my_all? (&prc)

    all = true
    self.my_each do |e|
      if prc.call(e) == false
        all = false
      end
    end
    all
  end

end

puts [5,6,7,8].my_all? { |e| e == 6}
puts [5,6,7,8].my_all? { |e| e > 1}

#
# #
# # My Flatten
# #
# # my_flatten should return all elements of the array into a
# # new, one-dimensional array. Hint: use recursion!
# #
# # Example:
# #
# #   [1, 2, 3, [4, [5, 6]], [[[7]], 8]].my_flatten # => [1, 2, 3, 4, 5, 6, 7, 8]
# #
#
# #[1,
# # 2,
# # 3,
# # [4, [5, 6]],
# # [[[7]],  8]
# # ]
# # arr[0]
# # arr[1]
# # arr[2]
# # arr[3][0]
# # arr[3][1][0]
# # arr[3][1][0]
# # arr[4][0][0]
# # arr[4][1]
# #
# # if array has more arrays dive deeper
# # if array has values take those values
#
# def flatten(array)
#   return array if array.length == 0
#   array[0] + flatten(array[1..-1])
# end
#
# array.each do |sub|
#   output = []
#   if sub.class == Integer
#     output << sub
#   elsif sub.class == Array
#   end
# end
# #.pop
# def flatten2(array)
#   return if array.length == 0
#   flatten(array[0..-2])
#
# end
#

puts "flatten"

require 'byebug'

def flatten4(array)
  #debugger
  output = []
  if array.length <= 0
    return output
  end

  popped = array.pop

  if popped.class == Array
    flatten4(popped)
  elsif popped.class == Integer
    popped
  end
  #output
end

puts flatten4([1, 2, 3, [4, [5, 6]], [[[7]], 8]])

puts "flatten5"

def flatten5(array)
  output = []
  array.each do |ele|
    if ele.class == Integer
      output << ele
    elsif ele.class == Array
      output << flatten5(ele)
    end
  end
  output
end


print flatten5([1, 2, 3, [4, [5, 6]], [[[7]], 8]])

puts " "
puts "flattener problem ----- my attempt"


  def isArray?(array)
    if array[0].class == Integer

      output << array[0]
      isArray?(array[1..-1])
    elsif array[0].class == Array

      isArray?(array[0])
      isArray?(array[1..-1])
    end
  end

def flatten9(array)
  output = []

  isArray?(array)
  print output
end

print "flattener - thier solution"


class Array
  def my_flatten
    flattened = []

    self.my_each do |el|

      if el.is_a?(Array)
        print el
        puts "is array"
        flattened.concat(el.my_flatten)
      else
        print el
        puts "is not array"

        flattened << el
      end
    end

    flattened
  end
end


#print [1, 2, 3, [4, [5, 6]], [[[7]], 8]].my_flatten
puts ""
puts "my_zip---------------------"

# a = [ 4, 5, 6 ]
# b = [ 7, 8, 9 ]
# [1, 2, 3].my_zip(a, b) # => [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
# a.my_zip([1,2], [8])   # => [[4, 1, 8], [5, 2, nil], [6, nil, nil]]
# [1, 2].my_zip(a, b)    # => [[1, 4, 7], [2, 5, 8]]
#
# c = [10, 11, 12]
# d = [13, 14, 15]
# [1, 2].my_zip(a, b, c, d)    # => [[1, 4, 7, 10, 13], [2, 5, 8, 11, 14]]

class Array
  def my_zip (*args)

    output = []

    puts self.length
    self.my_each do |el|
      output << Array.new(1, el)
    end

  i = 0
  while i < output.length
    if args[0][i]
      output[0] << args[0][i][0]
      output[1] << args[0][i][1]
      output[2] << args[0][i][2]
    elsif args[0][i] == false
      p "nil"
    end


    i+=1
  end


    #
    # i = 0
    # while i < output.length
    #   j = 0
    #   while j < output.length
    #     if (args[0][j][i])
    #       output[i] << args[0][j][i]
    #     end
    #     j+=1
    #   end
    #   i+=1
    # end

    # if args[0][i]
    #   p args[0][i]
    # else




    output
  end
end

print [10, 11, 12].my_zip([["a", "b", "c"], ["d", "e", "f"]])

puts "my_rotate------------------------"

class Array
  def my_rotate(val = 1)

    if val >0
      val.times do
        shifted = self.shift
        self.push(shifted)
      end
    elsif val < 0
      pos_num = val.abs
      pos_num.times do
        popped = self.pop

        self.unshift(popped)
      end

    end
    return self
  end
end

print [1,3,4].my_rotate(0)
print [1,3,4].my_rotate(1)
print [1,3,4].my_rotate(2)
print [1,3,4].my_rotate(0)
print [1,3,4].my_rotate(-1)
print [1,3,4].my_rotate(-2)



puts "my_join------------------------------------------"

#
# My Join
#
# my_join returns a single string containing all the elements of the array,
# separated by the given string separator. If no separator is given, an empty string is used.
#
# Example:
#
#   a = [ "a", "b", "c", "d" ]
#   a.my_join         # => "abcd"
#   a.my_join("$")    # => "a$b$c$d"



class Array
  def my_join(val="")
    output = ""
    i = 0
    length = self.length
    while i < self.length
      if i < length -1
        output +=( self[i].to_s + val.to_s)
      elsif i == length -1
        output +=( self[i].to_s)
      end
      i+=1
    end
    output
  end

end

print ["ab", "er", "po"].my_join("$")

puts "--"
puts "my_reverse------------------------------------------------"

#
# My Reverse
#
# Write a method that returns a new array containing all the elements of the original array in reverse order.
#
# Example:
#
#   [ "a", "b", "c" ].my_reverse   #=> ["c", "b", "a"]
#   [ 1 ].my_reverse               #=> [1]

class Array
  def my_reverse
    output = []
    i=0
    while i < self.length
      output.unshift(self[i])
      i+=1
    end
    output
  end
end

print [ "a", "b", "c" ].my_reverse


#Review
puts ""
puts "review of factors, bubble sort, substrings and subwords"
##Now that we're all warmed up, let's review the iteration exercises from the prepwork. Implement the following methods:

#factors(num)

    def factors(num)
      (2..num).select { |n| num % n == 0 }
    end


puts "bubble sort ---------------------------"
#bubble_sort!(&prc)

def bubble_sort(array)
  jonas = array.map.each_with_index do |ele, i|
    puts ele
    next if i == array.length - 1
    puts array[i].to_s + " " + array[i+1].to_s

    puts array[i] <=> array[i+1]

    if (array[i] <=> array[i+1]) == 1
      array[i+1]
    elsif (array[i] <=> array[i+1]) == -1
      array[i]
    end
  end
  puts "output"
  puts jonas
end
bubble_sort([1,2,3,4])
#bubble_sort(&prc)

# ### Bubble Sort
#
# http://en.wikipedia.org/wiki/bubble_sort
#
# Implement Bubble sort in a method, `Array#bubble_sort!`. Your method should
# modify the array so that it is in sorted order.
#
# > Bubble sort, sometimes incorrectly referred to as sinking sort, is a
# > simple sorting algorithm that works by repeatedly stepping through
# > the list to be sorted, comparing each pair of adjacent items and
# > swapping them if they are in the wrong order. The pass through the
# > list is repeated until no swaps are needed, which indicates that the
# > list is sorted. The algorithm gets its name from the way smaller
# > elements "bubble" to the top of the list. Because it only uses
# > comparisons to operate on elements, it is a comparison
# > sort. Although the algorithm is simple, most other algorithms are
# > more efficient for sorting large lists.
#
# Hint: Ruby has parallel assignment for easily swapping values:
# http://rubyquicktips.com/post/384502538/easily-swap-two-variables-values
#
# After writing `bubble_sort!`, write a `bubble_sort` that does the same
# but doesn't modify the original. Do this in two lines using `dup`.
#
# Finally, modify your `Array#bubble_sort!` method so that, instead of
# using `>` and `<` to compare elements, it takes a block to perform the
# comparison:
#
# ```ruby
# [1, 3, 5].bubble_sort! { |num1, num2| num1 <=> num2 } #sort ascending
# [1, 3, 5].bubble_sort! { |num1, num2| num2 <=> num1 } #sort descending
# ```
#
# #### `#<=>` (the **spaceship** method) compares objects. `x.<=>(y)` returns
# `-1` if `x` is less than `y`. If `x` and `y` are equal, it returns `0`. If
# greater, `1`. For future reference, you can define `<=>` on your own classes.
#
# http://stackoverflow.com/questions/827649/what-is-the-ruby-spaceship-operator



puts "substrings(string) subwords(word, dictionary)"

#substrings(string)
#subwords(word, dictionary)

    def substrings(word)
      output =[]

      j=0

      while j < word.length

        wordcut = word[j..-1]
        i=0

        while i < wordcut.length
          output << wordcut[0..i]

          i+=1
        end

        j+=1
      end
      output
    end

    puts substrings("cat")

    book1 = ["cat"]

    def subwords(word, dictionary)
      array_words = substrings(word)
      output = []
      array_words.each do |w|
        if dictionary.include?(w) == true && output.include?(w) == false
          output << w
        end
      end
      output
    end
    puts subwords("caterpiller", ["cat", "pill"])

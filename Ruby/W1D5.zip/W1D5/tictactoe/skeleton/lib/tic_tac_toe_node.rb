require_relative 'tic_tac_toe'
require 'byebug'
class TicTacToeNode

  attr_accessor :board, :next_mover_mark, :prev_move_pos, :parent
  def initialize(board, next_mover_mark, prev_move_pos = nil)
    @board = board
    @next_mover_mark = next_mover_mark
    @prev_move_pos = prev_move_pos
    @parent

  end

  def losing_node?(evaluator)
  end

  def winning_node?(evaluator)
  end
# To create this method, it will be necessary to iterate through all positions that are empty?
  #potential game states after this current node

  # def after_move_made
  #   chi
  # end

  def children
    children = []
    index = 0
    positions = [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[2,2]]
    9.times do
      newBoard = Board.new

      @board.rows.each.with_index do |row, i|

        row.each.with_index do |cell, j|
          newBoard.[]=([i,j],cell)
        end

      end
      if newBoard.[](positions[index]) == nil
        newBoard.[]=(positions[index], self.next_mover_mark)
          #debugger
        next_mover_mark = (self.next_mover_mark == :x ? :o : :x)
        new_node = TicTacToeNode.new(newBoard, next_mover_mark, positions[index])
        children << new_node
      end

      index+=1
      #debugger
    end
    prev_move_pos = next_mover_mark
    children
  end


end
node = TicTacToeNode.new(Board.new, :X)
node.children
#debugger
puts "hi"
puts "hi"
#newgame = TicTacToe.new
# node.children

class PolyTreeNode

  def initialize(value)
    @value = value
    @parent = nil
    @children = []
  end


  def parent
    @parent
  end

  def children
    # if @children.length < 1
    #   @children = []
    # end
    @children
  end

  def value
    @value
  end

  def inspect
    @value.inspect
  end

  def parent= (passed_in_node)
    if passed_in_node == nil
      @parent = nil
    else
      if passed_in_node.children.include?(self) == false
        passed_in_node.add_child = self
      end
      if @parent != nil && @parent != passed_in_node
        @parent.children.delete(self)
      end
      @parent = passed_in_node
    end
    #@children = node.children
    #@parent = node
  end
  def add_child=(node)
    if self.children.include?(node) == false
      children << node
      node.parent= (self)
    end
  end

  def remove_child(node)
    if children.include?(node) == false
      raise error
    else
      children.delete(node)
      node.parent=nil
    end
  end

  # def dfs(node, target_value)
  #   return node if node.value == target_value
  #   return nil if node.children.length < 1
  #   dfs(node.children[0], target_value) + dfs(node.children[1..-1], target_value)
  # end

  def dfs(node, target_val)
    puts "target_val: " + target_val.to_s
    puts "node.value: " + node.value
    puts "found it" if node.value == target_val
    return node if node.value == target_val

    node.children.each do |child|
      # puts child.value
      if dfs(child, target_val) != nil
        dfs(child, target_val)
      end
    end
    # nil
  end


  ####Thier solutions
  # def dfs(target = nil, &prc)
  #   raise "Need a proc or target" if [target, prc].none?
  #   prc ||= Proc.new { |node| node.value == target }
  #
  #   return self if prc.call(self)
  #
  #   children.each do |child|
  #     result = child.dfs(&prc)
  #     return result unless result.nil?
  #   end
  #
  #   nil
  # end

    #
    def bfs(target = nil, &prc)
      raise "Need a proc or target" if [target, prc].none?

      prc ||= Proc.new { |node| node.value == target }

      nodes = [self]
      until nodes.empty?
        node = nodes.shift

        return node if prc.call(node)
        nodes.concat(node.children)
      end

      nil
    end
end

#
# a = PolyTreeNode.new("a")
# b = PolyTreeNode.new("b")
# c = PolyTreeNode.new("c")
# d = PolyTreeNode.new("d")
#
# e = PolyTreeNode.new("e")
# f = PolyTreeNode.new("f")
# g = PolyTreeNode.new("g")
# h = PolyTreeNode.new("h")
# d.parent=c
# c.parent=b
# b.parent=a
# h.parent=g
# g.parent=f
# f.parent=e
# e.parent=a
# # puts a.dfs(a, "g")
# # puts a.dfs(a, "g")
# # puts g
# puts a.bfs("b")

require_relative 'KnightPathFinder'

puts "\n\n\nplease enter coordinates seperated by a comma:"
puts "to find a Knight's path to those coordinates"
puts "example =>  5,5\n"

input = gets.chomp.split(",")
input_w_nums = input.map { |str| str.to_i}
kpf = KnightPathFinder.new([0,0])

print kpf.returned_path(input_w_nums)



# kpf = KnightPathFinder.new([0,0])
# print kpf.returned_path([7,6])

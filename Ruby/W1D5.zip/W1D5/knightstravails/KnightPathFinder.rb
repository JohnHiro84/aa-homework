
require_relative '../poly-tree-node/skeleton/lib/00_tree_node.rb'
require 'byebug'

class KnightPathFinder
  attr_accessor :starting_pos, :root_node, :considered_positions, :all_seen_positions

  def initialize (starting_pos)
    @starting_pos = starting_pos
    @root_node = PolyTreeNode.new(starting_pos)
    @considered_positions = [starting_pos]
    @all_seen_positions = []
    build_move_tree
  end

  def self.valid_moves(pos)
    #this returns up to 8 valid moves
    x = pos[0]
    y = pos[1]
    valid_moves_array = []

    if (x +2) >=0 && (x+2) <= 7 && (y+1) >= 0 && (y+1) <= 7
      valid_moves_array << [(x+2), (y+1)]
    end
    if (x +2) >=0 && (x+2) <= 7 && (y-1) >= 0 && (y-1) <= 7
      valid_moves_array << [(x+2), (y-1)]
    end

    if (x -2) >=0 && (x-2) <= 7 && (y+1) >= 0 && (y+1) <= 7
      valid_moves_array << [(x-2), (y+1)]
    end
    if (x -2) >=0 && (x-2) <= 7 && (y-1) >= 0 && (y-1) <= 7
      valid_moves_array << [(x-2), (y-1)]
    end

    if (x +1) >=0 && (x+1) <= 7 && (y+2) >= 0 && (y+2) <= 7
      valid_moves_array << [(x+1), (y+2)]
    end
    if (x -1) >=0 && (x-1) <= 7 && (y+2) >= 0 && (y+2) <= 7
      valid_moves_array << [(x-1), (y+2)]
    end

    if (x +1) >=0 && (x+1) <= 7 && (y-2) >= 0 && (y-2) <= 7
      valid_moves_array << [(x+1), (y-2)]
    end
    if (x -1) >=0 && (x-1) <= 7 && (y-2) >= 0 && (y-2) <= 7
      valid_moves_array << [(x-1), (y-2)]
    end

    valid_moves_array

  end

  def new_move_positions(pos)
    latest_moves = []
    KnightPathFinder.valid_moves(pos).each do |pos_valid|
      # puts "new moves for pos:" + pos.to_s
      # puts pos_valid
      if @all_seen_positions.include?(pos_valid) == false
        @considered_positions << pos_valid
        latest_moves << pos_valid
      end

    end
    latest_moves
  end




  def build_move_tree
    start_node = root_node

    while considered_positions.length > 0
      current_pos = @considered_positions.shift

      new_move_positions(current_pos).each do |pos|
        new_node = PolyTreeNode.new(pos)
        new_node.parent=(root_node.bfs(current_pos))
      end

      if all_seen_positions.include?(current_pos) == false
        all_seen_positions << current_pos
      end

    end
    #debugger
  end


  def returned_path(position)
    output_array = []
    output_array << self.root_node.bfs(position).value

    if self.root_node.bfs(position).parent != nil
      output_array.concat(returned_path(self.root_node.bfs(position).parent.value))
    elsif self.root_node.bfs(position).parent == nil
      puts
    end
    output_array
  end

end




# kpf = KnightPathFinder.new([0,0])
# print kpf.returned_path([7,6])
#print KnightPathFinder.valid_moves([5,5])

# puts kpf.new_move_positions([4,4]).to_s
# puts kpf.considered_positions.to_s
# puts kpf.new_move_positions([4,7]).to_s
# puts kpf.considered_positions.to_s
# puts kpf.starting_pos
# kpf.expr
# print KnightPathFinder.valid_moves([0,0])
# puts "step 1"
# print kpf.new_move_positions([0,0])
# puts "step 2"
# print kpf.considered_positions
# puts "step 3"
# print kpf.new_move_positions([2,1])
# puts "step 4"
# print kpf.considered_positions
# print kpf.build_move_tree
# puts
# puts
# print kpf.root_node.children

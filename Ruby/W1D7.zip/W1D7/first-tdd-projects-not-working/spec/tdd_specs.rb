require 'rspec'
require 'tdd_methods'


describe "#hello_world" do
  it "returns 'Hello, World!'" do
    expect(hello_world).to eq("Hello, World!")
  end
end

describe Human do
  # let(:test_human) { double('chef', name: 'Jake') }
  subject(:bob) { Human.new("bob") }
  # let(:dessert_2) { Dessert.new("cake", 8, chef) }


  describe "#initialize" do
    it "sets a type" do
      expect(bob.name).to eq("bob")
    end
  end
end

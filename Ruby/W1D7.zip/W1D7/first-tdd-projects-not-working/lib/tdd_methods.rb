require 'active_support/inflector'
#
# def hello
#   return "hello world"
# end
#
# puts hello
# puts hello


def hello_world
  "Hello, World!"
end

class Human
  attr_accessor :name
  def initialize(name)
    @name = name
  end
end

bob = Human.new("bob")
puts bob

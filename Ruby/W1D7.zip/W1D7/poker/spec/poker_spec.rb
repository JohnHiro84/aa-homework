require 'deck'
require 'game'
require 'hand'

describe "#hello_world" do
  it "returns hello world" do
    expect(hello_world).to eq("hello world")
  end
end

describe "weather" do
  it "takes in the month and returns the weather" do
    expect(weather("january")).to eq("cold!")
  end
end

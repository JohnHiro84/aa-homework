require_relative 'deck'
require_relative 'hand'
require 'byebug'
class Player
  attr_accessor :hand, :name, :money, :players_current_bet, :fold
  def initialize(name)
    @name = name
    @hand = []
    @money = 150
    @pot = 0
    @players_current_bet = 0
    @fold = false
  end
end

class Game

  attr_accessor :deck, :players, :current_pot, :current_bet, :no_new_cards
  def initialize
    @deck = Deck.new
    @players = [Player.new("1"), Player.new("2"), Player.new("3")]
    @current_pot = 0
    @current_bet = 0
    @no_new_cards = false
    #add ability to add more players
  end

  def add_player
    @players << Player.new((players.length + 1).to_s)
  end

  def deal_first_hand
    players.each do |player|
      5.times do
       player.hand << self.deck.shuffled_cards.pop
      end
    end
  end

  def print_all_players_hands
    players.each do |player|
      print "\n\nplayer: " + player.name + "\n"
      #print "a b  c d e <- Card letter Number\n"
      player.hand.each {|card| print card.value.to_s + " " + card.suit.to_s + "\n" }
    end
      print "\n\nCards left in deck: " + deck.shuffled_cards.length.to_s + "\n"
  end

  def bet_fold_or_raise(player)
    valid_choice = false
    until valid_choice == true
      user_input = gets.chomp
      if user_input == "1"
        puts "current bet is:" + @current_bet.to_s

      elsif user_input == "2" && player.money >= current_bet
        player.money-= current_bet
        @current_pot += current_bet
        player.players_current_bet = current_bet
        valid_choice = true

      elsif user_input == "3"
        puts "ask user for amount to raise to"
        valid_choice = true if choose_to_raise(player)
      elsif user_input == "4"
        player.fold = true
        valid_choice = true
      else
        puts "please enter a 1 2 3 or 4"
      end
    end
  end

  def choose_to_raise(player)
    raised_input = gets.chomp.to_i
    if player.money >= raised_input && raised_input > current_bet
      player.money -= raised_input
      @current_pot += raised_input
      player.players_current_bet = raised_input
      @current_bet = raised_input
      true

    elsif player.money < raised_input
      puts "the max you can raise is: #{player.money}"
      puts "please enter a valid amount"
      false
    end
  end

  def change_out_cards?(player)
    puts "if you would like to change out card values enter in the values"
    puts "seperated by a space example:  Q heart 5 club 10 diamond"
    change_out = value_suit_pairing
    values = change_out.map { |pair| pair[0]}
    suits = change_out.map { |pair| pair[1]}

    player.hand.each.with_index do |card, idx|
      values.each.with_index do |val, j|
        if card.value == values[j] && card.suit == suits[j]
          card.keep = false
        end
      end
    end

    cards_to_keep = player.hand.select { |card| card.keep == true }
    player.hand = cards_to_keep
    get_new_cards(player)
  end

  def get_new_cards(player)
        num_new_cards = 5 - player.hand.length
        num_new_cards.times do
          player.hand << self.deck.shuffled_cards.pop
        end

        puts "new hand"
        player.hand.each{|card| puts card.value.to_s + " " + card.suit.to_s}
        puts "length:" + player.hand.length.to_s
  end

  def value_suit_pairing
    pairs = []
    change_out_cards = gets.chomp.split(" ")
    pair = []
    change_out_cards.each.with_index do |value, idx|
      pair << value
      if pair.length == 2
        pairs << pair
        pair = []
      end
    end
    pairs
  end


  def prompt_player_for_decision
    players.each do |player|
      print "\nplayer turn: " + player.name.to_s + "\n"
      print "\nPlease enter: \n1 see current_bet \n2 match current bet \n3 raise bet or \n4 fold\n"
      bet_fold_or_raise(player)
      change_out_cards?(player) if player.fold == false && self.no_new_cards == false
    end
    players.each { |player| puts player.name + "   "+ player.players_current_bet.to_s}
    puts current_bet
  end

  def prompt_player_to_match_bet
    # while players.any? { |player| player.players_current_bet < current_bet && player.fold == false}
      players.each do |player|
        if player.players_current_bet < current_bet && player.fold == false
          print_all_players_hands
          puts "player: " + player.name + " your bet is: " + player.players_current_bet.to_s
          puts "you need to raise if you want to stay in the game"
          puts "Did you want to match the bet? fold? or raise?"
          print "\nPlease enter: \n1 see current_bet \n2 match current bet \n3 raise bet or \n4 fold\n"
          bet_fold_or_raise(player)
        end
      end
    # end
  end
end


game = Game.new
game.deal_first_hand
game.print_all_players_hands
game.prompt_player_for_decision
game.prompt_player_to_match_bet
game.players.each { |player| puts player.name + "   "+ player.players_current_bet.to_s}
game.prompt_player_to_match_bet
game.no_new_cards = true
game.prompt_player_for_decision
game.prompt_player_to_match_bet
game.print_all_players_hands
# game.add_player
# game.players.each {|p| puts p.name}

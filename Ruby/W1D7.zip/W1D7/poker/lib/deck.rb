def hello_world
  "hello world"
end



def weather(month)
  if month == "january"
    return "cold!"
  elsif month == "july"
    return "warm!"
  end
end


class Card
  attr_accessor :value, :suit, :keep
  def initialize(value, suit)
    @value = value
    @suit = suit
    @keep = true
  end
end

class Deck
  attr_accessor :shuffled_cards
  def initialize
    @shuffled_cards = make_deck
  end

  def make_deck
    all_cards_created = []
    all_suits = ['spade', 'heart', 'club', 'diamond']
    all_card_values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'A', 'J', 'Q', 'K']
    all_suits.each do |suit|
      all_card_values.each do |card_value|
        all_cards_created << Card.new(card_value, suit)
      end
    end
    all_cards_created.shuffle.shuffle.shuffle
  end
end

require_relative 'deck'

class Hand
  def initialize

  end

  def take_five_cards

  end
end

class Player
  def initialize

  end
end

require 'hello'


describe "#hello_world" do 
  it "returns hello world" do 
    expect(hello_world).to eq("hello world")
  end
end


describe "#greetings" do 
  it "greets by name" do 
    expect(greetings("Joe")).to eq("greetings there! Joe")
  end
end

describe "super_math" do 
  it "takes in a number returns that number multiplied by 40" do
    expect(super_math(20) ).to eq(800)
  end
end
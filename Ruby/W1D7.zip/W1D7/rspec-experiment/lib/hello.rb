def hello_world
  "hello world"
end


def greetings(name)
  return "greetings there! #{name}"
end
  
def super_math(number)
  number * 40
end

puts "hi"
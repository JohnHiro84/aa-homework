require 'hello'


describe "#duplicate" do
  it "returns an array with only unique elements" do
    expect(duplicate([1,2,3,3])).to eq([1,2,3])
  end
end
describe "#hello_world" do
  it "returns hello world" do
    expect(hello_world).to eq("hello world")
  end
end

describe "weather" do
  it "takes in the month and returns the weather" do
    expect(weather("january")).to eq("cold!")
  end
end

describe "#greetings" do
  it "greets by name" do
    expect(greetings("Joe")).to eq("greetings there! Joe")
  end
end

describe "super_math" do
  it "takes in a number returns that number multiplied by 40" do
    expect(super_math(20) ).to eq(800)
  end
end

describe Array do
  subject(:test_uniq_array) { [1,2,3,4,5,6,7,4,4,4].my_uniq }
  describe "#my_uniq" do

    it "returns an array with only unique elements" do
      #expect(([1,2,3,3]).my_uniq).to eq([1,2,3])
      expect(test_uniq_array).to eq([1,2,3,4,5,6,7])
    end
  end

  describe "#two_sum" do

    it "returns an array of pairs where the indices sum to zero" do
      #expect(([1,2,3,3]).my_uniq).to eq([1,2,3])
      expect([1,2,3,-2,-1].two_sum).to eq([[0,4],[1,3]])
    end
    it "should have unique keys without any duplicates" do
      #expect(([1,2,3,3]).my_uniq).to eq([1,2,3])
      expect([1,2,3,-2,-1].two_sum).to_not eq([[0,4],[0,4],[1,3]])
    end
    it "the keys should be sorted numericaly" do
      #expect(([1,2,3,3]).my_uniq).to eq([1,2,3])
      expect([1,2,3,-2,-1].two_sum).to_not eq([[1,3],[0,4]])
    end

  end

  describe "#my_transpose" do
    #subject(:array) { [[1,2,3],[4,5,6],[7,8,9]].my_uniq }
    it "transposes an array where columns become rows" do
      expect([[1,2,3],[4,5,6],[7,8,9]].my_transpose).to eq([[1,4,7],[2,5,8],[3,6,9]])
    end
  end
end

describe "#stock_picker" do
  #subject(:array) { [[1,2,3],[4,5,6],[7,8,9]].my_uniq }
  it "takes in an array of prices and returns the best days to buy and sell" do
    expect(stock_picker([100,40,60, 80,120,40, 60])).to eq([1,4])
  end
  it "ensures the buy date is before the sell date" do
    expect(stock_picker([100,2,34,7,9,2,5,3])).to eq([1,2])
  end
end


describe Hanoi do
  let(:from_stack_num) { 0}
  let(:to_stack_num) { 1 }
  let(:from_stack) { 0}
  let(:to_stack) { 1 }
  let(:@stacks) { [[3,2,1], [], [] ] }

  describe "#move_disk" do
    it "successfully moves a disk" do
      #allow().to receive(:email_address).and_return("ned@appacademy.io")
      expect(from_stack_num).to eq(0)
    end
  end
end

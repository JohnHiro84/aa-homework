def hello_world
  "hello world"
end


def greetings(name)
  return "greetings there! #{name}"
end

def super_math(number)
  number * 40
end

puts "hi"

def weather(month)
  if month == "january"
    return "cold!"
  elsif month == "july"
    return "warm!"
  end
end


def duplicate(array)
  array.uniq
end

class Array
  def my_uniq
    uniq_elements = []
    if self.length == 0
      nil
    else
      self.each do |ele|
        if uniq_elements.include?(ele) == false
          uniq_elements << ele
        end
      end
    end
    uniq_elements
  end

  def two_sum
    pairs = []
    duplicate_array = self.dup
    return nil if self.any?{ |ele| ele.class != Integer}
    self.each.with_index do |ele, i|
      duplicate_array.each.with_index do |dup, j|
        if ele + dup == 0
          pairs << [i,j].sort
        end
      end
    end
    pairs.uniq.sort
  end

  def my_transpose
    transposed_arrays = []

    self.length.times do
      transposed_arrays << Array.new
    end

    self.each.with_index do |old_row, i|
      old_row.each.with_index do |old_ele, j|
        transposed_arrays[j] << old_ele
      end
    end
    transposed_arrays
  end
end

def stock_picker(prices)
  if prices.index(prices.min) < prices.index(prices.max)
    most_money = [prices.index(prices.min), prices.index(prices.max)]
  else
  possibilities = []
  prices.each.with_index do |price_one, i|
    prices.each.with_index do |price_two, j|
      if j > i && price_two - price_one > 0
        possibilities << [(price_two - price_one), (i.to_s + "-" + j.to_s)]
      end
    end
  end
  output = possibilities.uniq.sort[-1][1].split("-")
  output.map { |ele| ele.to_i}
end
end

 #stock_picker([100,2,34,7,9,2,5,3])




class Hanoi

   attr_accessor :stacks, :disks

   def disks
   (1..3).to_a.reverse
   end

   def initialize
     @stacks = [disks, [], []]

   def get_stack(prompt)
    move_hash = { "a" => 0, "b" => 1, "c" => 2 }
    while true
      print prompt
      stack_num = move_hash[gets.chomp]
      return stack_num unless stack_num.nil?
      puts "Invalid move!"
    end
   end

   def over?
     stacks[0].empty? && stacks[1..2].any?(&:empty?)
   end

   def display
     max_height = stacks.map(&:count).max
     render_string = (max_height - 1).downto(0).map do |height|
       stacks.map do |stack|
         stack[height] || " "
       end.join("\t")
     end.join("\n")
   end


    def move_disk(from_stack, to_stack)
      from_stack, to_stack = @stacks.values_at(from_stack_num, to_stack_num)
      raise "cannot move from empty stack" if from_stack.empty?
      unless (to_stack.empty? || to_stack.last > from_stack.last)
        raise "cannot move onto smaller disk"
      end
      to_stack.push(from_stack.pop)
    end

   until over?
     puts display
     from_stack_num = get_stack("Move from: ")
     to_stack_num = get_stack("Move to: ")
     from_stack, to_stack = @stacks.values_at(from_stack_num, to_stack_num)
     raise "cannot move from empty stack" if from_stack.empty?
     unless (to_stack.empty? || to_stack.last > from_stack.last)
       raise "cannot move onto smaller disk"
     end
     to_stack.push(from_stack.pop)
     # ...
   end


end
end
# hanoi = Hanoi.new

#
# def hanoi
#   until over?
#      puts display
#      from_stack = get_stack("Move from: ")
#      to_stack = get_stack("Move to: ")
#      move_disk(from_stack, to_stack)
#   end
# end




# Warmup
#
#     Write a recursive method, range, that takes a start and an end
#     and returns an array of all numbers in that range, exclusive.
#     For example, range(1, 5) should return [1, 2, 3, 4]. If end < start,
#     you can return an empty array.

#     Write both a recursive and iterative version of sum of an array.


#range
def range(starting, ending)
  return [ending] if starting == ending
  return [] if ending < starting
  [starting] + range((starting+1), ending)
end

def range_iter(s, e)
  (s...e).map { |ele| ele  }
end

#sum of array
def sum_array(array)
  return array[0] if array.length == 1
  array[-1]+ sum_array(array[0..-2])
end

def sum_array_iter(array)
  count = 0
  array.each { |num| count+=num}
  count
end

#exponent v1

def exp(a, b)
  c = b -1
  return 1 if c < 0
  a * exp(a, c)
end


#exponent v2
#
# def exponent(num, power)
#   return 1 if power == 0
#   return num if power == 1
#
#   if num % 2 == 0
#     exponent(power, num / 2) * exponent(power, num / 2)
#
#   elsif num % 2 == 1
#     power * (exponent(power, (num - 1) / 2) * exponent(power, (num - 1) / 2))
#   end
#
# end

#exponent v2 thier solution

def exp2(base, power)
  return 1 if power == 0
  debugger
  half = exp2(base, power / 2)

  if power.even?
    half * half
  else
    # note that (power / 2) == ((power - 1) / 2) if power.odd?
    base * half * half
  end
end


class Array
  def deep_dup

    output = [].dup
    self.each do |e|
      if e.is_a?(Array) == false

        output << e
      elsif e.is_a?(Array) == true

        output << e.deep_dup
      end
    end
    output
  end
end

[1,2,3,4, [5], [[6]]].deep_dup





# Fibonacci
#
# Write a recursive and an iterative Fibonacci method. The method should
# take in an integer n and return the first n Fibonacci numbers in an array.
#
# You shouldn't have to pass any arrays between methods; you should be able
# to do this just passing a single argument for the number of Fibonacci
# numbers requested.


####Fibonacci Iterative
def Fibonacci(n)
  array = []
  if n == 1
    array = [1]
  elsif n == 2
    array = [1, 1]
  elsif n > 2
    array = [1,1]
    num_times = n -2
    num_times.times do
      new_num = array[-1] + array[-2]
      array << new_num
    end
  end
  array
end

puts Fibonacci(10)

# Fibonacci recursion version
def Fibonacci_rec(n)

  return [1] if n == 1
  return [1, 1] if n == 2

  Fibonacci_rec(n -1) << Fibonacci_rec(n-1)[-2] + Fibonacci_rec(n-1)[-1]

end





# Binary Search
#
# The binary search algorithm begins by comparing the target value to the value of
# the middle element of the sorted array. If the target value is equal to the middle
#  element's value, then the position is returned and the search is finished. If the
#  target value is less than the middle element's value, then the search continues on
#  the lower half of the array; or if the target value is greater than the middle
#   element's value, then the search continues on the upper half of the array. This
#    process continues, eliminating half of the elements, and comparing the target
#     value to the value of the middle element of the remaining elements - until the
#     target value is either found (and its associated element position is returned),
#      or until the entire array has been searched (and "not found" is returned).
#
# Write a recursive binary search: bsearch(array, target). Note that binary search
#  only works on sorted arrays. Make sure to return the location of the found object
#   (or nil if not found!). Hint: you will probably want to use subarrays.
#
# Make sure that these test cases are working:
#
# bsearch([1, 2, 3], 1) # => 0
# bsearch([2, 3, 4, 5], 3) # => 1
# bsearch([2, 4, 6, 8, 10], 6) # => 2
# bsearch([1, 3, 4, 5, 9], 5) # => 3
# bsearch([1, 2, 3, 4, 5, 6], 6) # => 5
# bsearch([1, 2, 3, 4, 5, 6], 0) # => nil
# bsearch([1, 2, 3, 4, 5, 7], 6) # => nil


require 'byebug'
def bsearch(array, target)
  #debugger
  return nil if array.length == 0
  middle_el = array.length / 2
  output = 0
  if target == array[middle_el]

    output = middle_el
  elsif target < array[middle_el]

    results = bsearch(array[0...middle_el], target)
    if results == nil
      return nil
    end
    output = results
  elsif target > array[middle_el]
    if array.length != array[(middle_el)..-1].length
      results = bsearch(array[(middle_el)..-1], target)
      if results == nil
        return nil
      end
    else
      return nil
    end

    output = middle_el + results
  end
  output
end

puts "bsearch"
puts bsearch([1, 2, 3, 4, 5, 6], 8)




# Merge Sort
#
# Implement a method merge_sort that sorts an Array:
#
#     The base cases are for arrays of length zero or one. Do not use a length-two
#     array as a base case. This is unnecessary.
#     You'll want to write a merge helper method to merge the sorted halves.
#     To get a visual idea of how merge sort works, watch this gif and check out this
#     diagram.

def merge(array)
  return array if array.length == 0
  return array if array.length == 1
  splitter = array.length / 2
  side1 = array[0...splitter]
  side2 = array[splitter..-1]
  merge(side1)
  merge(side2)
end
puts "merge"

#merge_helper()

puts merge([1,2,3,4,5])

#merge thier solution
class Array
  def merge_sort
    return self if count < 2
    middle = count / 2

    left, right = self.take(middle), self.drop(middle)
    sorted_left, sorted_right = left.merge_sort, right.merge_sort

    merge(sorted_left, sorted_right)
  end

  def merge(left, right)
    merged_array = []
    until left.empty? || right.empty?
      if left.first < right.first
        merged_array << left.shift
      elsif right.first < left.first
        merged_array << right.shift
      end
    end
    merged_array + left + right
  end
    # def merge(left, right)
    #   merged_array = []
    #   until left.empty? || right.empty?
    #     merged_array << (left.first < right.first) ? left.shift : right.shift
    #   end
    #
    #   merged_array + left + right
    # end
end




#
# Array Subsets
#
# Write a method subsets that will return all subsets of an array.
#
# subsets([]) # => [[]]
# subsets([1]) # => [[], [1]]
# subsets([1, 2]) # => [[], [1], [2], [1, 2]]
# subsets([1, 2, 3])
# # => [[], [1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]
#
# You can implement this as an Array method if you prefer.
#
# Hint: For subsets([1, 2, 3]), there are two kinds of subsets:
#
#     Those that do not contain 3 (all of these are subsets of [1, 2]).
#     For every subset that does not contain 3, there is also a corresponding subset that is the same, except it also does contain 3.
puts "subsets"

def subsets(array)

  output = Array.new([])

  output << array
  array.each_with_index do |e, i|
    copy = array.dup
    copy.delete_at(i)
    output.concat(subsets(copy))

  end
  output.uniq
end
  # puts arr
  # array.each do |el|
  #   puts el
  # end


p subsets([1,2,3])




#
#
# Permutations
#
# Write a recursive method permutations(array) that calculates all the permutations of the given array.
# For an array of length n there are n! different permutations. So for an array with three elements we
# will have 3 * 2 * 1 = 6 different permutations.
#
# permutations([1, 2, 3]) # => [[1, 2, 3], [1, 3, 2],
#                         #     [2, 1, 3], [2, 3, 1],
#                         #     [3, 1, 2], [3, 2, 1]]
#
# You can use Ruby's built in Array#permutation method to get a better understanding of
# what you will be building.
#
# [1, 2, 3].permutation.to_a  # => [[1, 2, 3], [1, 3, 2],
#                             #     [2, 1, 3], [2, 3, 1],
#                             #     [3, 1, 2], [3, 2, 1]]


def permutations(array)

  output = []
  rev = array.reverse
  output << array
  output << rev

  popped = array.pop
  array.unshift(popped)

  poppedr = rev.pop
  rev.unshift(poppedr)
  output.concat(permutations(array))
  output.concat(permutations(rev))

end
puts permutations([1,2,3])


#permutations - thier solution

def permutations(array)
  return [array] if array.length <= 1


  # Similar to the subsets problem, we observe that to get the permutations
  # of [1, 2, 3] we can look at the permutations of [1, 2] which are
  # [1, 2] and [2, 1] and add the last element to every possible index getting
  # [3, 1, 2], [1, 3, 2], [1, 2, 3], [3, 2, 1], [2, 3, 1]

  # pop off the last element
  first = array.shift
  # make the recursive call
  perms = permutations(array)
  # we will need an array to store all our different permutations
  total_permutations = []


  # Now we iterate over the result of our recusive call say [[1, 2], [2, 1]]
  # and for each permutation add first into every index. This new subarray
  # gets added to total_permutations.
  perms.each do |perm|
    (0..perm.length).each do |i|
      total_permutations << perm[0...i] + [first] + perm[i..-1]
    end
  end
  total_permutations
end

require 'set'

class WordChainer
  def initialize(dictionary_file_name)
    @dictionary_array = File.open(dictionary_file_name).map { |word| word.chomp }.to_set
  end
  def dictionary_array
    @dictionary_array
  end

  def adjacent_words(word)
    close_words = []
    dictionary_array.each do |dict_w|
      if word.length == dict_w.length && differences_permitted?(word, dict_w) == true
          close_words << dict_w
      end
    end
    close_words
  end

  def differences_permitted?(word1, word2)
    differences = 0
    word1.each_char.with_index do |ch, i|
      if word1[i] != word2[i]
        differences+=1
      end
    end

    if differences <= 1
      true
    else
      false
    end
  end



  def run(source, target)

    @current_words = [source]
    @all_seen_words = {source => nil}

    def current_words=(word)
      @current_words = word
    end


    def explore_current_words
      new_current_words = []
      @current_words.each do |current_word|

        adjacent_words(current_word).each do |adj_word|

          if @all_seen_words.include?(adj_word) == false
            new_current_words << adj_word
            @all_seen_words[adj_word] = current_word
          end

        end
      end

      new_current_words.each do |word|
        if @all_seen_words.include?(word) == true
          puts word + " came from: " + @all_seen_words[word]
        end
      end
      new_current_words
    end


    i = 0
    while @current_words.length > 0
      @current_words = explore_current_words
      puts  "\n " + (i+1).to_s + " levels away from source:\n"
      print @current_words
      puts ""
      i+=1
    end

    def build_path(target)
      path = []
      path << @all_seen_words[target]

      while @all_seen_words[path[-1]] != nil
        path << @all_seen_words[path[-1]]
        #puts @all_seen_words[path[-1]]

      end
      puts target
      puts path
    end

    build_path(target)
  end

end

chain = WordChainer.new("dictionary.txt")
#puts chain.dictionary_array
#chain.adjacent_words("ear")
p  chain.run("build", "baker")

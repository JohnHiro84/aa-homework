require_relative 'word_chainer'



chain = WordChainer.new("dictionary.txt")

system "clear" or system "cls"
game_over = false
while game_over == false

  puts "\n\nplease type in 2 words that are the same length"
  puts "Examples (bill, bake) or (tree, take)\n"
  input1 = gets.chomp
  input2 = gets.chomp
  system "clear" or system "cls"

  if input1 == "exit" || input2 == "exit"
    game_over = true
  elsif input1.length == input2.length
    chain.run(input1, input2)
  elsif
    system "clear" or system "cls"
    puts "please make sure the 2 words are the same length"
  end

  puts "\n\ntype in 2 more words or type in exit to leave the program\n"
end

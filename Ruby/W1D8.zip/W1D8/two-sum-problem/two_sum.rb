

##brute force

def bad_two_sum?(array, target)
  i = 0
  array.each do |ele|
    array.each do |item|

      i+=1
      if ele != item
        if ele + item == target
          puts i
          return true
        end
      end
    end
  end
  puts i
  false
end


  # Note: you can cut the running-time significantly by returning early,
  # and by not checking pairs more than once. However, these micro-optimizations
  # will not improve the time complexity of the solution. Do you see why?

  # returning early can make it run a little bit faster for best case scenario where the numbers are found early
  # but with the worst case scenario it will still run through the array about twice, which makes it:
  # time is quadratic
  # space is quadratic too as have to save position in array twice for i and j





  def okay_two_sum?(array, target)
    array.sort.reverse.each { |ele| array.delete(ele) if ele > target}

    puts array.to_s
    array.each do |ele|
      array.each do |item|
        if ele != item
          return true if ele + item == target
        end
      end
    end
    false
  end

## since were looking to see if the sum of 2 numbers is equal to the target, it doesnt seem like we're
## working with negative numbers and so I thought maybe if we delete any number greater than the target number

# log time
# linear space






##########hash map

 ## hash maps have O(1) #set and O(1) #get,
 ## so you can build a hash out of each of the n elements in o(n time)

def two_sum_hash(array, target)
  hash = Hash.new(0)
  array.each do |ele|
    array.each do |j|
      if ele != j
        hash[ele + j] = ele + j
      end
    end
  end
  hash.has_value?(target)
end

two_sum_hash([1,2,3,4,5,6,7,8], 12)


#  quadratic time complexity
#  space is
## https://medium.com/@andrewsouthard1/binary-search-implementation-in-ruby-9636a4bf373c

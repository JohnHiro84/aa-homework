
list = [ 0, 3, 5, 4, -5, 10, 1, 90 ]


####my_min phase 1
def my_min(array)
  smallest = array[0]
  array.each do |number1|
    return smallest = number1 if array.all? { |ele| ele >= number1}
  end
  smallest
end
my_min(list)

##this past method has a time complexity of quadratic x^2

###my_min phase 2

def my_min_faster(array)
  smallest = array[0]
  array.each do |num|
    if num < smallest
      smallest = num
    end
  end
  smallest
end

###this past method has a linear  o(n) time complexity

require 'byebug'

##Largest Contiguous Sub-sum

def contiguous_subsum(array)

  possibilities = possible_combos(array)
  largest = possibilities[0]
  possibilities.each do |sub|
    if sub.sum > largest.sum
      largest = sub
    end

  end
  puts largest.to_s
  largest
end

#helper method, gives you all array possibilities
def possible_combos(list)
  combinations = []
  i = 0
  while i < list.length
    j = 0
    while j < list.length
      combinations << list[i..j] if list[i..j].length > 0
      j+=1
    end
    i+=1
  end
combinations
end
#possible_combos(list)
contiguous_subsum([5, 3, -7])
contiguous_subsum([2, 3, -6, 7, -6, 7])
contiguous_subsum([-5, -1, -3])

### the time complexity of this method is quadratic


###################contiguous subsum version 2



def contiguous_subsum_faster_version(array)

  possibilities = possible_combos_faster_version(array)
  largest = possibilities[0]
  possibilities.each do |sub|
    if sub.sum > largest.sum
      largest = sub
    end

  end
  puts largest.to_s
  largest
end

#helper method, gives you all array possibilities
def possible_combos_faster_version(list)
  combinations = []
  largest = []
  i = 0
  while i < list.length
    j = 0
    while j < list.length

      combinations << list[i..j] if list[i..j].length > 0
      #debugger
      largest = list[i..j] if combinations.length == 1
      largest = list[i..j] if list[i..j].sum > largest.sum && list[i..j].length > 0
      j+=1
    end
    i+=1
  end
largest
#combinations
end

puts possible_combos_faster_version([5, 3, -7]).to_s
puts possible_combos_faster_version([2, 3, -6, 7, -6, 7]).to_s
puts possible_combos_faster_version([-5, -1, -3]).to_s


##both versions are probably quadratic, the 2nd is probably a little faster

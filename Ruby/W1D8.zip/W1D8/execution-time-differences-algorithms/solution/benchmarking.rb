require 'benchmark'
require_relative 'execution_time_differences_solution'



# my_min_1a(list)
# my_min_1b(list)
# my_min_2(list)
# largest_contiguous_subsum1(array)
# largest_contiguous_subsum2(arr)


n = 3000000
Benchmark.bm(7) do |x|
  x.report("my_min_1a(list):")   { my_min_1a([1,2,3,4,5,6,7,8,9]) }
  x.report("my_min_1b(list):") { my_min_1b([1,2,3,4,5,6,7,8,9]) }
  x.report("my_min_2(list):")  { my_min_2([1,2,3,4,5,6,7,8,9]) }
  x.report("largest_contiguous_subsum1:")  { largest_contiguous_subsum1([1,2,3,4,5,6,7,8,9]) }
  x.report("largest_contiguous_subsum2:")  { largest_contiguous_subsum2([1,2,3,4,5,6,7,8,9]) }
end

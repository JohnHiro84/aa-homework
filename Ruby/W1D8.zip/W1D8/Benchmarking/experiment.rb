require 'benchmark'


def hello
  "hello"
end

def hello_1000
  1000.times do
    hello
  end
end


def hello_10000
  10000.times do
    hello
  end
end

def hello_100000
  10000.times do
    hello
  end
end

def multiply_10
  array = [1,2,3,4,5,6,7,8,9,10]
  array.each do |num|
    array.each do |n2|
      num * n2
    end
  end
end

def multiply_100
  array = (1..100).map { |n| n}
  array.each do |num|
    array.each do |n2|
      num * n2
    end
  end
end

def multiply_1000
  array = (1..1000).map { |n| n}
  array.each do |num|
    array.each do |n2|
      num * n2
    end
  end
end





# puts Benchmark.measure { hello_1000}
# puts Benchmark.measure { hello_10000}
# puts Benchmark.measure { hello_100000}
#
# n = 5000000
# Benchmark.bm do |x|
#   x.report { for i in 1..n; a = "1"; end }
#   x.report { n.times do   ; a = "1"; end }
#   x.report { 1.upto(n) do ; a = "1"; end }
# end
#
#
#
# puts "array sort"
#
# array = (1..100).map { rand }
#
# Benchmark.bmbm do |x|
#   x.report("sort!") { array.dup.sort! }
#   x.report("sort")  { array.dup.sort  }
# end




#
# begin_time = Time.now
# sleep 0.7
# hello_10000
# end_time = Time.now
# puts "Time taken is #{end_time - begin_time}."


n = 3000000
Benchmark.bm(7) do |x|
  x.report("hello_1000:")   { hello_1000 }
  x.report("hello_10000:") { hello_10000}
  x.report("hello_100000:")  { hello_100000 }
end



n = 3000000
Benchmark.bm(7) do |x|
  x.report("multiply_10:")   { multiply_10 }
  x.report("multiply_100:") { multiply_100}
  x.report("multiply_1000:")  { multiply_1000 }
end

require_relative 'anagrams'
require 'benchmark'

##benchmarking the anagrams speed

Benchmark.bm(7) do |x|
  x.report("first_anagram?(1,2):")   { first_anagram?("asdfghjklp", "qwertyuiop" ) }
  x.report("second_anagram?(1,2):") { second_anagram?("asdfghjklp", "qwertyuiop" )}
  x.report("third_anagram?(1,2):") { third_anagram?("asdfghjklp", "qwertyuiop" )}
  x.report("fourth_anagram?(1,2):") { fourth_anagram?("asdfghjklp", "qwertyuiop" )}

end

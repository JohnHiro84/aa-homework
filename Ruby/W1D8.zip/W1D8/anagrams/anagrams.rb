
def anagrams(word1, word2)
  array_w = word1.split("")
  word1_possibilities = array_w.permutation.to_a
  #puts word1_possibilities.to_s

  word1_possibilities.each do |pos|
    if pos.join == word2
      return true
    end
  end
  false
end


print anagrams("maple", "mleap")

#2^n, slower than quadratic? space and time?
#factorial


def second_anagram?(word1, word2)

  w1_array = word1.split("")
  w2_array = word2.split("")
  count = 0
  w1_array.each do |l1|
    #w2_array.include?(w1_letter)
    w2_array.each.with_index do |l2, i|
      if l1 == l2
        w2_array.delete_at(i)
        count+=1
      end
    end
  end

  puts count
  puts w2_array.to_s
  w2_array.to_s
  if count == word1.length && word1.length == word2.length && w2_array.empty? == true
    true
  else
    false
  end
end

puts second_anagram?("abracadabra", "abracadabar")


##second anagram is faster than the first. maybe its quadratic?
##linear space




###third anagram

def third_anagram(word1, word2)
  sorted1 = word1.split("").sort
  sorted2 = word2.split("").sort
  if sorted1.join == sorted2.join
    true
  else
    false
  end
end


# way faster
#id say space is close to constant 0(1)
#time is linear

#thier awnswers
# O(n*log(n)) linearithmic time
# O(n) linear space




###fourth anagram

def fourth_anagram(word1, word2)
  anagram = true
  word1_hash, word2_hash = Hash.new(0), Hash.new(0)

  word1.split("").each do |letter|
    word1_hash[letter]+=1
  end
  word2.split("").each do |letter|
    word2_hash[letter]+=1
  end
  word1_hash.each do |k, v|

    if word2_hash.has_key?(k) == false || word2_hash[k] != v
      anagram = false
    end
  end
  word2_hash.each do |k, v|
    if word1_hash.has_key?(k) == false || word1_hash[k] != v
      anagram = false
    end
  end
  anagram
end
fourth_anagram("hello", "there")

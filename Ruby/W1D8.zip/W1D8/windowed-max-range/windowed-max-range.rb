
#
# Given an array, and a window size w, find the maximum range (max - min) within a set of w elements.

#
# One approach to solving this problem would be:
#
#     Initialize a local variable current_max_range to nil.
#     Iterate over the array and consider each window of size w. For each window:
#         Find the min value in the window.
#         Find the max value in the window.
#         Calculate max - min and compare it to current_max_range. Reset the value of current_max_range if necessary.
#     Return current_max_range.
#
#  Implement this approach in a method, max_windowed_range(array, window_size).
#  Make sure your code passes the following test cases:
#
# windowed_max_range([1, 0, 2, 5, 4, 8], 2) == 4 # 4, 8
# windowed_max_range([1, 0, 2, 5, 4, 8], 3) == 5 # 0, 2, 5
# windowed_max_range([1, 0, 2, 5, 4, 8], 4) == 6 # 2, 5, 4, 8
# windowed_max_range([1, 3, 2, 5, 4, 8], 5) == 6 # 3, 2, 5, 4, 8




def max_windowed_range(array, window_size)
  current_max_range = [0,0]
  current_range_num = 0
  i = 0
  while i < array.length
    if (i + window_size) <= array.length
      puts array[i...(i + window_size)].to_s
      range = array[i...(i + window_size)].max - array[i...(i + window_size)].min
      current_max_num = current_max_range.max - current_max_range.min
      if range > current_max_num
        current_max_range = array[i...(i + window_size)]
        current_range_num = range
      end
    end
    i+=1
  end
  [current_max_range, current_range_num]
end

# max_windowed_range([19,2,30,4,50,6,70,8],2)
# max_windowed_range([1,2,3,4,5,6,7,8],3)
#
# max_windowed_range([1, 0, 2, 5, 4, 8], 2)
# max_windowed_range([1, 0, 2, 5, 4, 8], 3)
# max_windowed_range([1, 0, 2, 5, 4, 8], 4)
# max_windowed_range([1, 3, 2, 5, 4, 8], 5)

###linear time o(n)
###linear space o(n)


##calculating window size is costly
#min and max methods are o(n) complexity












class MyQueue
  #attr_accessor :store
  def initialize
    @store = []
  end

  def peek
    store.last
  end

  def enqueue(value)
    store << value
  end

  def dequeue
    store.shift
  end

  def empty?
    store.empty?
  end

  def size
    store.length
  end
end

## Implement peek, size, empty?, enqueue,
## and dequeue methods on your Queue.







class MyStack
  #attr_accessor :store
  def initialize
    @store = []
  end

  def push(value)
    @store << value
  end

  def pop
    @store.pop
  end

  def peek
    @store.last
  end

  def size
    @store.length
  end

  def empty?
    @store.empty?
  end

  def max
    @store.sort
    @store[-1]
  end

  def min
    @store.sort
    @store[0]
end
#
# Implement peek, size, empty?, pop and push methods on your Stack.
# A stack is first in, last out (FILO).

require 'byebug'
class StackQueue
  def initialize
    @queue = MyStack.new
    @queue2 = MyStack.new
  end

  def size
  end

  def empty?

  end

  def enqueue(value)
    @queue.push(value)
  end

  def dequeue

    #phase 1 move elements to the 2nd stack
    @queue.size.times do
      popped = @queue.pop
      @queue2.push(popped)
      puts popped
      puts @queue2
      puts @queue2.size
    end

    #phase 2 dump the first element from the 2nd stack
    @queue2.pop

    #phase 3 put the elements back in stack 1
    @queue2.size.times do

      popped_again = @queue2.pop
      @queue.push(popped_again)
      puts popped_again

    end
  end

end
#
# sq = StackQueue.new
# sq.enqueue(1)
# sq.enqueue(12)
# sq.enqueue(14)
# sq.enqueue(16)
# sq.dequeue
# debugger
# sq.size
# #mystack FILO
# #queue FIFO

Implement peek, size, empty?, max, min, pop, push methods on your MinMaxStack.

class MinMaxStack
  def initialize
    @stack = []
  end

  def peek
    @stack[-1]
  end

  def size
    @stack.length
  end
  def empty?
    @stack.empty?
  end

  def max
    @stack.sort
    @stack[-1]
  end

  def min
    @stack.sort
    @stack[0]
  end

  def push(value)
    @stack << value
  end

  def pop
    @stack.pop
  end
end

class MinMaxStackQueue
  #What methods are needed to solve this problem in O(n) time?
  def initialize

  end


end

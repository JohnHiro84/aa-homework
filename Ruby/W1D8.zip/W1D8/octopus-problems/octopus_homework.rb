fish = ['fish', 'fiiish', 'fiiiiish', 'fiiiish', 'fffish', 'ffiiiiisshh', 'fsh', 'fiiiissshhhhhh']


# Sluggish Octopus
# Find the longest fish in O(n2) time. Do this by comparing all
# fish lengths to all other fish lengths

def find_longest_fish(fish)
  longest = ""
  num_times_ran  = 0
  fish.each do |ind|
    fish.each do |j|
      puts num_times_ran
      if ind.length > j.length
        longest = ind
      elsif j.length > ind.length
        longest = j
      end
      num_times_ran +=1
    end
  end
  puts num_times_ran
  longest
end


# Dominant Octopus
# Find the longest fish in O(n log n) time. Hint: You saw a sorting algorithm
# that runs in O(n log n) in the Sorting Complexity Demo. Accessing this on GitHub?
# Use this link. Remember that Big O is classified by the dominant term.


class Dominant_Oct
  def self.merge_sort (array, &prc)
    return array if array.length <= 1

    mid_idx = array.length / 2
    merge(
      merge_sort(array.take(mid_idx), &prc),
      merge_sort(array.drop(mid_idx), &prc),
      &prc
    )
  end

  # NB: In Ruby, shift is an O(1) operation. This is not true of all languages.
  def self.merge(left, right, &prc)
    merged_array = []
    prc = Proc.new { |fish1, fish2| fish1.length <=> fish2.length } unless block_given?
    until left.empty? || right.empty?
      case prc.call(left.first, right.first)
      when -1
        merged_array << left.shift
      when 0
        merged_array << left.shift
      when 1
        merged_array << right.shift
      end
    end

    merged_array + left + right
  end
end
Dominant_Oct.merge_sort(fish)[-1]

# Clever Octopus
# Find the longest fish in O(n) time. The octopus can hold on to the longest fish
#  that you have found so far while stepping through the array only once.

def longest_fish_once_array(fish)
  longest = ""
  fish.each { |fish| longest = fish if fish.length > longest.length}
  longest
end


# Dancing Octopus
# Full of fish, the Octopus attempts Dance Dance Revolution.
# The game has tiles in the following directions:
# To play the game, the octopus must step on a tile with her corresponding tentacle.
# We can assume that the octopus's eight tentacles are numbered and correspond to the tile direction indices.



# Slow Dance
# Given a tile direction, iterate through a tiles array to return the tentacle number
# (tile index) the octopus must move. This should take O(n) time.
# examples:
# slow_dance("up", tiles_array)
# > 0
# slow_dance("right-down", tiles_array)
# > 3


tiles_array = ["up", "right-up", "right", "right-down", "down", "left-down", "left", "left-up" ]
def slow_dance(dir, tiles)
  tiles.each.with_index { |tile_dir, i| return i if tile_dir == dir}
end


# Constant Dance!
#
# Now that the octopus is warmed up, let's help her dance faster.
# Use a different data structure and write a new function so that you
# can access the tentacle number in O(1) time.
#
# fast_dance("up", new_tiles_data_structure)
# > 0
#
# fast_dance("right-down", new_tiles_data_structure)
# > 3


####thier solution for constant octopus dance 

# constant octopus dance
#use a hash for constant lookup
tiles_hash = {
    "up" => 0,
    "right-up" => 1,
    "right"=> 2,
    "right-down" => 3,
    "down" => 4,
    "left-down" => 5,
    "left" => 6,
    "left-up" => 7
}

def fast_dance(direction, tiles_hash)
  tiles_hash[direction]
end

require_relative 'minesweeper'

puts "type in 's' to start a new game or 'l' to load previous game"
input = gets.chomp
if input == "l"
  sweep = YAML.load(File.read("minesweeper_saved_game.yml"))
elsif input == "s"
  sweep = Minesweeper.new
end

until sweep.game_over == true
  system "clear" or system "cls"
  puts
  sweep.board.print_hidden_board
  sweep.guess
  sweep.game_over?
end

class Employee

  attr_accessor :name, :title, :salary, :boss
  def initialize(name, title, salary, boss)
    @name = name
    @title = title
    @salary = salary
    @boss = boss
  end

  def all_info
    puts name
    puts title
    puts salary
    puts boss
  end

  def bonus(multiplier)
    bonus = (salary) * multiplier
  end
end

class Manager < Employee

  attr_accessor :name, :title, :salary, :boss, :employees

  def initialize(name, title, salary, boss)
    super(name, title, salary, boss)
    @employees = []
  end

  def manage_employee(emp_inst)
    @employees << emp_inst
  end

  def all_managed_employees
    puts "all employees managed by:" + name.to_s
    employees.each do |worker|
      puts worker.name
    end
  end

  def bonus(multiplier)
    all_subordinates_salary = 0
    employees.each do |employee|
      all_subordinates_salary += employee.salary
    end
    bonus = (all_subordinates_salary) * multiplier
  end

end

bob = Employee.new("bob", "worker", 50000, "Bob")
bob.all_info
becca = Employee.new("rebecca", "worker", 70000, "Becca")
becca.all_info

grendale = Manager.new("Grenny", "ceo", 100000, "none shes the top")
grendale.manage_employee(bob)
grendale.manage_employee(becca)
grendale.all_info
grendale.all_managed_employees
puts grendale.employees
puts grendale.bonus(3)
puts "salary for reg employees"
puts bob.bonus(2)
puts becca.bonus(3)

require_relative 'piece'

class Board

  attr_accessor :chess_board

  def initialize
    @chess_board = create_board
    give_pieces_board_access
  end

  def create_board
    chess_board = Array.new(8){[]}
    chess_board.each.with_index do |row, idx|
      col = 0
      8.times do
        if idx == 0 || idx == 1 || idx == 6 || idx == 7
          if (idx == 0 && col == 0) || (idx == 0 && col == 7) || (idx == 7 && col == 0) || (idx == 7 && col == 7)
            row << Rook.new("red", [idx, col]) if idx == 0
            row << Rook.new("black", [idx, col]) if idx == 7
          elsif (idx == 0 && col == 2) || (idx == 0 && col == 5) || (idx == 7 && col == 2) || (idx == 7 && col == 5)
            row << Bishop.new("red", [idx, col]) if idx == 0
            row << Bishop.new("black", [idx, col]) if idx == 7
          elsif (idx == 0 && col == 3) || (idx == 7 && col == 3)
            row << Queen.new("red", [idx, col]) if idx == 0
            row << Queen.new("black", [idx, col]) if idx == 7
          elsif (idx == 0 && col == 4) || (idx == 7 && col == 4)
            row << King.new("red", [idx, col]) if idx == 0
            row << King.new("black", [idx, col]) if idx == 7
          elsif (idx == 0 && col == 1) || (idx == 0 && col == 6)|| (idx == 7 && col == 1)  || (idx == 7 && col == 6)
            row << M_Knight.new("red", [idx, col]) if idx == 0
            row << M_Knight.new("black", [idx, col]) if idx == 7
          else
            if idx == 1
              row << Pawn.new("red", [idx, col])
            elsif idx == 6
              row << Pawn.new("black", [idx, col])
            end
          end
        else
          row << NullPiece.new
        end
        col+=1
      end
    end
    chess_board
  end

  def give_pieces_board_access
    chess_board.each do |row|
      row.each do |piece|
        piece.board = self.chess_board
      end
    end
  end

  def [](position)
    row, col = position
    @chess_board[row][col]
  end

  def []=(position, val)
    row, col = position
    @chess_board[row][col] = val
  end

  def move_piece(start_pos, end_pos)
    raise ArgumentError.new("there is no piece at starting position") if self.[](start_pos).class == NullPiece
    #raise ArgumentError.new("that piece cannot move to that position") if self.[](start_pos).ability_to_move == false
    raise ArgumentError.new("there is a piece allready at the ending position") if self.[](end_pos).class == Piece

    if self.chess_board[start_pos[0]][start_pos[1]].moves.include?(end_pos)
      moving_piece_obj = self.[](start_pos).dup
      empty_space_obj = self.[](end_pos).dup

      if self.chess_board[end_pos[0]][end_pos[1]].class == NullPiece
        #empty the old space
        self.[]=(start_pos, empty_space_obj)

        # move the peice over
        self.[]=(end_pos, moving_piece_obj)
        moving_piece_obj.location = end_pos

      elsif self.chess_board[start_pos[0]][start_pos[1]].team != self.chess_board[end_pos[0]][end_pos[1]].team && self.chess_board[start_pos[0]][start_pos[1]].team != 'none' && self.chess_board[end_pos[0]][end_pos[1]].team != 'none'

        self.[]=(start_pos, NullPiece.new)
        #move piece over
        self.[]=(end_pos, moving_piece_obj)
        moving_piece_obj.location = end_pos
      end
    else
      puts "cant move that piece there, learn chess buddy"
    end

  end
  #
  # def print_board
  #   self.chess_board.each do |row|
  #     row.each do |piece|
  #       print " " + piece.class.to_s[0] + " "
  #     end
  #     print "\n"
  #   end
  # end
end
#
# a = Board.new
# a.chess_board
# puts a.chess_board
# #puts a.[]([0,1]).class == NullPiece
# a.print_board
# a.move_piece([0,0],[4,4])
# puts
# puts
# a.print_board
# a.[]=([4,4], Bishop.new(a.chess_board))
# a.print_board

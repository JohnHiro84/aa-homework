require_relative 'board'
require_relative 'cursor'
require 'colorized_string'


class Display
    attr_accessor :board #:cursor

    def initialize(board_inst)
      @board = board_inst
      #@cursor = Cursor.new([0,0], board.chess_board)
    end

    def print_board
      board.chess_board.each do |row|
        row.each do |piece|
          print " "
          if piece.class.to_s[0] == "N"
            print easy_color(piece.class.to_s[0], :white)
          elsif piece.team == "red"
            print easy_color(piece.class.to_s[0], :red)
          elsif piece.team == "black"
            print easy_color(piece.class.to_s[0], :black)
          end
          print " "
        end
        print "\n"
      end
    end

    def easy_color(string, color)
       ColorizedString[string].colorize(color)
    end
end

a = Board.new
a.chess_board
#puts a.chess_board


display = Display.new(a)
display.print_board
#puts "this should have avail prox spots"

#puts 'puts a.chess_board[4][4].proximity_potential_spots.to_s'
#puts a.chess_board[4][4].proximity_potential_spots.to_s


puts "M_Knight"
puts "a.chess_board[0][1].moves.to_s"
#puts a.chess_board[0][1].moves.to_s
a.move_piece([0,1],[2,0])
a.move_piece([2,0],[4,1])
puts a.chess_board[4][1].moves.to_s

puts "pawn"
a.move_piece([1,2],[3,2])
a.move_piece([3,2],[5,2])
puts a.chess_board[5][2].moves.to_s


a.move_piece([1,1],[3,1])

puts "bishop"
a.move_piece([0,2],[1,1])
a.move_piece([1,1],[4,4])
a.move_piece([4,4],[3,5])
a.move_piece([3,5],[2,4])
a.move_piece([2,4],[3,3])
puts a.chess_board[3][3].moves.to_s


a.move_piece([0,0],[0,2])
a.move_piece([0,2],[2,2])
a.move_piece([2,2],[2,6])
puts "rook"
puts "a.chess_board[0][2].all_available_spots.to_s"
puts a.chess_board[2][6].all_available_spots.to_s


puts "queen"
a.move_piece([0,3],[0,2])
a.move_piece([0,2],[4,2])
a.move_piece([4,2],[4,4])

puts "queen"
puts a.chess_board[4][4].all_available_spots.to_s
puts a.chess_board[4][4].moves.to_s
a.move_piece([4,4],[6,4])
a.move_piece([6,4],[6,5])
a.move_piece([6,5],[6,6])
a.move_piece([6,6],[6,7])
a.move_piece([6,7],[6,3])
a.move_piece([6,3],[6,2])
a.move_piece([6,2],[6,1])
a.move_piece([6,1],[6,0])
a.move_piece([6,0],[7,0])

x = 0
y = 1
6.times do

  a.move_piece([7,x],[7,y])
  x+=1
  y+=1
end
a.move_piece([7,7],[1,7])
#a.move_piece([1,7],[1,6])
a.move_piece([7,6],[3,6])

#
# puts "black pawn moves"
# puts a.chess_board[6][4].moves.to_s
# a.move_piece([6,4],[5,4])
# puts a.chess_board[5][4].moves.to_s
# a.move_piece([7,3],[3,7])
# puts "weiei"
# puts a.chess_board[3][7].class
#debugger
#puts a.chess_board[3][7].proximity_potential_spots.to_s
puts
#a.move_piece([3,7],[2,7])
#debugger
#a.move_piece([3,7],[3,4])
#
#
puts "queen moves"
puts a.chess_board[4][4].team
puts a.chess_board[4][6].team
display.print_board



# a.move_piece([0,2],[3,6])
# puts "bishop"
# puts "a.chess_board[3][6].all_available_spots.to_s"
# #puts a.chess_board[3][6].all_available_spots.to_s
# #puts a.chess_board[3][6].moves.to_s
#


# puts "M_Knight"
# puts "a.chess_board[7][6].moves.to_s"
# puts a.chess_board[7][6].moves.to_s


#puts "puts a.chess_board[0][2].all_available_spots.to_s"
#puts a.chess_board[0][2].all_available_spots.to_s


# a.move_piece([0,3],[3,3])
# puts "queen"
# puts "puts a.chess_board[3][3].all_available_spots.to_s"
# puts a.chess_board[3][3].all_available_spots.to_s
#
# puts "King"
# puts "a.chess_board[0][4].moves.to_s"
# puts a.chess_board[0][4].moves.to_s
#
# puts "Pawn"
# puts "a.chess_board[1][4].moves.to_s"
# puts a.chess_board[1][7].moves.to_s
# # puts a.chess_board[1][7].location
# display.print_board
#

# puts a.chess_board[0][2].team
# puts a.chess_board[0][2].proximity_potential_spots

#puts a.chess_board[0][3].proximity_potential_spots.to_s
# puts a.chess_board[0][1].team
# puts a.chess_board[7][7].team
# puts a.chess_board[3][7].team
#
#a.move_piece([0,0],[4,4])
# a.move_piece([7,7],[3,3])
# a.move_piece([1,1], [5,5])
# puts
# puts
# #a.print_board
# display = Display.new(a)
# display.print_board
# puts a.chess_board[0][1].ability_to_move
# #display.cursor.get_input

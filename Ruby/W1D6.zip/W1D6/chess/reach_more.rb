require 'byebug'

def reach_more(coords)

  #location = [4,4]

  next_spots = []
  #debugger
  coords.each do |pos|
    # puts "pos[0]" + pos[0].to_s
    # puts "pos[1]" + pos[1].to_s
    # puts location[0]
    # puts location[1]

  
    x_dir = 0
    x_change = pos[0] - location[0]
      #will tell you 1. if change, 2.if so what dir, L or R
    if x_change != 0
      x_dir = 1 if x_change.positive? == true
      x_dir = -1 if x_change.negative? == true
    end



    y_dir = 0
    y_change = pos[1] - location[1]
      #will tell you 1. if change, 2.if so what dir, L or R
    if y_change != 0
      y_dir = 1 if y_change.positive? == true
      y_dir = -1 if y_change.negative? == true
    end


    if x_change != 0 || y_change !=0
      next_spots << [(pos[0] + x_dir), (pos[1] + y_dir)]
    end
  end
  #puts next_spots.to_s
  next_spots

end

reach_more([[3,3],[5,5]])


#orig_spot
#new_potential
#reaching_further



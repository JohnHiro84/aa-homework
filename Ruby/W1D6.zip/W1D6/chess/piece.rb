require 'byebug'

class Piece

  attr_accessor :ability_to_move, :board, :team, :location, :enemy_spots
  def initialize(team, location)
    @type = "real_piece"
    @ability_to_move = true
    @board = []
    @team = team
    @location = location
    @enemy_spots = []
  end

  def moves

  end
end

class NullPiece < Piece
  def initialize
    @type = "null_piece"
    @ability_to_move = false
    @team = "none"
  end
end


#####sliding pieces ############################

module SlidingPiece

  def tell_me_direction
    puts "this piece can move #{self.move_dirs}"
    self.move_dirs
  end

  #can implement moves, but needs to
  #know the directions, diag,horiz, both
  def which_coordinates
    deltas = []
    self.move_dirs.each do |direction|
      if direction == "horizontal"
        deltas.concat([[0,  -1],[ 0,  1]])
      elsif direction == "vertical"
        deltas.concat([[1,  0],[ -1,  0]])
      elsif direction == "diagonal"
        deltas.concat([[-1, -1],[-1,  1],[ 1, -1],[ 1,  1]])
      end
    end
    deltas
  end

 # def scan_around_piece
 #  puts self.move_dirs
 #  puts location.to_s
 # end

 def proximity_potential_spots
   pos = self.location
   adjacent_coords = which_coordinates.map do |(dx, dy)|
     [pos[0] + dx, pos[1] + dy]
   end.select do |row, col|
     [row, col].all? do |coord|
       coord.between?(0, 7)
     end
   end
   adjacent_coords
end

def potential_spots_empty?(coords)
  empty_spots = []
  #puts self.team
  coords.each do |pos|
    if board[pos[0]][pos[1]].class == NullPiece
      if pos[0].between?(0, 7) && pos[1].between?(0, 7)
        empty_spots << pos
      end
    end
    #is an enemy at that spot?
    enemy_at_that_spot?(pos)
  end
  empty_spots
end

def enemy_at_that_spot?(pos)
  if pos[0].between?(0, 7) && pos[1].between?(0, 7)
    if board[pos[0]][pos[1]].team != self.team && board[pos[0]][pos[1]].team != "none"
      #puts "here"
      #puts board[pos[0]][pos[1]].location.to_s
      #puts board[pos[0]][pos[1]].team.to_s
      enemy_spots << pos
    end
  end
end

require 'byebug'

def reach_more_potential_spots(coords)

  #location = [4,4]

  next_spots = []
  #debugger
  coords.each do |old_spot|

    x_dir = 0
    x_change = old_spot[0] - self.location[0]
    if x_change != 0
      x_dir = 1 if x_change.positive? == true
      x_dir = -1 if x_change.negative? == true
    end

    y_dir = 0
    y_change = old_spot[1] - self.location[1]
    if y_change != 0
      y_dir = 1 if y_change.positive? == true
      y_dir = -1 if y_change.negative? == true
    end
    new_spot = [(old_spot[0] + x_dir), (old_spot[1] + y_dir)]
    if x_change != 0 || y_change !=0
      next_spots << new_spot
    end

  end
  #puts next_spots.to_s
  next_spots

end



  def recursive_spot_check(arrays)
    #debugger
    more_spots = []
    if potential_spots_empty?(arrays).length > 0
      nextone = potential_spots_empty?(reach_more_potential_spots(arrays))
      if nextone.empty? == false
        more_spots.concat(nextone)
        more_spots.concat(recursive_spot_check(nextone))
      end
    end
    more_spots
  end

  def all_available_spots

    avail_spots = []
    @enemy_spots = []

    avail_neighbor_spots = potential_spots_empty?(proximity_potential_spots)

    avail_spots.concat(avail_neighbor_spots)
    avail_spots.concat(recursive_spot_check(avail_neighbor_spots))
    #puts "enemy Spots:" + enemy_spots.to_s
    #puts avail_spots.to_s
    avail_spots.concat(enemy_spots)
  end

end


class Bishop < Piece
  include SlidingPiece
  def initialize(team, location)
    super(team, location) #(parent_board)
    #@board = parent_board
  end

  def moves
    #returns an array of places a piece
    #can move to
    all_available_spots
  end

  def move_dirs
    direction = ["diagonal"]
  end
end

class Rook < Piece
  include SlidingPiece
  def initialize(team, location)
    super(team, location)
  end
   def moves
    all_available_spots
   end

  def move_dirs
    direction = ["horizontal", "vertical"]
  end
end

class Queen < Piece
  include SlidingPiece

  def initialize(team, location)
    super(team, location)
  end

  def moves
    all_available_spots
  end

  def move_dirs
    direction = ["diagonal", "horizontal", "vertical"]
  end
end



module SteppingPiece

   def proximity_potential_spots(deltas)
     pos = self.location
     adjacent_coords = deltas.map do |(dx, dy)|
       [pos[0] + dx, pos[1] + dy]
     end.select do |row, col|
       [row, col].all? do |coord|
         coord.between?(0, 7)
       end
     end
     adjacent_coords
  end

  def potential_spots_empty?(coords)
    empty_spots = []
    #puts self.team
    coords.each do |pos|
      if board[pos[0]][pos[1]].class == NullPiece || board[pos[0]][pos[1]].team != self.team
        if pos[0].between?(0, 7) && pos[1].between?(0, 7)
          empty_spots << pos
        end
      end
    end
    empty_spots
  end

end


class M_Knight < Piece
  attr_accessor :M_Knights_deltas
  include SteppingPiece
  def initialize(team, location)
    super(team, location)
    @M_Knights_deltas = [[1, -2],[ 1, 2],[2, -1],[2, 1],[-1, 2],[-1, -2],[-2, 1],[-2,-1]]
  end

  def moves
    potential_spots_empty?(proximity_potential_spots(@M_Knights_deltas))
  end
end

class King < Piece
  attr_accessor :Kings_deltas
  include SteppingPiece
  def initialize(team, location)
    super(team, location)
    @Kings_deltas = [[0,-1],[0, 1],[1, 0],[-1,0],[-1,-1],[-1,1],[1,-1],[1,1]]

  end

  def moves
    potential_spots_empty?(proximity_potential_spots(@Kings_deltas))
  end
end


class Pawn < Piece
  attr_accessor :Pawns_deltas, :first_move, :team
  include SteppingPiece
  def initialize(team, location)
    super(team, location)
    @Pawns_deltas = []
    @first_move = true
    pawns_dir_team_based
  end

  def pawns_dir_team_based
    @Pawns_deltas=([[-1,0],[-2, 0]]) if self.team == "black"
    @Pawns_deltas=([[1,0],[2, 0]]) if self.team == "red"

  end

  def moves
    potential_spots_empty?(proximity_potential_spots(@Pawns_deltas))
  end
end

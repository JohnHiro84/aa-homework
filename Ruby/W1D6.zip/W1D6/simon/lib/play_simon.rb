require_relative 'simon'


simon_says = Simon.new
simon_says.play

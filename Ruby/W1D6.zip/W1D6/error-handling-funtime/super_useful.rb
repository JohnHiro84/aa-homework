# PHASE 2
def convert_to_int(str)

  begin
    Integer(str)
  rescue ArgumentError => e
    puts e.class
    puts e
    puts "Error was: #{e.message}"
  end
end

# print convert_to_int("20234d4")
# print convert_to_int("a" )



# PHASE 3
#
# def reaction(maybe_fruit)
#   begin
#     if FRUITS.include? maybe_fruit
#       puts "OMG, thanks so much for the #{maybe_fruit}!"
#     else
#       raise ArgumentError.new "Monster doesn't like this type of food"
#       puts e
#     end
#   rescue
#     if maybe_fruit == "coffee"
#       raise CoffeeError
#     end
#     #retry
#   end
# end
#

#
# def feed_me_a_fruit
#   puts "Hello, I am a friendly monster. :)"
#   puts "Feed me a fruit! (Enter the name of a fruit:)"
#   maybe_fruit = gets.chomp
#   reaction(maybe_fruit)
# end

FRUITS = ["apple", "banana", "orange"]

class CoffeeError < StandardError
  def message
    puts "I cant have caffeine"
  end
end

def reaction(maybe_fruit)
  if FRUITS.include?(maybe_fruit)
    puts "I really love #{maybe_fruit}, Thank you!"
  elsif maybe_fruit == "coffee"
    raise CoffeeError
  else
    raise ArgumentError
  end
end

def feed_me_a_fruit
  puts "I am a nice monster :)"
  begin
    puts "Feed me a fruit(Enter the name of a fruit)"
    fruit_input = gets.chomp
    reaction(fruit_input)
  rescue CoffeeError => e
    puts e.message
    retry
  rescue ArgumentError => e
    puts e
  end
end

#feed_me_a_fruit




# PHASE 4
class ShortStringError < StandardError
  def message
    puts "the string you entered is too short, needs to be longer"
  end
end

class BestFriend
  def initialize(name, yrs_known, fav_pastime)

    if yrs_known < 5
      begin
        raise ArgumentError.new "You need to know someone at least 5 years to be a bestie"
      rescue ArgumentError => e
        puts e
      end
      real = BestFriend.new("Tanya", 8, "Doing Science")
      print real
    end
    if name == "" || fav_pastime == "" 
      begin
        raise ShortStringError.new "string is too short"
      rescue ShortStringError => e
        puts e
      end
    end
    @name = name
    @yrs_known = yrs_known
    @fav_pastime = fav_pastime
  end

  def talk_about_friendship
    puts "Wowza, we've been friends for #{@yrs_known}. Let's be friends for another #{1000 * @yrs_known}."
  end

  def do_friendstuff
    puts "Hey bestie, let's go #{@fav_pastime}. Wait, why don't you choose. 😄"
  end

  def give_friendship_bracelet
    puts "Hey bestie, I made you a friendship bracelet. It says my name, #{@name}, so you never forget me."
  end
end

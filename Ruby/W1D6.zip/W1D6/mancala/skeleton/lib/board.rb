require 'byebug'

class Board
  attr_accessor :cups, :player1, :player2

  def initialize(name1, name2)
    @cups = []
    14.times do
      @cups << Array.new
    end

    place_stones
    @name1 = name1
    @name2 = name2
  end



  def place_stones
    # helper method to #initialize every non-store cup with four stones each
    @cups.each.with_index do |cup, idx|
      #debugger
      if idx != 6 && idx != 13
        4.times do |stone|
          cup << :stone
        end
      else
        puts "not the right cup, players cups"
      end
    end
  end

  def valid_move?(start_pos)
    range = false
    not_players_cup = false
    if start_pos > -1 && start_pos < 14
      range = true
    end
    if start_pos != 6 && start_pos != 13
      not_players_cup = true
    end
    raise 'Invalid starting cup' if range == false || not_players_cup == false
    raise 'Starting cup is empty' if cups[start_pos].length == 0
    range && not_players_cup && cups[start_pos].length > 0
  end
  #
  # def make_move(start_pos, current_player_name)
  #   #debugger
  #
  #   # puts "what cup do you want to put the stones in?"
  #   # destination = gets.chomp
  #   # dest = destination.to_i
  #
  #   dest = start_pos
  #   dest_idx = 0
  #   nums_stones_in_cup = cups[start_pos].length
  #
  #
  #   nums_stones_in_cup.times do
  #
  #     pop_stone = cups[start_pos].pop
  #     #skip opponents cup
  #     if current_player_name == @player1name
  #       #no stones in cup 13 but yes in cup 6
  #       if (dest + dest_idx) != 13
  #         cups[dest + dest_idx] << pop_stone
  #         dest_idx +=1
  #       else
  #         dest = 0
  #         cups[dest] << pop_stone
  #         dest_idx +=1
  #       end
  #
  #     elsif current_player_name == @player2name
  #       #no stones in cup 6 but yes in cup 13
  #       if (dest + dest_idx) != 6
  #         cups[dest + dest_idx] << pop_stone
  #         dest_idx +=1
  #       else
  #           dest_idx +=1
  #         cups[destination + dest_idx] << pop_stone
  #
  #       end
  #     end
  #   end
  #   #debugger
  #
  # end

  def make_move(start_pos, current_player_name)
  # empties cup
  stones = @cups[start_pos]
  @cups[start_pos] = []

  # distributes stones
  cup_idx = start_pos
  until stones.empty?
    cup_idx += 1
    cup_idx = 0 if cup_idx > 13
    # places stones in the correct current player's cups
    if cup_idx == 6
      @cups[6] << stones.pop if current_player_name == @name1
    elsif cup_idx == 13
      @cups[13] << stones.pop if current_player_name == @name2
    else
      @cups[cup_idx] << stones.pop
    end
  end

  render
  next_turn(cup_idx)
end



  def next_turn(ending_cup_idx)
    if ending_cup_idx == 6 || ending_cup_idx == 13
      :prompt
    elsif @cups[ending_cup_idx].count == 1
      :switch
    else
      ending_cup_idx
    end
    # helper method to determine whether #make_move returns :switch, :prompt, or ending_cup_idx
  end

  def render
    print "      #{@cups[7..12].reverse.map { |cup| cup.count }}      \n"
    puts "#{@cups[13].count} -------------------------- #{@cups[6].count}"
    print "      #{@cups.take(6).map { |cup| cup.count }}      \n"
    puts ""
    puts ""
  end

  def one_side_empty?
    one_row = false
    two_row = false
    @cups.each.with_index do |cup, i|
      if i >= 0 && i <= 5 && cup.empty? == true
        one_row = true
      elsif i >= 7 && i < 13 && cup.empty? == true
        two_row = true
      end
    end
    one_row == true || two_row == true
  end

  def winner
    if @cups[6].length > @cups[13].length
      return @name1
    elsif @cups[13].length > @cups[6].length
      return @name2
    elsif @cups[6].length == @cups[13].length
      return :draw
    end
  end
end

require_relative "tile.rb"
require 'colorized_string'

ColorizedString.disable_colorization = false

class Board
  def initialize(filename)
    @grid = Board.from_file(filename)
  end

  def self.from_file(file)
    #factory method to read a file and parse it
    #into a two-dimensional Array containing Tile instances.
    grid = Array.new(9){[]}
    File.open(file).each.with_index do |line, i|
      line.chomp.each_char do |chr|
        if chr.to_i > 0
          grid[i] << Tile.new(chr, true)
        else
          grid[i] << Tile.new(chr, false)
        end
      end
    end
    grid
  end

  # def grid
  #   @grid
  # end


  # A render method to display the current board state
  def render
    print "\n"
    print "   0 1 2 3 4 5 6 7 8\n\n"

    @grid.each.with_index do |array, i|
      #print array
      print i.to_s + "  "
      array.each do |ele|
        if ele.original == true
          print ColorizedString[ele.value].colorize(:yellow) + " "
        elsif ele.original == false
          print ele.value + " "
        end

      end
      print "\n"
    end
  end

  # A method to update the value of a Tile at the given position
  #setting a new value
  def [](position, new_value)
    row, column = position

    if @grid[row][column].original == false
        @grid[row][column].value = new_value
    else
      print "this tile is original and cannot be changed"
    end
  end

  def turn
    puts "please enter coordinates(0-8) seperated by a space => 3 4"
    coordinates = gets.chomp.split(" ")

    coordinates_i = coordinates.map { |e| e.to_i  }

    puts "please enter a value(1-9) that you want this coordinate to become:"
    value = gets.chomp

    if coordinates.length == 2 && value.to_i > 0 && value.to_i < 10 &&

      if @grid[coordinates_i[0]][coordinates_i[1]].original == true
        puts "Sorry, that's an original tile that came with the board"
        puts "it cannot be changed"
      elsif @grid[coordinates_i[0]][coordinates_i[1]].original == false
        self.[](coordinates_i, value)
      end
    end
    #puts sudoku.[]([0, 2], "9")
  end

  ##methods to determine if all the rows have all 9 values
  ##used to create a blank hash used in checking if all 9 values are there

  def make_check_nine_hash
    check_nine_hash = Hash.new { |h, k| h[k] = false }
    (1..9).each do |n|
      check_nine_hash[n] = false
    end
    check_nine_hash
  end

  def check_nine_hash_complete?(hash)
    if hash.has_value?(false) == true
      false
    else
      true
    end
  end


  #Row - does the row have 1,2,3,4,5,6,7,8,9

  def row_have_all9?
    @grid.each.with_index do |row, i|
      hash = make_check_nine_hash
      #check individual row
      row.each do |ele|
        if hash.has_key?(ele.value.to_i)
          hash[ele.value.to_i] = true
        end
      end
      if check_nine_hash_complete?(hash) == false
        return false
      else
        true
      end
    end
    return true
  end

  def column_have_all9?
    columns_array = Array.new(9){[]}
    @grid.each do |row|
      row.each.with_index do |ele, i|
        columns_array[i] << ele
      end
    end

    columns_array.each.with_index do |row, i|
      hash = make_check_nine_hash
      #check individual row
      row.each do |ele|
        if hash.has_key?(ele.value.to_i)
          hash[ele.value.to_i] = true
        end
      end
      if check_nine_hash_complete?(hash) == false
        return false
      else
        true
      end
    end
    return true
  end



  def three_by_three_all9?

    array_of_chunks = []
    shift = 0
    i = 0
    while array_of_chunks.length < 9

      chunk = []
      while chunk.length < 9
        chunk += @grid[i][(0+shift)..(2+shift)]
        i+=1
      end

      array_of_chunks << chunk

      if array_of_chunks.length % 3 == 0
        shift+=3
        i = 0
      end
    end
    ##repeated code
    array_of_chunks.each.with_index do |row, i|
      hash = make_check_nine_hash
      #check individual row
      row.each do |ele|
        if hash.has_key?(ele.value.to_i)
          hash[ele.value.to_i] = true
        end
      end
      if check_nine_hash_complete?(hash) == false
        return false
      else
        true
      end
    end
    return true
  end

  def game_over?
    if row_have_all9? == true && column_have_all9? == true && three_by_three_all9? == true
      render
      puts
      puts "You Win! Congratulations!"
      sleep(5)
      true
    end
  end
end


#puts sudoku.[]([0, 2], "9")
#
# sudoku = Board.new("sudoku1.txt")
# sudoku.render
# puts sudoku.row_have_all9?
# puts sudoku.column_have_all9?
# puts sudoku.three_by_three_all9?
# puts sudoku.game_over?

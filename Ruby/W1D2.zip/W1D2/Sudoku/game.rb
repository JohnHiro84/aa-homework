require_relative "board"

system "clear" or system "cls"
puts "please enter a sudoku filename in the puzzles directory"
puts " sudoku1.txt \n sudoku1_almost.txt\n sudoku1_solved.txt\n sudoku2.txt\n sudoku3.txt\n\n"

input = "./puzzles/" + gets.chomp

sudoku = Board.new(input)
system "clear" or system "cls"
until sudoku.game_over? do

  sudoku.render
  puts
  sudoku.turn
  system "clear" or system "cls"
end

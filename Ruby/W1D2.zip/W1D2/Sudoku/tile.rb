class Tile
  def initialize (value, original)
    @value = value
    @original = original
  end
  def value
    @value
  end

  def value=(number)
    @value = number
  end
  def original
    @original
  end

end

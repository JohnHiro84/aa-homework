require_relative "game"

puts "Enter a size for the game(2,4,6,8) "

cardgame = Game.new(gets.chomp.to_i)
system "clear" or system "cls"

cardgame.take_turn

class Card

  attr_accessor  :face_value, :facing

  def initialize(value)
    @facing = "down"
    @face_value = value

  end
  def hide

  end

  def reveal

  end

  def to_s

  end

  def ==(another_card)

  end
end

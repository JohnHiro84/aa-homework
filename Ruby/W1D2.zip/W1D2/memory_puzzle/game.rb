require_relative "board"


class Game
  attr_accessor  :playboard

  def initialize(num)

    # if permitted_size(num) == true
      @playboard = Board.new(num)
      playboard.populate
    # end
    @guessed_pos = 8

  end

  # def permitted_size(num)
  #   if num % 2 == 0 && num < 10
  #     true
  #   else
  #     false
  #   end
  # end


  def take_turn
    # prompt the player for input,
    puts "Enter 2 coordinates for a card to guess: "
    puts "then press enter and enter another 2 coordinates"
    puts "seperated by a space ie: 2 0 Enter 0 0 Enter"
    puts "-------------------------------------"
    input1 = gets.chomp
    input2 = gets.chomp
    input1array = input1.split(" ")
    input2array = input2.split(" ")
    playboard.reveal(input1array, input2array)
    playboard.print_hidden_board
    #playboard.print_populated_board
    sleep(2)

    system "clear" or system "cls"

    if playboard.check_if_match(input1array, input2array) == false
      playboard.hide(input1array, input2array)
    end
    puts playboard.game_over?
    if playboard.game_over? == false
      take_turn
    elsif playboard.game_over? == true
      print "congratulations! you've matched all the pairs!"
    end
  end

  # until playboard.count_cards_facing_up == playboard.num_tiles
  #   take_turn
  # end
    # until playboard.game_over? do
    #   puts "-------------------------"
    #    # render the board
    #   take_turn
    #
    # end

end



#print board.grid
#print board.grid
# ------------------
# board = Board.new(4)
# puts board.populate
# board.print_populated_board
# board.print_hidden_board



# playit = Game.new(2)
# puts playit.playboard.print_populated_board
# puts playit.playboard.game_over?
# puts playit.playboard.count_cards_facing_up
# puts playit.take_turn

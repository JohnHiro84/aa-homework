require_relative "card"


class Board
  UNIQUE_CARDS = "AABBCCDDEEFFGGHHIIJJKKLLMMNNOOPPQQRRSSTTUUVVWWXXYYZZ11223344556677889900@@$$&&%%"
  attr_accessor  :num_tiles

  def initialize(n)
  @grid = []
    n.times do
      @grid << Array.new(n, ".")
    end
  @num_tiles = n * n
  @grid_width = n
  end


  def grid
    @grid
  end



  def populate
    #UNIQUE_CARDS.each_char.with_index { |char, i| puts i  }
    tile_num = 0
        while pop_check_unpopulated > 0
          rand_x = rand(0...grid.length)
          rand_y = rand(0...grid.length)

          if grid[rand_x][rand_y] == "."
            grid[rand_x][rand_y] = Card.new(UNIQUE_CARDS[tile_num])
            tile_num +=1
          end
        end
  end

  def pop_check_unpopulated
    num_unpopulated = 0
    grid.each do |row|
      row.each {  |tile| num_unpopulated+=1 if tile == "." }
    end
    num_unpopulated
  end


  ##shows all the cards values
  def print_populated_board
    puts
    puts
    grid.each do |row|
       row.each do |card|
         print " " + card.face_value.to_s
       end
       puts
    end
  end

  def print_hidden_board
    puts
    puts
    grid.each do |row|
       row.each do |card|
         if card.facing == "down"
           print "."
         elsif card.facing == "up"
           print " " + card.face_value.to_s
         end
       end
       puts
    end
  end


  def count_cards_facing_up
    count = 0
    grid.each do |row|
       row.each do |card|
         if card.facing == "up"
           count+=1
         end
       end
    end
    count
  end

  def game_over?
    false
    if num_tiles == count_cards_facing_up
      true
    else
      false
    end
  end

  def render

  end

  def won?

  end

  def reveal(arr1, arr2)

    #should reveal card at guessed_pos
    self.grid[arr1[0].to_i][arr1[1].to_i].facing = "up"
    self.grid[arr2[0].to_i][arr2[1].to_i].facing = "up"

  end

  def check_if_match(arr1, arr2)
    if self.grid[arr1[0].to_i][arr1[1].to_i].face_value == self.grid[arr2[0].to_i][arr2[1].to_i].face_value
      true
    else
      false
    end 
  end

  def hide(arr1, arr2)
    self.grid[arr1[0].to_i][arr1[1].to_i].facing = "down"
    self.grid[arr2[0].to_i][arr2[1].to_i].facing = "down"

  end
end
#
# board = Board.new(4)
# #print board.grid
# puts board.populate
# #print board.grid
#
# board.print_populated_board
#
# board.print_hidden_board
